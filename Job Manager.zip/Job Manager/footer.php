                        </div>
                        </main><!-- #main -->
                    </div><!-- #primary -->
                </div>
        



                                    <div class="col-md-4">
                        
<aside id="secondary" class="widget-area">
    <section id="search-2" class="widget widget_search"><form role="search" method="get" class="search-form" action="http://localhost/wordpress/wordpress/">
                <label>
                    <span class="screen-reader-text">Search for:</span>
                    <input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
                </label>
                <input type="submit" class="search-submit" value="Search" />
            </form></section>       <section id="recent-posts-2" class="widget widget_recent_entries">      <h2 class="widget-title">Recent Posts</h2>      <ul>
                                            <li>
                    <a href="http://localhost/wordpress/wordpress/2018/08/04/hello-world/"></a>
                                    </li>
                    </ul>
        </section><section id="recent-comments-2" class="widget widget_recent_comments"><h2 class="widget-title">Recent Comments</h2><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link"><a href='https://wordpress.org/' rel='external nofollow' class='url'></a></span><a href="http://localhost/wordpress/wordpress/2018/08/04/hello-world/#comment-1"></a></li></ul></section></aside><!-- #secondary -->
                    </div>
           </div>

            </div>

<footer>
    
    <div class="botfooter">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright" style="color: ">
                        <p>
                            <a>Created By Darshit Patel & Parth Navsariwala</a> <span class="sep"> | </span>
                            Theme: <a target="_blank" href="https://codethemes.co/product/robolist-lite" rel="nofollow" title="Robolist Lite">Robolist Lite</a> by Code Themes.                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>


<style>[class*="fa fa-"]{font-family: FontAwesome !important;}</style><link rel='stylesheet' id='jp-front-styles-css'  href='wordpress/wp-content/plugins/job-postings/include/../css/style.css?v=1.7.8&#038;ver=4.9.8' type='text/css' media='all' />
<script type='text/javascript' src='wordpress/wp-includes/js/admin-bar.min.js?ver=4.9.8'></script>
<script type='text/javascript' src='wordpress/wp-content/uploads/bb-plugin/cache/14-layout.js?ver=2a4fac57bd30979a092e53f15b560b98'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/js/navigation.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/js/skip-link-focus-fix.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/bootstrap.min.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/slick.min.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/tabs.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/fitvids.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/sticky-header.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/jarallax.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/sidr.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/bootstrap-select.min.js?ver=20151215'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var robolist_lite_params = {"login_url":"http:\/\/localhost\/wordpress\/wordpress\/wp-login.php","listings_page_url":"http:\/\/localhost\/wordpress\/wordpress\/jobs\/","strings":{"wp-job-manager-file-upload":"Add Photo","no_job_listings_found":"No results","results-no":"Results"}};
/* ]]> */
</script>
<script type='text/javascript' src='wordpress/wp-content/themes/robolist-lite/assets/js/app.js?ver=20151215'></script>
<script type='text/javascript' src='wordpress/wp-includes/js/wp-embed.min.js?ver=4.9.8'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var jpsd = {"ajaxurl":"http:\/\/localhost\/wordpress\/wordpress\/wp-admin\/admin-ajax.php","no_name":"Please input template name."};
/* ]]> */
</script>
<script type='text/javascript' src='wordpress/wp-content/plugins/job-postings/include/../js/script.js?v=1.7.8&#038;ver=4.9.8'></script>
	<script type="text/javascript">
			(function() {
				var request, b = document.body, c = 'className', cs = 'customize-support', rcs = new RegExp('(^|\\s+)(no-)?'+cs+'(\\s+|$)');

						request = true;
		
				b[c] = b[c].replace( rcs, ' ' );
				// The customizer requires postMessage and CORS (if the site is cross domain)
				b[c] += ( window.postMessage && request ? ' ' : ' no-' ) + cs;
			}());
		</script>
	<!--<![endif]-->
</body>
</html>
