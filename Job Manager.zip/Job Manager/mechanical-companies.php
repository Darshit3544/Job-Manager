<?php
include "header.php";
?>
<title>Mechanical-Companies &#8211; Job Creator</title>

 <div class="fl-col-group fl-node-5b6e9b2b0cf24" data-node="5b6e9b2b0cf24">
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.audi.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="audi.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
    	<p style="font-size: 30px"><strong>Audi</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
    Audi AG is a German automobile manufacturer that designs, engineers, produces, markets and distributes luxury vehicles. Audi is a member of the Volkswagen Group and has its roots at Ingolstadt, Bavaria, Germany.The eventful and varied history of AUDI AG extends back to the 19th century. Find out more about the great personalities from the brand’s 100-plus years of history. Learn about the fascinating evolution of the various models and major milestones in the fields of car manufacturing, engine production and motor racing.
</div>
</div>
</div>
</div>

</div>
   

             <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://http://www.mahindra.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="M&M.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
    	<p style="font-size: 30px"><strong>Mahindra & Mahindra</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
 		Our story was cast and hewn in India’s steel industry in 1945, and today, we’re a US $20.7 billion global federation of companies. Famous for our rugged and reliable automobiles, some also know us for our innovative IT solutions, and others for our commitment to rural prosperity.Seven decades in the making, our history is definitive of the growth of modern India. It is a story with an upward curve, of how an Indian company — and all the associations that arise with that phrase — rose to become a global powerhouse. We’ve come a long way since the Willys, and as we accelerate into the 21st century, our journey as a global brand is well under way.
</div>
</div>
</div>
</div>

</div>
    

<?php
include "footer.php";
?>