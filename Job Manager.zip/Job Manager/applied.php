<?php
include "Com_header.php";
?>
<title>Applied Students</title>

<script type="text/javascript">
$(document).ready(function(){

        var action="app_list";
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action,
        success : function(data)
        {
            $("#po_1").html(data);
        }
       })
  })
</script>

<p id="po_1"></p>

<?php
include "footer.php";
?>