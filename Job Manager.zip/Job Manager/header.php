<?php
session_start();
?>
<!doctype html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">
<script src="jquery-3.3.1.min.js"></script>
<script src="bootstrap.min.js"></script>
<style type="text/css">
.w3-animate-right{position:relative;animation:animateright 0.4s}@keyframes animateright{from{right:-300px;opacity:0} to{right:0;opacity:1}}
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='dashicons-css'  href='wordpress/wp-includes/css/dashicons.min.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='admin-bar-css'  href='wordpress/wp-includes/css/admin-bar.min.css?ver=4.9.8' type='text/css' media='all' />
<style id='admin-bar-inline-css' type='text/css'>
#wp-admin-bar-fl-builder-frontend-edit-link .ab-icon:before { content: "\f116" !important; top: 2px; margin-right: 3px; }
</style>
<link rel='stylesheet' id='fl-builder-layout-14-css'  href='wordpress/wp-content/uploads/bb-plugin/cache/14-layout.css?ver=79eac36fbb861a08d6c236ca92b0fab9' type='text/css' media='all' />
<link rel='stylesheet' id='jsjob-jobseeker-style-css'  href='wordpress/wp-content/plugins/js-jobs/includes/css/jobseekercp.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='jsjob-employer-style-css'  href='wordpress/wp-content/plugins/js-jobs/includes/css/employercp.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='jsjob-style-css'  href='wordpress/wp-content/plugins/js-jobs/includes/css/style.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='jsjob-style-tablet-css'  href='wordpress/wp-content/plugins/js-jobs/includes/css/style_tablet.css?ver=4.9.8' type='text/css' media='(min-width: 481px) and (max-width: 780px)' />
<link rel='stylesheet' id='jsjob-style-mobile-landscape-css'  href='wordpress/wp-content/plugins/js-jobs/includes/css/style_mobile_landscape.css?ver=4.9.8' type='text/css' media='(min-width: 481px) and (max-width: 650px)' />
<link rel='stylesheet' id='jsjob-style-mobile-css'  href='wordpress/wp-content/plugins/js-jobs/includes/css/style_mobile.css?ver=4.9.8' type='text/css' media='(max-width: 480px)' />
<link rel='stylesheet' id='jsjob-chosen-style-css'  href='wordpress/wp-content/plugins/js-jobs/includes/js/chosen/chosen.min.css?ver=4.9.8' type='text/css' media='all' />
<!--[if IE]>
<link rel='stylesheet' id='jsjobs-css-ie-css'  href='wordpress/wp-content/plugins/js-jobs/includes/css/jsjobs-ie.css?ver=4.9.8' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='image-hover-effects-css-css'  href='wordpress/wp-content/plugins/mega-addons-for-visual-composer/css/ihover.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='style-css-css'  href='wordpress/wp-content/plugins/mega-addons-for-visual-composer/css/style.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-latest-css'  href='wordpress/wp-content/plugins/mega-addons-for-visual-composer/css/font-awesome/css/font-awesome.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='simple-job-board-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100i%2C300%2C300i%2C400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i&#038;ver=2.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='simple-job-board-font-awesome-css'  href='wordpress/wp-content/plugins/simple-job-board/public/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='simple-job-board-jquery-ui-css'  href='wordpress/wp-content/plugins/simple-job-board/public/css/jquery-ui.css?ver=1.12.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-job-board-frontend-css'  href='wordpress/wp-content/plugins/simple-job-board/public/css/simple-job-board-public.css?ver=3.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='wordpress/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='chosen-css'  href='wordpress/wp-content/plugins/wp-job-manager/assets/css/chosen.css?ver=1.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='wp-job-manager-frontend-css'  href='wordpress/wp-content/plugins/wp-job-manager/assets/css/frontend.css?ver=1.31.2' type='text/css' media='all' />
<link rel='stylesheet' id='robolist-lite-style-css'  href='wordpress/wp-content/themes/robolist-lite/style.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='robolist-custom-lite-style-css'  href='wordpress/wp-content/themes/robolist-lite/assets/css/robolist.css?ver=4.9.8' type='text/css' media='all' />
<link rel="stylesheet" type="text/css" href="//localhost/wordpress/wordpress/wp-content/plugins/smart-slider-3/library/media/smartslider.min.css?1533993153" media="all" />
<script type='text/javascript' src='wordpress/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='wordpress/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='wordpress/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='wordpress/wp-content/plugins/mega-addons-for-visual-composer/js/script.js?ver=4.9.8'></script>
<link rel='https://api.w.org/' href='wordpress/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="wordpress/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="wordpress/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.8" />
<link rel="canonical" href="wordpress/" />
<link rel='shortlink' href='wordpress/' />
<link rel="alternate" type="application/json+oembed" href="wordpress/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwordpress%2Fwordpress%2F" />
<link rel="alternate" type="text/xml+oembed" href="wordpress/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwordpress%2Fwordpress%2F&#038;format=xml" />
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<style type="text/css" media="print">#wpadminbar { display:none; }</style>
</style>
<link rel="icon" href="wordpress/wp-content/uploads/2018/08/cropped-jc-1-32x32.jpg" sizes="32x32" />
<link rel="icon" href="wordpress/wp-content/uploads/2018/08/cropped-jc-1-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="wordpress/wp-content/uploads/2018/08/cropped-jc-1-180x180.jpg" />
<meta name="msapplication-TileImage" content="wordpress/wp-content/uploads/2018/08/cropped-jc-1-270x270.jpg" />

<body>
<!-- Header -->

<div id="sidr" class="mobile-menu">
    <div class="menu-close">
        <i class="fa fa-close"></i>

    </div>

      
    <ul id="menu-menu-2" class="nav navbar-nav">
<li id="sign-out" class="signout"><a class="dropdown-toggle" style="margin-left:30%;margin-right:30%" data-toggle="dropdown" href="profile.php"><img alt='' src='profile.jpg' OnError="this.src='profile.jpg';" id="imm" class='avatar avatar-32 photo' style="border-radius:150px;box-shadow: 0px 0px 10px 0px;height:60px;width:60px;"/></span></a><ul class="dropdown-menu"><li><a data-toggle="modal" data-target="#login" href="">Login</a></li></ul></li>
      <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-14 current_page_item menu-item-29 active"><a title="HOME" href="home.php">HOME</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30"><a title="Profile" href="profile.php">Profile</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a title="Academic" href="academic.php">Academic</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-51"><a title="Projects & Achievements" href="projects.php">Projects & Achievements</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-52"><a title="Resume" href="pdf1.php">Resume</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-81 dropdown"><a title="Companies" href="companies.php">Companies <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu">
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-84"><a title="IT Companies" href="it-companies.php">IT Companies</a></li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-90"><a title="Electrical Companies" href="electrical-companies.php">Electrical Companies</a></li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-93"><a title="Civil Companies" href="civil-companies.php">Civil Companies</a></li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-96"><a title="Mechanical Companies" href="Mechanical-companies.php">Mechanical Companies</a></li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-96"><a title="Electronics & Communication Companies" href="EC-companies.php">Electronics & Communication Companies</a></li>
</ul>
</li>   
</ul></div>


<header id="top" class="header hero" >
    <!-- Start of Naviation -->
    <div class="nav-wrapper">
        <div class="">
            <div class="col-md-2">

                <div class="site-branding" style="margin-left:35px">
                    <a href="home.php" class="custom-logo-link" rel="home" itemprop="url"><img width="644" height="498" src="JM.png" class="custom-logo" alt="Job Creator" itemprop="logo" srcset="JM.png 644w, JM.png 300w" sizes="(max-width: 644px) 100vw, 644px" /></a>  
                    <h1 class="site-title"><a href="home.php" rel="home">Job Manager</a></h1>
                                        </div><!-- .site-branding -->
                <div class="show-mobile">

                    <ul class="nav navbar-nav">
                        <li id="sign-out" class="signout"><a class="dropdown-toggle" data-toggle="dropdown" href="profile.php"><img alt='' src='profile.jpg' id="im" OnError="this.src='profile.jpg';" style="border-radius:150px;box-shadow: 0px 0px 10px 0px;height:60px;width:60px;" /></span></a><ul class="dropdown-menu"><li><a data-toggle="modal" data-target="#newlogin" href="">Login</a></li></ul></li> 
                        </ul>                                                  
                </div>
                <div class="navbar-header">
                    <a id="simple-menu" class="ninja-btn menu-btn pull-right" href="#sidr"><span></span></a>
                </div>
            </div>
            <div class="col-md-7">
                <nav id="primary-nav" class="navbar navbar-default">
                    <!-- Brand and toggle get grouped for better mobile display -->

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="navbar-collapse">
                        <ul id="menu-menu-2" class="nav navbar-nav">
                          <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-14 current_page_item menu-item-29 active"><a title="HOME" href="home.php">HOME</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30"><a title="Profile" href="profile.php">Profile</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a title="Academic" href="academic.php">Academic</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-51"><a title="Projects & Achievements" href="projects.php">Projects & Achievements</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-52"><a title="Resume" href="pdf1.php">Resume</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-81 dropdown"><a title="Companies" href="companies.php">Companies <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-84"><a title="IT Companies" href="it-companies.php">IT Companies</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-90"><a title="Electrical Companies" href="electrical-companies.php">Electrical Companies</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-93"><a title="Civil Companies" href="civil-companies.php">Civil Companies</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-96"><a title="Mechanical Companies" href="Mechanical-companies.php">Mechanical Companies</a></li>
    <li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-96"><a title="Electronics & Communication Companies" href="EC-companies.php">Electronics & Communication Companies</a></li>
</ul>
</li>   
</ul>                    </div><!-- End navbar-collapse -->
                </nav>
            </div>
            <div class="col-md-3">
                <ul class="nav navbar-nav">
                    <li id="sign-out" class="signout"><a class="dropdown-toggle" data-toggle="dropdown" href="profile.php"><img src="profile.jpg" id="imms" OnError="this.src='profile.jpg';" style="border-radius:150px;box-shadow: 0px 0px 10px 0px;height:60px;width:60px;"/></span></a><ul class="dropdown-menu"><li><a data-toggle="modal" data-target="#newlogin" href="">Login</a></li><li><a href="" onclick="logout()">Logout</a></li></ul></li></ul>
                  </div>
            </div>
        </div>
    </div>
       <!-- End of Navigation -->
    <script type="text/javascript">
      function logout()
      {
        var action="logout";
        $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action,
        success : function(data)
        {
            $("#p1").html(data);
        }
       })   
      }
    </script>

    <script type="text/javascript">
        $(document).ready(function(){
               $("#log").submit(function(event){
           var action="log";
           event.preventDefault();
      var mail=document.getElementById("mail").value;
      var pass=document.getElementById("Password1").value;
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"mail="+mail+"&pas="+pass+"&act="+action,
        success : function(data)
        {
          string=data;
            $("#msg").html(data);
        }
       })
    })
    })
    </script>

    <script type="text/javascript">
        $(document).ready(function(){
               $("#com_log").submit(function(event){
           var action="comlog";
           event.preventDefault();
      var name=document.getElementById("com_name").value;
      var pass=document.getElementById("com_password").value;
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"name="+name+"&pas="+pass+"&act="+action,
        success : function(data)
        {
          string=data;
            $("#com_msg").html(data);
        }
       })
    })
    })
    </script>

     <script type="text/javascript">
        $(document).ready(function(){
               $("#com_sign").submit(function(event){
           var action="comsign";
           event.preventDefault();
      var name=document.getElementById("sign_name").value;
      var pass=document.getElementById("sign_password1").value;
      var pass1=document.getElementById("sign_password2").value;
      if(pass==pass1)
      {
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"name="+name+"&pas="+pass+"&act="+action,
        success : function(data)
        {
          string=data;
            $("#sign_msg").html(data);
        }
       })
    }
    else
    {
      alert("Password Does not Match!!!")
    }
    })
    })
    </script>

    <script type="text/javascript">
        function cl()
    {
       document.getElementById("log").reset();
       location.reload();
    }
    </script>

<script type="text/javascript">
  $(document).ready(function(){
  var user_name = "<?php echo $_SESSION['user_id'];?>";
         user_name="upls/".concat(user_name).concat(".jpg");
        $("#imms").attr("src",user_name);
        $("#imm").attr("src",user_name);
      $("#im").attr("src",user_name);
    })
</script>

    </header>
 <p id="p1"></p>
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div id="primary" class="content-area">
                        <main id="main" class="site-main">

    <div class="fl-row-content-wrap">
                <div class="fl-row-content fl-row-fixed-width fl-node-content">
                    
 <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-hidden="true" style="top:120px">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Login
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
    </h3>
      </div>
      <div class="modal-body" style="font-size:20px">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        
  <form id="log">
  <div class="form-group"> 
    <label><strong>User Id</strong></label>
    </div>
    <div class="form-group">
    <input type="text" id="mail" placeholder="Enter User Id" style="width:348px" required>
    </div>
    <div class="form-group">
    <label><strong>Password</strong></label>
    </div>
    <div class="form-group">
    <input type="password" id="Password1" placeholder="Password" style="width:348px" required>
  </div>
    <div class="form-group">
  <button type="submit" class="btn btn-primary" style="font-size:20px"><strong>Login</strong></button>
  </div>
<p id="msg" ></p>
<br>
<nav class="nav justify-content-center">
  <a class="nav-link" href=""><strong>Forget Password?</strong></a>
      
    </nav>
</form> 
      </div>
    </div>
    
</div>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="cl()" >Close</button>
       </div>
    </div>
  </div>
</div>
    
<div class="modal fade" id="newlogin" tabindex="-1" role="dialog" aria-hidden="true" style="top:120px">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Login
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
    </h3>
      </div>
      <div class="modal-body" style="font-size:20px">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        
  <form>
    <div class="row">
  <div class="form-group col-md-6"> 
    
    
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#login" data-dismiss="modal" style="font-size:20px"><strong>I Am Student</strong></button>
  </div>
  
 <div class="form-group col-md-6"> 
  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#comlogin" data-dismiss="modal" style="font-size:20px"><strong>I Am Company</strong></button>
  </div>
</div>
<p id="msg99" ></p>
</form> 
      </div>
    </div>
    
</div>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="cl()" >Close</button>
       </div>
    </div>
  </div>
</div>

<div class="modal fade" id="comlogin" tabindex="-1" role="dialog" aria-hidden="true" style="top:120px">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Login
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
    </h3>
      </div>
      <div class="modal-body" style="font-size:20px">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        
  <form id="com_log">
  <div class="form-group"> 
    <label><strong>User Id</strong></label>
    </div>
    <div class="form-group">
    <input type="text" id="com_name" placeholder="Enter Company Name" style="width:348px" required>
    </div>
    <div class="form-group">
    <label><strong>Password</strong></label>
    </div>
    <div class="form-group">
    <input type="password" id="com_password" placeholder="Password" style="width:348px" required>
  </div>
    <div class="form-group">
  <button type="submit" class="btn btn-primary" style="font-size:20px"><strong>Login</strong></button>
  </div>
<p id="com_msg" ></p>
<br>
  <div class="row">
    <div class="col-md-6">
  <a class="nav-link" href=""><strong>Forget Password?</strong></a>
  </div>
  <div class="col-md-6">
     <a class="nav-link" data-toggle="modal" data-target="#comsign" data-dismiss="modal" href=""><strong>New User?</strong></a>  
   </div>
 </div>
  </form> 
      </div>
    </div>
    
</div>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="cl()" >Close</button>
       </div>
    </div>
  </div>
</div>

<div class="modal fade" id="comsign" tabindex="-1" role="dialog" aria-hidden="true" style="top:120px">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Signup
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
    </h3>
      </div>
      <div class="modal-body" style="font-size:20px">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        
  <form id="com_sign">
  <div class="form-group"> 
    <label><strong>Company Name</strong></label>
    </div>
    <div class="form-group">
    <input type="text" id="sign_name" placeholder="Enter Company Name" style="width:348px" required>
    </div>
    <div class="form-group">
    <label><strong>Password</strong></label>
    </div>
    <div class="form-group">
    <input type="password" id="sign_password1" placeholder="Password" style="width:348px" required>
  </div>
  <div class="form-group">
    <label><strong>Confirm Password</strong></label>
    </div>
    <div class="form-group">
    <input type="password" id="sign_password2" placeholder="Confirm Password" style="width:348px" required>
  </div>
    <div class="form-group">
  <button type="submit" class="btn btn-primary" style="font-size:20px"><strong>Signup</strong></button>
  </div>
<p id="sign_msg" ></p>

</form> 
      </div>
    </div>
  
</div>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="cl()" >Close</button>
       </div>
    </div>
  </div>
</div>

    <div class="entry-content">
           <div class="fl-row-content-wrap">
                <div class="fl-row-content fl-row-fixed-width fl-node-content">

