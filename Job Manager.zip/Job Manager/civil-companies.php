<?php
include "header.php";
?>
<title>Civil-Companies &#8211; Job Creator</title>

 <div class="fl-col-group fl-node-5b6e9b2b0cf24" data-node="5b6e9b2b0cf24">
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.adani.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="adani.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
    	<p style="font-size: 30px"><strong>Adani Limited</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
    Since our inception in 1988, the Adani Group has grown exponentially. Over the last 25 years, the Group has established itself as a leading infrastructure conglomerate from India and put together an integrated value chain that is unique and in many ways unparalleled anywhere in the world.This has been primarily achieved by our people who have had the courage to constantly charter into unexplored waters and made “Thinking Big. Doing Better” a natural philosophy that is embodied in our daily lives at the Adani Group.
</div>
</div>
</div>
</div>

</div>
    
 
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.larsentoubro.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="L&T.jpg" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
    	<p style="font-size: 30px"><strong>Larsen & Toubro</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
 		L&T's Construction has been attracting, holding and moulding the finest engineering talent in India and abroad. People are the Company's most valued asset - its core strength. L&T also has India's largest fleet of sophisticated and specialized equipment for speedy, high-quality and cost-effective construction.Fully mechanized stone and metal quarries and crushing plants throughout India strengthen the resource base of the Company; their operations are completely environment friendly which further sustains L&T's growth. 

</div>
</div>
</div>
</div>

</div>
   

<?php
include "footer.php";
?>