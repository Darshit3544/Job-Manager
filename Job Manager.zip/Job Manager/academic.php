<?php
include "header.php";
if($_SESSION["user_id"]=='')
        {
            $message = "Login First!!!";
            echo "<script type='text/javascript'>alert('$message');window.location='home.php'</script>";
        }
?>
<title>Academic &#8211; Job Creator</title>

<script type="text/javascript">
     $(document).ready(function(){
    var action="aca";
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action,
        success : function(data)
        {
            $("#p3").html(data);
        }
       })
     })
</script>

<p id="p3"></p>

<?php
include "footer.php";
?>