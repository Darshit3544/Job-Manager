<?php
include "Com_header.php";
?>

	<title>Job Creator</title>

<style>
.mySlides {display:none;}
</style>
<div class="w3-content w3-section" style="max-width:500px">
  <img class="mySlides w3-animate-right" src="tcs.png" style="width:100%">
  <img class="mySlides w3-animate-right" src="audi.png" style="width:100%">
  <img class="mySlides w3-animate-right" src="M&M.png" style="width:100%">
  <img class="mySlides w3-animate-right" src="BAJA.png" style="width:100%">
  </div>

  <script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 3500);    
}
</script>
    <script type="text/javascript">
$(document).ready(function(){

        var action="home_post";
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action,
        success : function(data)
        {
            $("#po_1").html(data);
        }
       })
  })
</script>
<script type="text/javascript">
    function app(a,b)
    {
        var action="apply";
        $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action+"&num="+a+"&id="+b,
        success : function(data)
        {
            $("#po_1").html(data);
        }
       })
    }
</script>
<p id="po_1"></p>
    <!-- .entry-content -->


<?php
include "footer.php";
?>