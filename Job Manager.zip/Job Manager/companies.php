<?php
include "header.php";
?>
    <title>IT Companies &#8211; Job Creator</title>

        
<div class="fl-col-group fl-node-5b6e9b2b0cf24" data-node="5b6e9b2b0cf24">
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.tcs.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="TCS.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    
</div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Tata Consultancy Service</strong></p></a>
        <div class="fl-rich-text" style="color: grey">
    <a class="mw-redirect" title="Headquarter" href="https://en.wikipedia.org/wiki/Headquarter">headquartered</a> in <a title="Mumbai" href="https://en.wikipedia.org/wiki/Mumbai">Mumbai</a>, <a title="Maharashtra" href="https://en.wikipedia.org/wiki/Maharashtra">Maharashtra</a>.<sup id="cite_ref-2" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-2">[2]</a></sup><sup id="cite_ref-3" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-3">[3]</a></sup> It is part of the <a title="Tata Group" href="https://en.wikipedia.org/wiki/Tata_Group">Tata Group</a> and operates in 46 countries.<sup id="cite_ref-TCS_Investor_FAQs_4-0" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-TCS_Investor_FAQs-4">[4]</a></sup>
TCS is one of the largest Indian companies by <a title="Market capitalization" href="https://en.wikipedia.org/wiki/Market_capitalization">market capitalization</a>. TCS alone generates 70% dividends of its parent company, <a title="Tata Sons" href="https://en.wikipedia.org/wiki/Tata_Sons">Tata Sons</a>.<sup id="cite_ref-8" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-8">[8]</a></sup> The parent group recently decided to sell stocks of TCS worth $1.25 billion in a bulk deal.<sup id="cite_ref-9" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-9">[9]</a></sup> <sup id="cite_ref-10" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-10">[10]</a></sup> In 2015, TCS is ranked 64th overall in the
</div>
</div>
</div>
</div>

</div>
   

        <!-- .entry-content -->

            

            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
        <a href="https://www.infochip.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="infochip.png" alt="Info Chip" sizes="(max-width: 150px) 100vw, 150px" itemprop="image" title="Info Chip"  />
                    </div>
    </div>
    </div>
</div></div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">

    <div class="fl-module-content fl-node-content">
         <p style="font-size: 25px"><strong>INFO-CHIP COMMUNICATIONS</strong></p></a>
        <div class="fl-rich-text" style="color: grey">
   <strong>INFO-CHIP COMMUNICATIONS</strong> is North America's leading provider of telephone on-hold marketing services and systems. As a customer-centric production company, our emphasis is on providing telephone on-hold services and related business audio productions.
    Our sales force, creative copywriters, voice talent, and production engineers work together to ensure a quality product and quick, professional service.
</div>
</div>
</div>
</div>
    </div>

        <!-- .entry-content -->
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.bhel.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="BHEL.jpg" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Bharat Heavy Electrical Limited</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
    BHEL, one of Indias leading PSUs, is today the largest engineering enterprise of its kind in India. BHEL caters to the needs of core sectors of the economy like Power, Transmission, Industry, Transportation (including Railways), Defence, Renewable energy etc., and various industries like Petrochemicals, Petroleum, Steel, Cement, Fertilisers etc. with its unmatched expertise. With its presence across the country and massive expanse in International Operations, BHEL provides its employees ample opportunity to develop their competencies and hone their skills and talents.
</div>
</div>
</div>
</div>

</div>
   

            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.bajajelectricals.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="BAJA.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Bajaj Electrical Limited</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
         Bajaj Electricals Limited (BEL), a globally renowned and trusted company, with a turnaround of ₹4298 crores (FY 16-17), is a part of "Bajaj Group". Bajaj Electricals business is spread across – Consumer Products (Appliances, Fans, Lighting), Exports, Luminaires and EPC (Illumination, Transmission Towers and Power Distribution). Bajaj Electricals has 19 branch offices spread in different parts of the country besides being supported by a chain of distributors, authorized dealers, retail outlets, exclusive showrooms called ‘Bajaj World’ and approximately 462 customer care centres. We also have a presence in the hi-end range of appliances with brands like Platini and Morphy Richards in India.

</div>
</div>
</div>
</div>

</div>
   
           <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.adani.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="adani.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Adani Limited</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
    Since our inception in 1988, the Adani Group has grown exponentially. Over the last 25 years, the Group has established itself as a leading infrastructure conglomerate from India and put together an integrated value chain that is unique and in many ways unparalleled anywhere in the world.This has been primarily achieved by our people who have had the courage to constantly charter into unexplored waters and made “Thinking Big. Doing Better” a natural philosophy that is embodied in our daily lives at the Adani Group.
</div>
</div>
</div>
</div>

</div>
    
 
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.larsentoubro.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="L&T.jpg" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Larsen & Toubro</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
        L&T's Construction has been attracting, holding and moulding the finest engineering talent in India and abroad. People are the Company's most valued asset - its core strength. L&T also has India's largest fleet of sophisticated and specialized equipment for speedy, high-quality and cost-effective construction.Fully mechanized stone and metal quarries and crushing plants throughout India strengthen the resource base of the Company; their operations are completely environment friendly which further sustains L&T's growth. 

</div>
</div>
</div>
</div>

</div>
   

 <div class="fl-col-group fl-node-5b6e9b2b0cf24" data-node="5b6e9b2b0cf24">
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.audi.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="audi.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Audi</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
    Audi AG is a German automobile manufacturer that designs, engineers, produces, markets and distributes luxury vehicles. Audi is a member of the Volkswagen Group and has its roots at Ingolstadt, Bavaria, Germany.The eventful and varied history of AUDI AG extends back to the 19th century. Find out more about the great personalities from the brand’s 100-plus years of history. Learn about the fascinating evolution of the various models and major milestones in the fields of car manufacturing, engine production and motor racing.
</div>
</div>
</div>
</div>

</div>
   

             <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://http://www.mahindra.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="M&M.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Mahindra & Mahindra</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
        Our story was cast and hewn in India’s steel industry in 1945, and today, we’re a US $20.7 billion global federation of companies. Famous for our rugged and reliable automobiles, some also know us for our innovative IT solutions, and others for our commitment to rural prosperity.Seven decades in the making, our history is definitive of the growth of modern India. It is a story with an upward curve, of how an Indian company — and all the associations that arise with that phrase — rose to become a global powerhouse. We’ve come a long way since the Willys, and as we accelerate into the 21st century, our journey as a global brand is well under way.
</div>
</div>
</div>
</div>

</div>
                

   
<?php
include "footer.php";
?>