<?php
include "header.php";
?>
	<title>IT Companies &#8211; Job Creator</title>

        
<div class="fl-col-group fl-node-5b6e9b2b0cf24" data-node="5b6e9b2b0cf24">
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.drdo.gov.in/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="drdo.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    
</div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Defence Research and Development Organization</strong></p></a>
        <div class="fl-rich-text" style="color: grey">
    Defence Research & Development Organisation (DRDO) works under Department of Defence Research and Development of Ministry of Defence. DRDO dedicatedly working towards enhancing self-reliance in Defence Systems and undertakes design & development leading to production of world class weapon systems and equipment in accordance with the expressed needs and the qualitative requirements laid down by the three services.
</div>
</div>
</div>

</div>
    </div>

        <!-- .entry-content -->

            

            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
        <a href="https://www.syntelinc.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="syntel.jpg" alt="Info Chip" sizes="(max-width: 150px) 100vw, 150px" itemprop="image" title="Info Chip"  />
                    </div>
    </div>
    </div>
</div></div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">

    <div class="fl-module-content fl-node-content">
         <p style="font-size: 25px"><strong>INFO-CHIP COMMUNICATIONS</strong></p></a>
        <div class="fl-rich-text" style="color: grey">
   Syntel is a leading global provider of Information Technology and Knowledge Processing services. We help global enterprises evolve their core IT applications, infrastructure and business processes by leveraging intelligent automation, scaled agile development and cloud computing solutions. Our digital services enable clients to engage their customers, discover new insights, and create more connected enterprises.Syntel, Inc. is a U.S.-based multinational provider of integrated technology and business services.  Syntel is a certified minority-owned business.
</div>
</div>
</div>
</div>
    </div>

        <!-- .entry-content -->
    

   
<?php
include "footer.php";
?>