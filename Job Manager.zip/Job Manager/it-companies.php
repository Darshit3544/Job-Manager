<?php
include "header.php";
?>
	<title>IT Companies &#8211; Job Creator</title>

        
<div class="fl-col-group fl-node-5b6e9b2b0cf24" data-node="5b6e9b2b0cf24">
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.tcs.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="TCS.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    
</div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
        <p style="font-size: 30px"><strong>Tata Consultancy Service</strong></p></a>
        <div class="fl-rich-text" style="color: grey">
    <a class="mw-redirect" title="Headquarter" href="https://en.wikipedia.org/wiki/Headquarter">headquartered</a> in <a title="Mumbai" href="https://en.wikipedia.org/wiki/Mumbai">Mumbai</a>, <a title="Maharashtra" href="https://en.wikipedia.org/wiki/Maharashtra">Maharashtra</a>.<sup id="cite_ref-2" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-2">[2]</a></sup><sup id="cite_ref-3" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-3">[3]</a></sup> It is part of the <a title="Tata Group" href="https://en.wikipedia.org/wiki/Tata_Group">Tata Group</a> and operates in 46 countries.<sup id="cite_ref-TCS_Investor_FAQs_4-0" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-TCS_Investor_FAQs-4">[4]</a></sup>
TCS is one of the largest Indian companies by <a title="Market capitalization" href="https://en.wikipedia.org/wiki/Market_capitalization">market capitalization</a>. TCS alone generates 70% dividends of its parent company, <a title="Tata Sons" href="https://en.wikipedia.org/wiki/Tata_Sons">Tata Sons</a>.<sup id="cite_ref-8" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-8">[8]</a></sup> The parent group recently decided to sell stocks of TCS worth $1.25 billion in a bulk deal.<sup id="cite_ref-9" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-9">[9]</a></sup> <sup id="cite_ref-10" class="reference"><a href="https://en.wikipedia.org/wiki/Tata_Consultancy_Services#cite_note-10">[10]</a></sup> In 2015, TCS is ranked 64th overall in the
</div>
</div>
</div>

</div>
    </div>

        <!-- .entry-content -->

            

            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
        <a href="https://www.infochip.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="infochip.png" alt="Info Chip" sizes="(max-width: 150px) 100vw, 150px" itemprop="image" title="Info Chip"  />
                    </div>
    </div>
    </div>
</div></div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">

    <div class="fl-module-content fl-node-content">
         <p style="font-size: 25px"><strong>INFO-CHIP COMMUNICATIONS</strong></p></a>
        <div class="fl-rich-text" style="color: grey">
   <strong>INFO-CHIP COMMUNICATIONS</strong> is North America's leading provider of telephone on-hold marketing services and systems. As a customer-centric production company, our emphasis is on providing telephone on-hold services and related business audio productions.
    Our sales force, creative copywriters, voice talent, and production engineers work together to ensure a quality product and quick, professional service.
</div>
</div>
</div>
</div>
    </div>

        <!-- .entry-content -->
    

   
<?php
include "footer.php";
?>