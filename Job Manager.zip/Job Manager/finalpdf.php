<?php 

require'fpdf.php';
class PD extends FPDF
{
// Page header
    function Header()
    {
    // Logo
    $this->Image('CSPIT.png',0,0,60,50);
    $this->SetFont('Arial','B',13);
    // Move to the right
    // Title
    $this->SetY(10);
    $this->Cell(230);

    $this->Image('BANNER.png',80,5,200,40);
    $this->Line(00,50,2000,50);
    $this->Ln(40);
    }
    function Footer()
    {
    // Go to 1.5 cm from bottom
    $this->SetY(-15);
    // Select Arial italic 8
    $this->SetFont('Arial','I',14);
    // Print centered page number
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'R');
    }
}
$PD=new PD(); 
$PD->AddPage('L','A4',0);
$PD->Ln(30);
$PD->SetX(30);
$PD->SetY(60);   
$PD->ClippingCircle(250,85,30,True);
$PD->Image('me.jpg',210,35,85);
$PD->UnsetClipping();
$PD->Ln(30);
$PD->SetY(60);
$PD->write(10,'DARSHIT PATEL');
$PD->SetY(70);
$PD->Write(10,'PHONE:-');
$PD->SetY(70);
$PD->SetX(30);
$PD->write(10,'123456789');
$PD->SetY(80);
$PD->Write(10,'EMAIL:-');
$PD->SetX(30);
$PD->write(10,'xyz@gmail.com');
$PD->SetY($a=120);
$PD->SetX($b=10);
$PD->Write(10,'OBJECTIVE:-');
$PD->Line($b,$k=$a+10,$b+280,$k);
$PD->SetY($k);
$PD->SetX($b);
$PD->Write(10,'To work in an organization where culture of freedom and working for initiatives is ensured, facilitating my contribution');
$PD->SetY($k=$k+10);
$PD->write(10,'through thoughts and action to the company vision and thus achieve self-development by playing a important role in the');
$PD->SetY($k=$k+10);
$PD->write(10,'organization.');
$PD->SetY($k=$k+20);
$PD->write(10,'EDUCATIONAL QUALIFICATION:-');
$PD->Line($b,$k=$k+10,$b+280,$k);
$PD->SetX($b);
$PD->SetY($k=$k+80);
$PD->write(10,'CURRENT SEMESTER-4:-');
$PD->SetY($k=70);
$PD->SetX(30);
$PD->MultiCell(40,10,'YEAR',1,'C',False);
$PD->SetY($k=70);
$PD->SetX(70);
$PD->MultiCell(60,10,'DEGREE CERTIFICATION',1,'C',False);
$PD->SetY($k=70);
$PD->SetX(130);
$PD->MultiCell(60,10,'INSTITUTE / BOARD',1,'C',False);
$PD->SetY($k=70);
$PD->SetX(190);
$PD->MultiCell(60,10,'MARKS OBTAINED',1,'C',False);
for($i=0;$i<4;$i++)
    {
        $PD->SetY($k=$k+10);
        $PD->SetX(30); 
        $PD->MultiCell(40,10,'',1,'C',False);
        $PD->SetX(70);
        $PD->MultiCell(60,10,'',1,'C',False);
        $PD->SetX(130);
        $PD->MultiCell(60,10,'',1,'C',False);
        $PD->SetX(190);
        $PD->MultiCell(60,10,'',1,'C',False);
    }
   /* $PD->Ln(10);
    $PD->SetY($k=$j+20);
    $PD->Cell(10);
    $PD->write(10,'Technical Skills');
    $PD->Line(10,$i=$k+10,290,$k+10);
    $PD->Ln(10);
    $k=-1;
    for($j=0;$j<=8;$j++)
    {
        if($j==0) 
        {
            $PD->Ln(10);
        }
        $PD->Cell(10);
        $PD->MultiCell(250,10,$i,1,'C',False);
        $k++;
    }
    $PD->SetY($h=($k+3)*10);
    $PD->Cell(10);
    $PD->write(10,'Technical Area of Intrest:-');
    $PD->Line(10,$m=($h+10),290,$m);
    $o=-1;
    $PD->Ln(10);
    for($j=0;$j<=3;$j++)
    {
         if($j==0) 
        {
            $PD->Ln(10);
        }
        $PD->Cell(10);
        $PD->MultiCell(250,10,$j+1,1,'L',False);
        $o++;
    }
    $PD->SetY($h=($k+$o+16)*10);
    $PD->Cell(10);
    $PD->write(10,'Extra Activities:-');
    $PD->Ln(10);
    $s=0;
   for($j=0;$j<=15;$j++)
    {
         if($j==0) 
        {
            $PD->Ln(10);
        }
        $PD->Cell(10);
        $PD->MultiCell(250,10,$j+1,0,'L',False);
        $s++;
    }
    $PD->SetY(($k+$o+$s)*4);
    $PD->Cell(10);
    $PD->write(10,'PROJECTS:-');
    $PD->Ln(10);
    $d=0;
   for($j=0;$j<=3;$j++)
    {
         if($j==0) 
        {
            $PD->Ln(10);
        }
        $PD->Cell(10);
        $PD->MultiCell(250,10,$j+1,1,'L',False);
        $d++;
    }
    $PD->SetY($f=(($k+$o+$s+$d)*8));
    $PD->Cell(10);
    $PD->write(10,'Personal Details:-');
    $PD->Line(10,$m=$f,290,$m);
    for($j=0;$j<=3;$j++)
    {
        $PD->Ln(10);
        $PD->Cell(10);
        $PD->MultiCell(250,10,$j+1,0,'L',False);
    }*/
$PD->Output();
?>