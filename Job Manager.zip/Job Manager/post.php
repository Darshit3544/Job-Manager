<?php
include "Com_header.php";
?>
	<title>Post</title>
	<script src="ckeditor.js"></script>
	<script type="text/javascript">
  function del(b)
  {
    var action="post_del";
    $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action+"&num="+b,
        success : function(data)
        {
          $("#msg2").html(data);
        }
       })
  }
</script>
	<script type="text/javascript">
$(document).ready(function(){

		var action="post_view";
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action,
        success : function(data)
        {
            $("#post_view").html(data);
        }
       })

      $("#post_form").submit(function(event){
       var action="com_post";
      event.preventDefault();
      var post=document.getElementById("po").value;
      var req=document.getElementById("req").value;
      var eli=document.getElementById("Eli").value;
      var con=CKEDITOR.instances.text.getData();
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action+"&nam="+con+"&post="+post+"&req="+req+"&eli="+eli,
        success : function(data)
        {
          $("#msg2").html(data);
        }
       })
    })

    
})
</script>
	<div class="col-md-6"><button><h3><a data-toggle="modal" data-target="#post_modal" href="">Add Post</a></button></h3></div>
	<p id="post_view"></p>
<div class="modal fade" id="post_modal" tabindex="-1" role="dialog" aria-hidden="true" style="top:120px">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Post
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cl()">
          <span aria-hidden="true">&times;</span>
        </button>
    </h3>
      </div>
      <div class="modal-body" >
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        
  <form id="post_form">
  	<div class="form-group"> 
    <label><strong>Vacancy for the post of </strong></label>
    </div>
    <div class="form-group">
    <input type="text" id="po" placeholder="Enter Vacant Post" style="width:348px" required>
    </div>
    <div class="form-group"> 
    <label><strong>Eligible Criteria</strong></label>
    </div>
    <div class="form-group">
    <input type="text" id="Eli" placeholder="Enter Criteria" style="width:348px" required>
    </div>
    <div class="form-group"> 
    <label><strong>Requirement</strong></label>
    </div>
    <div class="form-group">
    <input type="text" id="req" placeholder="Enter Requirement" style="width:348px" required>
    </div>
  <div class="form-group"> 
    <label><strong>Description about Post</strong></label>
    
     <textarea rows="14" cols="40" id="text" placeholder="Enter Description about Post......" required></textarea> <script>CKEDITOR.replace( 'text' );</script>
    </div>
    
    <div class="form-group">
  <button type="submit" class="btn btn-primary" style="font-size:25px"><strong>Post</strong></button>
  </div>
<p id="msg2" ></p>


</form> 
      </div>
    </div>
    
</div>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="cl()" >Close</button>
       </div>
    </div>
  </div>
</div>

<?php
include "footer.php";
?>