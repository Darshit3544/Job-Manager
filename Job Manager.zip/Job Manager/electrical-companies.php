<?php
include "header.php";
?>
<title>Electrical-Companies &#8211; Job Creator</title>

 <div class="fl-col-group fl-node-5b6e9b2b0cf24" data-node="5b6e9b2b0cf24">
            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.bhel.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="BHEL.jpg" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
    	<p style="font-size: 30px"><strong>Bharat Heavy Electrical Limited</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
    BHEL, one of Indias leading PSUs, is today the largest engineering enterprise of its kind in India. BHEL caters to the needs of core sectors of the economy like Power, Transmission, Industry, Transportation (including Railways), Defence, Renewable energy etc., and various industries like Petrochemicals, Petroleum, Steel, Cement, Fertilisers etc. with its unmatched expertise. With its presence across the country and massive expanse in International Operations, BHEL provides its employees ample opportunity to develop their competencies and hone their skills and talents.
</div>
</div>
</div>
</div>

</div>
   

            <div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
    <div class="fl-module-content fl-node-content">
        <div class="fl-photo fl-photo-align-center" itemscope itemtype="ImageObject">
    <div class="fl-photo-content fl-photo-img-png">
         <a href="https://www.bajajelectricals.com/" target="_self" rel="nofollow"  itemprop="url">
        <img class="fl-photo-img wp-image-98 size-full" src="BAJA.png" alt="TCS" itemprop="image" height="137" width="270" title="TCS"  />
                    </div>
    </div>
    </div>
</div>
    </div>
</div>
            <div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
    <div class="fl-col-content fl-node-content">
    <div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
        
    <div class="fl-module-content fl-node-content">
    	<p style="font-size: 30px"><strong>Bajaj Electrical Limited</strong></p></div></a>
        <div class="fl-rich-text" style="color: grey">
 		 Bajaj Electricals Limited (BEL), a globally renowned and trusted company, with a turnaround of ₹4298 crores (FY 16-17), is a part of "Bajaj Group". Bajaj Electricals business is spread across – Consumer Products (Appliances, Fans, Lighting), Exports, Luminaires and EPC (Illumination, Transmission Towers and Power Distribution). Bajaj Electricals has 19 branch offices spread in different parts of the country besides being supported by a chain of distributors, authorized dealers, retail outlets, exclusive showrooms called ‘Bajaj World’ and approximately 462 customer care centres. We also have a presence in the hi-end range of appliances with brands like Platini and Morphy Richards in India.

</div>
</div>
</div>
</div>

</div>
   

<?php
include "footer.php";
?>