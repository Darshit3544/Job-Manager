
<!doctype html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="http://gmpg.org/xfn/11">

	<title>Job Creator</title>
<style >
    div.js-jobs-resume-apply-now-visitor{border:1px solid #00A9E0;}
    input#jsjobs-login-btn{background: #00A9E0;color:#FFFFFF;}
    div.jsjobs-button-search input#btnsubmit-search,div.jsjobs-button-search input#reset{background: #00A9E0;color:#FFFFFF;}
    div#jsjob-search-popup span.popup-title, div#jsjobs-listpopup span.popup-title{background: #00A9E0;color:#FFFFFF;}
    div#jsjobs-wrapper a{color:#0097C9;}
    div#jsjobs-pagination span.page-numbers.current{color:#00A9E0;}
    div#jsjobs-pagination a.page-numbers.next{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-pagination a.page-numbers.prev{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-wrapper div.page_heading a.additem{border:1px solid #D4D4D5;color:#64676A;background:#FAFAFA;}
    div#jsjobs-wrapper div.page_heading a.additem:hover{border:1px solid #00A9E0;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewrow div.quickviewrow span.visitor-message{border:1px solid #F8E69C;background:#FEFED8;color:#444442;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewrow div.quickviewhalfwidth input[type="text"] {border:1px solid #D4D4D5;color: #64676A;background-color:#FAFAFA ;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewrow div.quickviewhalfwidth label {color: #444442;}
    div#jsjobs-listpopup div.jsjob-contentarea div.commentrow textarea {border:1px solid #D4D4D5;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewrow div.quickviewfullwidth label {color: #444442;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewrow div.quickviewfullwidth textarea {border:1px solid #D4D4D5;}
    div#jsjobs-listpopup div.jsjob-contentarea div.commentrow label {color: #444442;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewrow {color: #64676A;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewrow span.title {color: #444442;}
    div#jsjobs-wrapper div.viewcompany-upper-wrapper{background:#FAFAFA;color:#64676A;border-bottom:1px solid #D4D4D5; }
    div#jsjobs-wrapper div.viewcompany-upper-wrapper div.viewcompnay-name{color:#444442;}
    div#jsjobs-wrapper div.viewcompany-upper-wrapper div.viewcompnay-url{border-right:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.viewcompany-upper-wrapper div.viewcompnay-url a{color:#00A9E0;}
    div#jsjobs-wrapper div.viewcompany-lower-wrapper div.viewcompany-logo{border:1px solid #D4D4D5;border-left:5px solid #00A9E0;}
    div#jsjobs-wrapper div.viewcompany-lower-wrapper div.viewcompany-data div.data-row{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.viewcompany-lower-wrapper div.viewcompany-data a.contact-detail-button{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-wrapper div.bottombutton{border-top:1px solid #0097C9;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewrow-without-border1 p{border:1px solid #D4D4D5;color: #64676A;}
    div#jsjobs-wrapper div.bottombutton a{background:#F0F0F0;color:#444442;}
    div#jsjobs-wrapper div.bottombutton a:hover{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewupper{background:#FAFAFA;border-bottom:1px solid #D4D4D5;border-top:1px solid #D4D4D5;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewupper span.quickviewcompanytitle a{color: #00A9E0;}
    div#jsjob-contentarea div.quickviewupper span.quickviewhalfwidth:first-child{border-right:1px solid #D4D4D5;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower span.quickviewtitle{border-bottom:3px solid #00A9E0;background:#FAFAFA;color: #444442;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewrow{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewbutton a.quickviewbutton{background:#F0F0F0;color:#64676A;border:1px solid #D4D4D5;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewbutton a#apply-now-btn{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewbutton a.quickviewbutton.login{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewbutton a.quickviewbutton.login:hover{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewbutton a.quickviewbutton:hover{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewbutton a#apply-now-btn.quickviewbutton.applyvisitor{background:#79b32b;color:#FFFFFF;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewbutton a.resumeaddlink{background: #F0F0F0;color:#444442;border:1px solid #D4D4D5;}
    div#jsjobs-listpopup span.no-resume-span{background: #FAFAFA;border:1px solid #D4D4D5; color:#64676A;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewlower div.quickviewbutton a#apply-now-btn.quickviewbutton.applyvisitor:hover{background:#79b32b;color:#FFFFFF;}
    div#jsjobs-listpopup a.no-resume-link{float:left;width:100%;display:inline-block;color:#0097C9;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewupper span.quickviewhalfwidth{color:#64676A;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewupper span.quickviewhalfwidth-right{color:#64676A;border-right:1px solid #D4D4D5; }
    div#jsjob-search-popup div.js-searchform-value input {border:1px solid #D4D4D5;color: #64676A}
    div#jsjob-search-popup div.js-searchform-title {color:#444442; }
    div#jsjobs-popup{background: #ffffff;border-bottom:10px solid #00A9E0;}
    div#jsjobs-popup span.popup-title{background-color: #00A9E0;color: #FFFFFF;}
    div#jsjobs-popup div.popup-row{border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-popup div.popup-row:first-child{border-top: 1px solid #D4D4D5;}
    div#jsjobs-popup div.popup-row.button a.proceed{color:#FFFFFF;border:1px solid #D4D4D5;background-color:#00A9E0;}
    div#jsjobs-popup div.popup-row.button a.cancel{color:#444442;border:1px solid #D4D4D5;background-color:#F0F0F0;}
    div#jsjobs-popup div.popup-row span.title{color:#444442;}
    div#jsjobs-popup div.popup-row span.value{color:#64676A;}
    div#jsjobs-wrapper div.department-content-data{border:1px solid #D4D4D5;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.department-content-data span.upper-app-title{color:#444442;}
    div#jsjobs-wrapper div.department-content-data div.data-upper{border-bottom:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div.department-content-data div.data-icons img.icon-img {border:1px solid #D4D4D5;background-color:#F0F0F0;}
    div#jsjobs-wrapper div.department-content-data div.data-icons{border-left:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.department-content-data div.data-lower a{color:#0097C9;}
    div#jsjobs-wrapper div.department-content-data div.data-lower span.lower-text1 a{color:#0097C9;}
    div#jsjobs-wrapper div.department-content-data div.data-lower span.title{color:#444442;}
    div#jsjobs-wrapper div.department-content-data div.data-lower span.get-status.red{color: #E22828;}
    div#jsjobs-wrapper div.department-content-data div.data-lower span.get-status.green{color: #87D554;}
    div#jsjobs-wrapper div.department-content-data div.data-lower span.get-status.orange{color: #FF9900;}
    div#jsjobs-wrapper div#department-name {border-bottom:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div#department-company{border-bottom:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div#department-disc{border-bottom:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper span.view-department-title{color:#444442;}
    div#jsjobs-wrapper span.wrapper-text{color:#64676A;}
    div#jsjobs-wrapper span.wrapper-text1{color:#64676A;}
    div#jsjobs-wrapper div.cover-letter-content-data{border:1px solid #D4D4D5;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.cover-letter-content-data span.datecreated{color:#444442;border-left:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.cover-letter-content-data div.data-upper{color:#64676A;}
    div#jsjobs-wrapper div.cover-letter-content-data div.data-icons img.icon-img {border:1px solid #D4D4D5;background-color:#F0F0F0;}
    div#jsjobs-wrapper div.cover-letter-content-data div.data-icons{border-left:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#cover-letter-wrapper-title {border-bottom:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div#cover-letter-wrapper-disc{border-bottom:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper span.cover-letter-title{color:#444442;}
    div#jsjobs-wrapper span.wrapper-text{color:#64676A;}
    div#jsjobs-wrapper span.wrapper-text1{color:#64676A;}
    div#jsjobs-wrapper div.type-wrapper div.jobs-by-type-wrapper{border: 1px solid #D4D4D5; background: #FAFAFA;color: #64676A;font-size: 14px;}
    div#jsjobs-wrapper div.type-wrapper div.jobs-by-type-wrapper:hover{border-color: #00A9E0; cursor: pointer;}
    div#jsjobs-wrapper div.type-wrapper span.totat-jobs:hover{border-color: #00A9E0; cursor: pointer;}
    div#jsjobs-wrapper div#popup-main div#popup-bottom-part {color: #64676A;}
    div#jsjobs-wrapper div#my-jobs-header ul li{border: 1px solid #D4D4D5;color:#FFFFFF;background-color:#444442;}
    div#jsjobs-wrapper div#my-jobs-header ul li a{color:#FFFFFF}
    div#jsjobs-wrapper div ul li a.selected{background-color:#00A9E0}
    div#jsjobs-wrapper div.my-jobs-data{border:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div.my-jobs-data span.fir a{background-color:white;border:2px solid #D4D4D5;border-left:4px solid #00A9E0;}
    div#jsjobs-wrapper div.my-jobs-data div.data-bigupper div.big-upper-upper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-jobs-data div.data-bigupper span.title {color:#444442;}
    div#jsjobs-wrapper div.my-jobs-data div.data-bigupper div.big-upper-upper a{color: #00A9E0;}
    div#jsjobs-wrapper div.my-jobs-data div.data-bigupper div.big-upper-upper div.headingtext{color:#0097C9;}
    div#jsjobs-wrapper div.my-jobs-data div.data-bigupper span.bigupper-jobtotal {color:#64676A;background-color:#FAFAFA;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-jobs-data div.data-big-lower {background-color:#FAFAFA;border-top:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-jobs-data div.data-big-lower img.big-lower-img {background-color:#FAFAFA;}
    div#jsjobs-wrapper div.my-jobs-data div.data-bigupper a{color:#00A9E0;}
    div#jsjobs-wrapper div.my-jobs-data div.data-bigupper div.big-upper-upper span.title{color:#444442;}
    div#jsjobs-wrapper div.my-jobs-data div.data-big-lower div.big-lower-data-icons img.icon-img {border:1px solid #D4D4D5;background-color:#F0F0F0;}
    div#jsjobs-wrapper div.my-jobs-data div.data-big-lower div.big-lower-data-icons span.icon-text-box{border:1px solid #D4D4D5;background-color:#F0F0F0;}
    div#jsjobs-wrapper div.my-jobs-data div.data-big-lower div.big-lower-data-icons span.icons-resume{color:#FFFFFF; background-color:#00A9E0; border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-jobs-data div.data-bigupper div.big-upper-upper span.buttonu {color:#64676A;background-color:#FAFAFA;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#my-jobs-header ul li img#posted-img{border:1px solid white;}
    div#jsjobs-wrapper div#my-jobs-header ul li:hover{background-color:#00A9E0;}
    div#jsjobs-wrapper div.search-wrapper-content-data{border:1px solid #D4D4D5;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.search-wrapper-content-data span.upper-app-title{color:#444442;border-right:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.search-wrapper-content-data div.data-upper{color:#64676A;}
    div#jsjobs-wrapper div.search-wrapper-content-data div.data-icons img.icon-img {border:1px solid #D4D4D5;background-color:#F0F0F0;}
    div#jsjobs-wrapper div.search-wrapper-content-data div.data-icons{border-left:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#my-resume-header ul li{border: 1px solid #D4D4D5;color:#FFFFFF;background-color:#444442;} div.my-resume-data{border:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div.my-resume-data span.fir a {background-color:white;border:2px solid #D4D4D5;border-left:4px solid #00A9E0;}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper div.big-upper-upper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper div.big-upper-upper span.headingtext{color: #0097C9}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper div.big-upper-upper span.buttonu{color:#64676A;background-color:#FAFAFA;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-resume-data div.data-big-lower {background-color:#FAFAFA;border-top:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-resume-data div.data-big-lower img.big-lower-img {background-color:#FAFAFA;}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper span.title{color:#444442;}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper div.big-upper-upper span.title{color:#444442;}
    div#jsjobs-wrapper div#my-resume-header ul li:hover{background-color:#00A9E0;}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper span.bigupper-jobtotal{background-color:#FAFAFA;border-top:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-resume-data div.data-big-lower div.big-lower-data-icons img.icon-img {border:1px solid #D4D4D5;background-color:#FAFAFA;}
    div#jsjobs-wrapper div#my-resume-header ul li img#posted-img{border:1px solid white;}
    div#jsjobs-wrapper div#my-resume-header ul li a{color:#FFFFFF;}
    div#jsjobs-wrapper div#my-resume-header ul li a:focus{background-color:#00A9E0}
    div#jsjobs-wrapper div.my-resume-data div.data-big-lower div.big-lower-data-icons span.icon-text-box{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-resume-data div.data-big-lower div.big-lower-data-icons span.icons-resume{color:white;background-color:#2993CF;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper div.big-upper-lower div.big-upper-lower1 span.lower-upper-title{color:#64676A;}
    div#jsjobs-wrapper div.message-content-data{border:1px solid #D4D4D5;background-color:#FAFAFA;color:#64676A;}
    div#jsjobs-wrapper div.message-content-data div.data-left span.upper{border-bottom:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div.message-content-data div.data-left span.lower{color:#64676A;}
    div#jsjobs-wrapper div.message-content-data div.data-left{border-right:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.message-content-data div.data-left span.title{color:#444442;}
    div#jsjobs-wrapper div.message-content-data div.data-left span.lower a { color:#00A9E0}
    div#jsjobs-wrapper div.message-content-data div.data-right a.text-right{border:1px solid #D4D4D5;background-color:#F0F0F0;color:#64676A;}
    div#jsjobs-wrapper div.message-content-data div.data-right a.text-right:hover{background-color:#0097C9;color:#FFFFFF;}
    div#jsjobs-wrapper div.credit-wrapper{border-bottom: 1px solid #00A9E0;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data{border: 1px solid #D4D4D5;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-top{border-bottom: 1px solid #D4D4D5;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-top span.top-left{color:#444442;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-top span.right-discount{background-color:#3AB31B;color:white;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-top span.top-right span.discounted-amount{text-decoration-color:red;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-top span.top-right span.net-amount{background-color: #00A9E0;color:#FFFFFF;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-middle{border-bottom: 1px solid #D4D4D5;color:#444442;background-color:#ffffff;}
    div#jsjobs-wrapper div.credit-log-wrapper span.desc a{color:#00A9E0;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-middle span.middle-right{color: #444442;border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-bottom {color: #64676A;border-bottom: 1px solid #D4D4D5;background-color:#FAFAFA; }
    div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.bottom-expiry {color: #64676A;border-bottom:1px solid #D4D4D5; background-color:#FAFAFA;}
    div#jsjobs-wrapper div.purchase-history-wrapper {border-top: 1px solid #00A9E0;}
    div#jsjobs-wrapper div.purchase-history-wrapper:last-child{border-bottom: 1px solid #00A9E0;}
    div#jsjobs-wrapper div.purchase-history-wrapper div.purchase-history-data{border: 1px solid #D4D4D5;color:#444442;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.purchase-history-wrapper div.purchase-history-data span.data-credit{border-top: 1px solid #D4D4D5;border-bottom: 1px solid #D4D4D5;color:#444442;background: #FFF;}
    div#jsjobs-wrapper div.purchase-history-wrapper div.purchase-history-data span.data-price{color:#444442;}
    div#jsjobs-wrapper div.purchase-history-wrapper div.purchase-history-data span.data-price span.amount{color:#FFFFFF;background: #00A9E0;}
    div#jsjobs-wrapper div.purchase-history-wrapper div.purchase-history-data span.data-created{color:#64676A;}
    div#jsjobs-wrapper div.purchase-history-wrapper div.purchase-history-data span.data-status{border-left:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.purchase-header div.total img{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.purchase-header div.spent img{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.purchase-header div.remaining img{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.purchase-header div.total{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.purchase-header div.spent{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.purchase-header div.remaining{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.purchase-header span.text{color:#444442;}
    div#jsjobs-wrapper div.purchase-header span.number{color:#444442;}
    div#jsjobs-wrapper div.page_heading span.expire {border: 1px solid #00A9E0;color:#444442;background-color:#FAFAFA;border-bottom:none;}
    div#jsjobs-wrapper div.log-header{border-bottom: 1px solid #00A9E0;}
    div#jsjobs-wrapper div.log-header div.total img{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.log-header div.spent img{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.log-header div.remaining img{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.log-header div.total{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.log-header div.spent{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.log-header div.remaining{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.log-header span.text{color:#444442;}
    div#jsjobs-wrapper div.log-header span.number{color:#444442;}
    div#jsjobs-wrapper div.credit-log-wrapper{border: 1px solid #D4D4D5;color:#444442;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.credit-log-wrapper { background-color: #FAFAFA;border: 1px solid #D4D4D5;color:#444442;}
    div#jsjobs-wrapper div.credit-log-wrapper span.date-time{border-right: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.credit-log-wrapper span.desc{border-left: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.credit-log-wrapper span.cost{color:#FFFFFF;background-color:#00A9E0;}
    div#jsjobs-wrapper input#save{background:none; color:#FFFFFF;background-color:#00A9E0;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#comments textArea {border:1px solid #D4D4D5}
    div#jsjobs-wrapper div#comments div.email-feilds input {border:1px solid #D4D4D5}
    div#jsjobs-wrapper span#popup_coverletter_title{border-bottom: 1px solid #D4D4D5;color: #444442;}
    div#jsjobs-wrapper div#popup-main div#popup-bottom-part{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#popup-main-outer{background-color: #FFFFFF;}
    div#jsjobs-wrapper div#popup-main{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#popup-main span.popup-top{width:100%;display:inline-block;background-color:#00A9E0;color:#FFFFFF; }
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower div.company-detail-lower-left span.js-text{color:#00A9E0;}
    div#jsjobs-wrapper span#popup-coverletter_title{border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#popup-main span.popup-top span#popup_title{color:#FFFFFF;}
    div#jsjobs-wrapper div#popup-main div#popup-bottom-part{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#popup-main-outer{background-color: #FFFFFF;}
    div#jsjobs-wrapper div#popup-main{border:1px solid #FFFFFF;}
    div#jsjobs-wrapper span#popup-coverletter_title{border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#popup-main span.popup-top span#popup_title{color:#FFFFFF;}
    div#jsjobs-wrapper div#save-button{border-top:2px solid #0097C9;} 
    div#jsjobs-wrapper div#send-message-wrapper div.top-data {border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#send-message-wrapper div.top-data span.data-right-part span.right-top {border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#send-message-wrapper div.top-data span.data-right-part {color:#64676A;}
    div#jsjobs-wrapper div#send-message-wrapper div.top-data span.top-data-img div{border:1px solid #D4D4D5;border-left:4px solid #00A9E0;}
    div#jsjobs-wrapper div#send-message-wrapper div.top-data span.title{color:#444442;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-subject span.subject-text{color:#64676A;background-color:#FAFAFA;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-subject span.subject{color:#444442;}
    div#jsjobs-wrapper div#send-message-wrapper div.top-data span.data-right-part a{color:#00A9E0;}
    div#jsjobs-wrapper div#send-message-wrapper span.history-title{color:#FFFFFF;background-color:#444442;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-history span.message-my{border:1px solid #D4D4D5;background-color:#FAFAFA;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-history span.message-my.mesend{background-color:#FFFFFF;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-history span.message-my span.message-created{color:#64676A;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-history span.message-my span.message-desc{color:#64676A;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-history span.message-my span.message-data span.message-title{color:#444442;background-color:#FAFAFA;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-history span.message-my span.message-other span.message-title{color:#FFFFFF;background-color:#00A9E0;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#send-message-wrapper div.message-history span.message-my span.message-admin span.message-title {color: #FFFFFF;background-color: #444442;border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#comments{border-top:1px solid #D4D4D5;}
    div.js_job_error_messages_wrapper{border:1px solid #00A9E0; color: #FFFFFF;background:#ffffff;}
    div.js_job_error_messages_wrapper div.message2{box-shadow: 0px 3px 3px 2px #D4D4D5; background:#00A9E0; color: #FFFFFF;}
    div.js_job_error_messages_wrapper div.message3{box-shadow: 0px 3px 3px 2px #D4D4D5; background:#B81D20; color: #FFFFFF;}
    div.js_job_error_messages_wrapper div.footer{background: #FAFAFA; border-top: 1px solid #D4D4D5;}
    div.js_job_error_messages_wrapper div.message1 span{ font-size: 30px; font-weight: bold;color:#444442}
    div.js_job_error_messages_wrapper div.message2 span.img{border:1px solid #00A9E0;}
    div.js_job_error_messages_wrapper div.message2 span.message-text{font-size: 24px; font-weight: bold; }
    div.js_job_error_messages_wrapper div.message3 span.img{border:1px solid #00A9E0;}
    div.js_job_error_messages_wrapper div.message3 span.message-text{font-size: 24px; font-weight: bold; }
    div.js_job_error_messages_wrapper div.footer a{background: #F0F0F0; color:#444442 !important;border: 1px solid #D4D4D5; font-size: 16px;}
    div.js_job_error_messages_wrapper div.footer a:hover{background: #00A9E0; color:#FFFFFF !important;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower span.js-get-title{color:#444442;}
    div#jsjobs-wrapper div.credits-log-wrapper div.credits-log-header{border-bottom: 1px solid #00A9E0;}
    div#jsjobs-wrapper div.credits-log-wrapper div.credits-log-header div.block{background: #FAFAFA; border: 1px solid #D4D4D5; border-radius: 5px;}
    div#jsjobs-wrapper div.credits-log-wrapper div.credits-log-header div.block img{border-radius: 3px;}
    div#jsjobs-wrapper div.credits-log-wrapper div.credits-log-header div.block span.figure{font-size: 22px; display: inline-block; text-align: left; font-weight: bold; color: #64676A;}
    div#jsjobs-wrapper div.credits-log-wrapper div.credits-log-header div.block span.text{font-size: 22px;  color: #64676A; display: inline-block; text-align: left;}
    div#jsjobs-wrapper div.credits-log-wrapper div.log-list-wrapper{background: #FAFAFA; border: 1px solid #D4D4D5;font-size: 20px;  color: #64676A;}
    div#jsjobs-wrapper div.credits-log-wrapper div.log-list-wrapper span:nth-child(1){border-right: 2px solid #D4D4D5;}
    div#jsjobs-wrapper div.credits-log-wrapper div.log-list-wrapper span.upper{border-right: 2px solid #D4D4D5;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-upper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower div.company-detail-lower-left {color:#64676A;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower div.company-detail-lower-left span.js-text{color:#444442;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower div.company-detail-lower-left span.category-text{color: #444442;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower div.company-detail-lower-right span.status-text{color: #444442;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower div.company-detail-lower-left span.get-category{color: #64676A;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-upper span.company-date{color: #64676A;}
    div#jsjobs-wrapper div.company-wrapper div.company-lower-wrapper span.company-address{color:#64676A;}
    div#jsjobs-wrapper div.page_heading{color:#444442;border-bottom:2px solid #0097C9;}
    div#jsjobs-wrapper span.applied-resume-count{background-color: #FAFAFA;color: #444442;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.company-wrapper{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-img a{ border: 1px solid #D4D4D5; border-left: 4px solid #00A9E0; background-color: white;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.company-wrapper div.company-lower-wrapper div.company-lower-wrapper-right div.button{ border: 1px solid; border-color: #D4D4D5; background-color: #F0F0F0; }
    div#jsjobs-wrapper div.company-wrapper div.company-lower-wrapper{background: #FAFAFA;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-upper div.company-detail-upper-left span.gold{background: #CC9900; color: white; border-radius: 6px; font-weight: bold; font-size: 10px;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower div.company-detail-lower-right span.get-status.red{color:  #E22828;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower div.company-detail-lower-right span.get-status.green{color: #87D554;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-upper-wrapper div.company-detail div.company-detail-upper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower span.website-url-text{font-weight: bold; color: #444442;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-upper-wrapper div.company-detail div.company-detail-lower a.get-website-url{ color: #00A9E0; text-decoration: none;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-lower-wrapper span.company-address{color:#64676A;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-upper-wrapper div.company-img a{border: 1px solid #D4D4D5; border-left: 4px solid #00A9E0; background-color: white;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-upper-wrapper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-lower-wrapper div.company-lower-wrapper-right a.viewall-jobs{border: 1px solid #D4D4D5;background-color: #F0F0F0; font-size: 12px;color: #444442;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-lower-wrapper div.company-lower-wrapper-right a.viewall-jobs:hover{color: 1px solid #D4D4D5; background-color: #00A9E0;color: #FFFFFF;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-lower-wrapper{background: #FAFAFA;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-upper-wrapper div.company-detail div.company-detail-upper span.gold{background: #CC9900; color: white; border-radius: 6px; font-weight: bold; font-size: 10px;}
    div#jsjobs-wrapper div#companies-wrapper div.view-companies-wrapper div.company-upper-wrapper div.company-detail div.company-detail-upper span.feature{background: #2993CF; color: white; border-radius: 4px; font-weight: bold; font-size: 10px; padding: 1px;}
    div#jsjobs-wrapper div#companies-wrapper div.filter-wrapper{border-bottom: 2px solid #0097C9;}
    div#jsjobs-wrapper div.folder-wrapper{border:1px solid #D4D4D5; background: #FAFAFA;}
    div#jsjobs-wrapper div.folder-wrapper{display: inline-block; width: 100%;}
    div#jsjobs-wrapper div.folder-wrapper div.folder-firsl{border-right: 1px solid #D4D4D5 ;}
    div#jsjobs-wrapper div.folder-wrapper div.folder-firsl span{color:#444442 ; font-size: 13px; font-weight: bold;}
    div#jsjobs-wrapper div.folder-wrapper div.folder-second span{color:#444442 ; font-size: 14px; font-weight: bold;}
    div#jsjobs-wrapper div.folder-wrapper div.folder-second span.get-status.red{ color: #E22828}
    div#jsjobs-wrapper div.folder-wrapper div.folder-second span.get-status.green{ color: #87D554}
    div#jsjobs-wrapper div.folder-wrapper div.folder-second span.get-status.orange{ color: #FF9900}
    div#jsjobs-wrapper div.folder-wrapper div.folder-second{border-right: 1px solid #D4D4D5 ;}
    div#jsjobs-wrapper div.folder-wrapper div.folder-third div.button-section div.button{ border: solid 1px #D4D4D5; background: #F0F0F0;}
    div#jsjobs-wrapper div.folder-wrapper div.folder-third div.button-section div.button a{color: #64676A; font-size: 14px;}
    div#jsjobs-wrapper div.folder-wrapper div.folder-third div.button-section div.button a:hover{color: #FFFFFF;}
    div#jsjobs-wrapper div.folder-wrapper div.folder-third div.button-section div.resume-button:hover{background: #00A9E0; color: #FFFFFF;}
    div#jsjobs-wrapper div.resume-save-search-wrapper{border:1px solid #D4D4D5;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.resume-save-search-wrapper span.upper-app-title{color:#444442;border-right:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.data-upper{color:#64676A;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.data-icons img.icon-img {border:1px solid #D4D4D5;background-color:#F0F0F0;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.data-icons{border-left:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.resume-save-search-wrapper{border:1px solid #D4D4D5; background: #FAFAFA;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.div-left{border-right: 1px solid #D4D4D5 ;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.div-left span{color:#444442 ; font-size: 14px; font-weight: bold;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.div-middel span.created-text{color:#444442 ; font-size: 14px; font-weight: bold;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.div-middel span.get-resume-date{color:#444442 ; font-size: 14px;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.div-middel{border-right: 1px solid #D4D4D5 ;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.div-right div.button{ border: solid 1px #D4D4D5; background: #F0F0F0;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.div-right div.button a{color: #64676A; font-size: 14px;}
    div#jsjobs-wrapper div.resume-save-search-wrapper div.div-right div.button:hover{background: #00A9E0; color: #FFFFFF;} 
    div#jsjobs-wrapper div.view-folder-wrapper div.name{border-bottom: 1px solid #D4D4D5; font-size: 16px;}
    div#jsjobs-wrapper div.view-folder-wrapper div.name span.name-text{color: #444442; font-weight: bold;}
    div#jsjobs-wrapper div.view-folder-wrapper div.name span.get-name{color: #64676A;}
    div#jsjobs-wrapper div.view-folder-wrapper div.description{border-bottom: 1px solid #D4D4D5; font-size: 16px;}
    div#jsjobs-wrapper div.view-folder-wrapper div.description span.description-text{ color: #444442; font-weight: bold; }
    div#jsjobs-wrapper div.view-folder-wrapper div.description span.get-description{color: #64676A; }
    div#jsjobs-wrapper div.jobs-by-categories-wrapper{border: 1px solid #D4D4D5; background: #FAFAFA;color: #64676A;font-size: 14px;}
    div#jsjobs-wrapper div.jobs-by-categories-wrapper:hover{border-color: #00A9E0; cursor: pointer;}
    div#jsjobs-wrapper div.jobs-by-categories-wrapper span.total-jobs:hover{border-color: #00A9E0; cursor: pointer;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-navebar ul li{background:#444442; font-size: 14px; color: #FFFFFF;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-navebar ul li a{color: #FFFFFF;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-navebar ul li:hover{background:#00A9E0;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-img a{border:1px solid #D4D4D5; border-left: 6px solid #00A9E0;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-upper{border-bottom:1px solid  #D4D4D5;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-upper div.job-detail-upper-left a{color:#00A9E0;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail-upper div.job-detail-upper span.job-date{color: #FAFAFA}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-upper span.time-of-job{border: 1px solid #D4D4D5;background: #FAFAFA;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-upper span{color: #64676A;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-lower-wrapper span.company-address{color:#64676A;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.company-img{ border: 1px solid #D4D4D5; border-left: 6px solid #00A9E0; background-color: white;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.shortlist{color: #FFFFFF;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-lower-wrapper{background: #FAFAFA;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list span.heading{color: #444442}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list  div#full-width-top{border-top: 1px solid #D4D4D5}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list span.get-text{color: #64676A}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list span.get-text a{color: #00A9E0}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-left:#444442;font-size: 14px;font-weight: bold;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-left color: #64676A;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.heading{color:#444442;font-size: 14px;font-weight: bold;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.get-text{color: #64676A;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.btn-shortlist a{background: #00A9E0; font-size: 14px; text-decoration: none; color: #FFFFFF;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-lower-wrapper div.button{background: #00A9E0; font-size: 14px; text-decoration: none; color: #FFFFFF;}
    div#jsjobs-wrapper div#my-applied-jobs-wrraper div#my-applied-jobs-list div.jobs-lower-wrapper a.applied-info-button{border:1px solid #D4D4D5;background: #F0F0F0;color:#444442;}
    div#jsjobs-wrapper div#folder-resume-wrapper{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-img{border:1px solid #D4D4D5; border-left: 6px solid #00A9E0;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-upper{border-bottom:1px solid  #D4D4D5;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-upper div.job-detail-upper-left a{color:#00A9E0;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail-upper div.job-detail-upper span.job-date{color: #FAFAFA}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-upper span.time-of-job{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-upper span{color: #64676A;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-lower-wrapper span.company-address{color:#64676A;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.company-img{ border: 1px solid #D4D4D5; border-left: 6px solid #00A9E0; background-color: white;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right a{background: #00A9E0; color: #FFFFFF;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-lower-wrapper{background: #FAFAFA;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-left span.heading{color:#444442;font-size: 14px;font-weight: bold;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-left span.get-text{color: #64676A;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.heading{color:#444442;font-size: 14px;font-weight: bold;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.get-text{color: #64676A;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.btn-shortlist a{background: #00A9E0; font-size: 14px; text-decoration: none; color: #FFFFFF;}
    div#jsjobs-wrapper div#folder-resume-wrapper div.jobs-lower-wrapper div.jobs-lower-wrapper-right div.button a{background: #00A9E0; font-size: 14px; text-decoration: none; color: #FFFFFF;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper{border:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.jsdata-icon a{background-color:white;border:2px solid #D4D4D5;border-left:6px solid #00A9E0;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-bigupper div.big-upper-upper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-bigupper div.comments{ background: #FAFAFA; color: #64676A; border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-bigupper div.big-upper-upper span.headingtext{color:blue;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-bigupper div.big-upper-upper span.buttonu{border: 1px solid #D4D4D5;color: #444442;background-color:#FAFAFA;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-big-lower {background-color:#FAFAFA;border-top:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-big-lower img.big-lower-img {background-color:#FAFAFA;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-bigupper span.title{color:#444442;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-bigupper div.big-upper-upper span.title{color:#444442;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-bigupper span.bigupper-jobtotal{background-color:#FAFAFA;border-top:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-big-lower div.big-lower-data-icons a.btn {border:1px solid #D4D4D5;background-color:#F0F0F0; color: #444442;}
    div#jsjobs-wrapper div.jsjobs-shorlisted-wrapper div.data-big-lower div.big-lower-data-icons a.btn:last-child{background-color:#00A9E0; color: #FFFFFF;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list-navebar ul li{background:#444442; font-size: 14px; color: #FFFFFF;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list-navebar ul li:hover{background:#00A9E0;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-img a{border:1px solid #D4D4D5; border-left: 6px solid #00A9E0;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-upper{border-bottom:1px solid  #D4D4D5;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-upper div.resume-detail-upper-left a{color:#00A9E0;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail-upper div.resume-detail-upper span.resume-date{color: #FAFAFA;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-upper span.time-of-resume{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-upper span{color: #64676A;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-lower-wrapper span.company-address{color:#64676A;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.company-img{ border: 1px solid #D4D4D5; border-left: 6px solid #00A9E0; background-color: white;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-lower div.resume-detail-lower-right a{background: #00A9E0; color: #FFFFFF;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-lower-wrapper{background: #FAFAFA;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-lower span.get-text{color: #64676A;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-lower div.resume-detail-lower-left span.heading{color:#444442;font-size: 14px;font-weight: bold;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-lower div.resume-detail-lower-left span.get-text{color: #64676A;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-lower div.resume-detail-lower-right span.heading{color:#444442;font-size: 14px;font-weight: bold;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-lower div.resume-detail-lower-right span.get-text{color: #64676A;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-upper-wrapper div.resume-detail div.resume-detail-lower div.resume-detail-lower-right span.btn-shortlist a{background: #00A9E0; font-size: 14px; text-decoration: none; color: #FFFFFF;}
    div#jsjobs-wrapper div#resume-list-wrraper div#resume-list div.resume-lower-wrapper div.resume-lower-wrapper-right div.button a{background: #00A9E0; font-size: 14px; text-decoration: none; color: #FFFFFF;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-navebar ul li{background:#444442; font-size: 14px; color: #FFFFFF;}
    div#jsjobs-wrapper div#comments span.detail span.heading{color:#444442;}
    div#jsjobs-wrapper div#comments span.detail{color:#64676A;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-navebar ul li:hover{background:#00A9E0;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-navebar ul li a:focus{background:#00A9E0;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-inner-navebar ul li{background:#F0F0F0; }
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-inner-navebar ul li a{font-size: 16px; color: #444442; text-decoration:none; padding: 10px 20px;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-inner-navebar ul li a:hover{background:#00A9E0; color: #FFFFFF;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-inner-navebar ul li a.selected{background:#00A9E0; color: #FFFFFF;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume{border:1px solid #D4D4D5; }
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-upper-left div.job-img{border:2px solid #00A9E0; border-radius: 200px; box-shadow: 0px 0px 10px #ECECEC;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-upper{border-bottom:1px solid  #D4D4D5;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-upper div.job-detail-upper-left{color:#00A9E0;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail-upper div.job-detail-upper span.job-date{color: #FAFAFA}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-upper span.time-of-job{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-upper span.created{font-weight: bold;color:#444442;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-upper span.job-title{color: #00A9E0;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-upper span.job-date{color: #64676A}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-lower-wrapper span.company-address{color:#64676A;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.company-img{ border: 1px solid #D4D4D5; border-left: 6px solid #00A9E0; background-color: white;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper{}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right a{background: #00A9E0; color: #FFFFFF;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-lower-wrapper{background: #FAFAFA;border-top:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-left span.heading{color:#444442;font-size: 14px;font-weight: bold;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-left span.get-text{color: #64676A;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.heading{color:#444442;font-size: 14px;font-weight: bold;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.get-text{color: #64676A;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.job-detail-lower-right span.btn-shortlist a{background: #00A9E0; font-size: 14px; text-decoration: none; color: #FFFFFF;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.notes{background: #F0F0F0; color: #444442; border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-lower-wrapper{background: #FAFAFA;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-lower-wrapper div.buttons a{background: #F0F0F0; color: #444442; border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-upper-left div.anchor a.view-resume{background: #00A9E0; color: #FFFFFF; border-radius: 5px; text-decoration: none;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-upper-left div.anchor a.view-coverletter{background: #FFFFFF; color: #444442; border:2px solid #00A9E0;  border-radius: 5px; text-decoration: none;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-inner-navebar{border-bottom: 2px solid #00A9E0;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-upper-left div.job-img img{border: 1px solid #D4D4D5; border-radius: 50%;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume-inner-navebar a.export-all{ border-radius: 3px; border: 1px solid #D4D4D5; background: #FAFAFA; color: #64676A;}
    div#jsjobs-wrapper div.view-resume-wrapper div.most-upper-wrapper div.img{border: 1px solid #D4D4D5; border-left: 6px solid #0097C9; }
    div#jsjobs-wrapper div.view-resume-wrapper div.most-upper-wrapper div.right-upper-wrapper div.inner-upper{border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.view-resume-wrapper div.most-upper-wrapper div.right-upper-wrapper div.inner-lower div.text{color: #64676A;}
    div#jsjobs-wrapper div.view-resume-wrapper div.most-upper-wrapper div.right-upper-wrapper div.inner-lower div.btn span:hover{cursor: pointer;}
    div#jsjobs-wrapper div.view-resume-wrapper div.most-upper-wrapper div.right-upper-wrapper div.inner-lower div.btn span.grayBtn{background: #F0F0F0; color: #444442; border:1px solid #D4D4D5; font-size: 14px;}
    div#jsjobs-wrapper div.view-resume-wrapper div.most-upper-wrapper div.right-upper-wrapper div.inner-lower div.btn span.blueBtn{background: #00A9E0; color: #FFFFFF; font-size: 14px;}
    div#jsjobs-wrapper div.view-resume-wrapper div.most-upper-wrapper div.right-upper-wrapper div.inner-upper span{color: #444442; font-size: 16px; font-weight: bold;}
    div#jsjobs-wrapper div.view-resume-wrapper div.main-heading{border-bottom: 2px solid #00A9E0;}
    div#jsjobs-wrapper div.view-resume-wrapper div.innerHeading{border-bottom: 2px solid #00A9E0;}
    div#jsjobs-wrapper div.view-resume-wrapper div.main-heading img.heading-img{background: #00A9E0;}
    div#jsjobs-wrapper div.view-resume-wrapper div.main-heading span{font-size: 20px; font-weight: bold; color: #444442;}
    div#jsjobs-wrapper div.view-resume-wrapper div.innerHeading span{font-size: 16px; font-weight: bold; color: #444442;}
    div#jsjobs-wrapper div.view-resume-wrapper div.detail{border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.view-resume-wrapper div.detail span.heading{ font-size: 16px; color: #444442;}
    div#jsjobs-wrapper div.view-resume-wrapper div.detail span.txt{font-size: 16px; color: #64676A;}
    div#jsjobs-wrapper div.view-resume-wrapper div.detail-blueBorder span.heading{ font-size: 16px; color: #444442;}
    div#jsjobs-wrapper div.view-resume-wrapper div.detail-blueBorder span.txt{font-size: 16px; color: #64676A;}
    div#jsjobs-wrapper div.view-resume-wrapper div.detail-blueBorder{border-bottom: 1px solid #00A9E0;}
    div#jsjobs-wrapper div.view-resume-wrapper div.btnSection{border: 1px solid #D4D4D5; background: #F0F0F0; color: #444442; font-size: 16px;}
    div#jsjobs-wrapper div.view-resume-wrapper div.btnSection:hover{color: #FFFFFF; background: #00A9E0; cursor: pointer;}
    div#jsjobs-wrapper div.view-resume-wrapper div.resume-page{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.view-resume-wrapper div.skills-page{border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.control-pannel-header{border-bottom:2px solid #0097C9;}
    div#jsjobs-wrapper div.control-pannel-header span.heading{color: #444442;}
    div#jsjobs-wrapper div.control-pannel-header span.notify img:hover{cursor: pointer;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.control-pannel-categories{background: #FAFAFA; }
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.left div.show-items{background: #FAFAFA;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.left div.show-items div.job-wrapper div.img a{border: 1px solid #D4D4D5; border-left: 6px solid #00A9E0;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.left div.show-items div.job-wrapper{border: 1px solid #D4D4D5; background: #FFFFFF;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.left div.show-items div.job-wrapper div.upper{border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.left div.show-items div.job-wrapper div.upper a{background:none;color: #444442; text-decoration: none; font-size: 16px; }
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.left div.show-items div.job-wrapper div.lower span{color: #64676A;  font-size: 14px; }
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items{background: #FAFAFA;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper{background: #ffffff;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.img a{border: 1px solid #D4D4D5; border-left: 6px solid #00A9E0;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper{border: 1px solid #D4D4D5; background: #FFFFFF;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.upper{border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.upper a{background:none;color: #00A9E0; text-decoration: none; font-size: 16px; }
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.header{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.lower div.resume {color: #64676A;  font-size: 14px;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.lower div.email span.heading{color: #444442;  font-size: 14px; font-weight: bold;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.lower div.category span.heading{color: #444442;  font-size: 14px; font-weight: bold;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.lower div.email span.get-text{color: #64676A;  font-size: 14px;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.lower div.category span.get-text{color: #64676A;  font-size: 14px;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.extra-activities div.right div.show-items div.job-wrapper div.footer{background: #FAFAFA; color: #64676A;}

    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.messages{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.messages div.heading{background: #FAFAFA; color: #444442; border-bottom: 1px solid #D4D4D5; font-weight: bold;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.messages div.message{border-bottom: 1px solid #D4D4D5; color: #64676A; background: #FAFAFA;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.control-pannel-header{border-bottom: 2px solid #00A9E0;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.control-pannel-header span.notify span.count_notifications{color: #FFFFFF;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.control-pannel-header span.notify img:hover{cursor: pointer;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.control-pannel-header span.notify span.count_messages{color: #FFFFFF;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.control-pannel-header span.heading{color: #64676A; font-weight: bold;font-size: 18px;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.control-pannel-categories{}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.left{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.right{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.header-left{ color: #FFFFFF; font-weight: bold; font-size: 16px;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper a{ color: #FFFFFF;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.header-right{ color: #FFFFFF;font-weight: bold; font-size: 16px;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper a{ color: #FFFFFF;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.show-items{background: #FAFAFA;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.show-items div.job-wrapper div.img a{border: 1px solid #D4D4D5; border-left: 6px solid #00A9E0;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.show-items div.job-wrapper{border: 1px solid #D4D4D5; background: #FFFFFF;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.show-items div.job-wrapper div.upper{border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.show-items div.job-wrapper div.upper a{background:none;color: #00A9E0; font-weight: bold; text-decoration: none; font-size: 16px; }
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.show-items div.job-wrapper div.lower div.resume_title{color: #64676A;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.show-items div.job-wrapper div.lower span.get-text{color: #64676A;  font-size: 14px; }
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.extra-activities div.detail-wrapper div.show-items div.job-wrapper div.lower span.text{color: #444442;  font-size: 16px; }

    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.notifications{border: 1px solid #D4D4D5;box-shadow: -5px 4px 4px 0 #a9abae;background: #FAFAFA;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.notifications div.message div.title div.heading{color: #444442;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.notifications div.message div.title div.text{color: #64676A;}

    div#jsjobs-wrapper div.js-topstats div.tprow{border:1px solid #D4D4D5; background: #FAFAFA;}
    div#jsjobs-wrapper div.js-topstats div.tprow div.js-headtext{color: #64676A;}
    table#js-table thead.stats tr{background: #FAFAFA;border:1px solid #D4D4D5;}
    table#js-table thead.stats tr th{border-right:1px solid #D4D4D5;color: #444442;background: #FAFAFA;}
    table#js-table thead.stats tr th:last-child{border-right:none;}

    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.notifications{background: #FAFAFA;box-shadow: 0px 0px 18px #a9abae;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.notifications div.heading{color: #444442;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.notifications div.message{background: #ffffff;border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.notifications div.message div.title div.heading{color:#444442;}
    div#jsjobs-wrapper div#jobseeker-control-pannel-wrapper div.notifications div.message div.title div.text{color:#64676A;}

    table#js-table tbody.stats tr td{border:1px solid #D4D4D5; color: #64676A; background: #ffffff;}
    table#js-table tbody.stats tr td{border-right: none;}
    table#js-table tbody.stats tr td:last-child{border-right: 1px solid #D4D4D5;}
    table#js-table tbody.stats tr td.publish{color: #444442;}
    table#js-table tbody.stats tr td.expired{color: #444442;}

    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.notifications div.heading{background: #FAFAFA; color: #444442; border-bottom: 1px solid #D4D4D5; font-weight: bold;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.notifications div.message{border-bottom: 1px solid #D4D4D5; color: #64676A; background: #FAFAFA}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.messages{border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.messages div.heading{background: #FAFAFA; color: #444442; border-bottom: 1px solid #D4D4D5; font-weight: bold;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.messages div.message{border: 1px solid #D4D4D5;box-shadow: -5px 4px 4px 0 #a9abae;background: #FAFAFA;}
    div#jsjobs-wrapper div#employer-control-pannel-wrapper div.messages div.message div.title div.text{color: #64676A}
    div#jsjobs-wrapper div#jsjobs-admin-wrapper div.dashboard span{background: #FFFFFF;border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#jsjobs-admin-wrapper div.dashboard span.heading-dashboard{background: #FFFFFF; border-radius: 5px; color: #64676A; border: 1px solid #D4D4D5; font-weight: bold; font-size: 18px;}
    div#jsjobs-wrapper div#view-job-wrapper div.top{background: #FAFAFA; border-bottom: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.top div.jobname{font-size: 16px; font-weight: bold; color: #444442;}
    div#jsjobs-wrapper div#view-job-wrapper div.top div.inner-wrapper div.jobdetail span.get-text{border-right: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.top div.inner-wrapper div.jobdetail{font-size: 14px;}
    div#jsjobs-wrapper div#view-job-wrapper div.top div.inner-wrapper div.jobdetail span.get-text span.gold{color: #ffffff; font-size: 12px;}
    div#jsjobs-wrapper div#view-job-wrapper div.top div.inner-wrapper div.jobdetail span.get-text span.featured{color: #ffffff; font-size: 12px;}
    div#jsjobs-wrapper div#view-job-wrapper div.top div.inner-wrapper div.jobdetail span.agodays{color: #64676A; }
    div#jsjobs-wrapper div#view-job-wrapper div.top div.inner-wrapper div.jobdetail span.city{color: #64676A; border-right: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.btn-div a.btn{color: #444442; background: #F0F0F0; border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.btn-div a.btn:hover{color: #FFFFFF; background: #00A9E0; border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.btn-div a.btn:focus{color: #FFFFFF; background: #00A9E0; border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.btn-div a.blue{color: #FFFFFF; background: #00A9E0; border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.heading1{color: #444442; background: #FAFAFA; border-bottom: 2px solid #00A9E0; font-size: 16px; font-weight: bold;}
    div#jsjobs-wrapper div#view-job-wrapper div.heading2{color: #444442; background: #FAFAFA; border-bottom: 2px solid #00A9E0; font-size: 16px; font-weight: bold;}
    div#jsjobs-wrapper div#view-job-wrapper div.detail-wrapper{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.left{border-right:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.detail-wrapper span.heading{color: #444442; }
    div#jsjobs-wrapper div#view-job-wrapper div.detail-wrapper span.txt{color: #64676A;}
    div#jsjobs-wrapper div#view-job-wrapper div.peragraph{color: #64676A; border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.apply a.apply-btn {color: #FFFFFF; background: #00A9E0; border-radius: 3px;}
    div#jsjobs-wrapper div#view-job-wrapper div.apply{border-top: 2px solid #00A9E0;}
    div#jsjobs-wrapper div#view-job-wrapper div.fb-heading { color: #FFFFFF;   font-size: 18px;}
    div#jsjobs-wrapper div#view-job-wrapper div.main div.right div.companywrapper{background: #FAFAFA;border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#view-job-wrapper div.main div.right div.company-img{border: 1px solid #D4D4D5;background: #ffffff; border-left: 6px solid #00A9E0;}
    div#jsjobs-wrapper div#view-job-wrapper div.main div.right div.copmany-detail span.heading{color: #444442; font-size: 16px;}
    div#jsjobs-wrapper div#view-job-wrapper div.main div.right div.copmany-detail a.url{color: #00A9E0;}
    div#jsjobs-wrapper div#view-job-wrapper div.main div.right div.copmany-detail span.address{color: #64676A;}
    div#jsjobs-wrapper div#view-job-wrapper div.main div.right div.copmany-detail span.share{color:#64676A;}
    div#jsjobs-wrapper div.company-wrapper div.company-upper-wrapper div.company-detail div.company-detail-upper div.company-detail-upper-left span.company-title a{color: #00A9E0}
    div#js_main_wrapper div.js-resume-section-title{background:#00A9E0;color:#FAFAFA;}
    div#js_main_wrapper div div.js-resume-section-title{background:#0097C9;color:#FAFAFA;}
    div#js_main_wrapper div div.js-resume-section-body{background:#D4D4D5;border:1px solid #64676A;/*color:#FAFAFA;*/}
    div#js_main_wrapper div div.js-resume-field-container{color:#F0F0F0;}
    div#js_main_wrapper div div.js-resume-section-body form div.js-resume-checkbox-container{color:#F0F0F0;border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-field-container div.upload-field{border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-field-container div.files-field{border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-field-container div.files-field div.selectedFiles span.selectedFile{border:1px solid #64676A;background:#D4D4D5;}
    div#js_main_wrapper div div.js-resume-section-body form div.uploadedFiles{border:1px solid #64676A;color:#444442;}
    div#js_main_wrapper div div.js-resume-section-body form div.uploadedFiles span.selectedFile{border:1px solid #64676A;background:#D4D4D5;color:#444442;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-data div div.filesList{border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-data div div.filesList ul li.selectedFile{border:1px solid #64676A;background:#D4D4D5;color:#444442;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-data div div.filesList a.zip-downloader{background:#0097C9;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-field-container span.upload_btn{border:1px solid #64676A;background:#D4D4D5;color:#F0F0F0;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-field-container div.upload-field:hover span.upload_btn{background:#0097C9;color:#FAFAFA;border:1px solid #0097C9;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-field-container div.files-field:hover span.upload_btn{background:#0097C9;color:#FAFAFA;border:1px solid #0097C9;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-field-container ul{border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-show-hide-btn span{border:1px solid #64676A;background:#FFFFFF;color:#444442;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-show-hide-btn span:hover{background:#0097C9;color:#FAFAFA;}
    div#js_main_wrapper div div.js-resume-section-body form div div.loc-field a.map-link{border:1px solid #64676A;background:#D4D4D5;color:#F0F0F0;}
    div#js_main_wrapper div div.js-resume-section-body form div div.loc-field a.map-link:hover{background:#0097C9;color:#FAFAFA;border:1px solid #0097C9;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-submit-container{border-top:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-submit-container button{background:#FFFFFF;border:1px solid #64676A;color:#444442;}
    div#js_main_wrapper div div.js-resume-section-body form div div.js-resume-submit-container button:hover{background:#0097C9;color:#FAFAFA;}
    div#js_main_wrapper div div.js-resume-section-view{color:#FAFAFA;}
    div#js_main_wrapper div div.js-resume-section-body div.js-resume-section-view div.js-resume-profile div img.avatar{border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-profile-info div div.js-resume-profile-name{color:#F0F0F0;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-profile-info div.profile-name-outer{border-bottom:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-profile-info div.js-resume-profile-email{color:#F0F0F0;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-profile-info div.js-resume-profile-cell{color:#F0F0F0;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-data div div.js-resume-data-title{color:#D34034;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-section-view div.js-resume-data div div.js-resume-data-value{color:#F0F0F0;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-address-section-view{border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-address-section-view div span.addressDetails{color:#D34034;}
    div#js_main_wrapper div div.js-resume-section-body div div#editorView div span{color:#D34034;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-address-section-view div span.sectionText{color:#00A9E0;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-address-section-view div.map-toggler{background:#D4D4D5; border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-address-section-view div.map-toggler span{color:#00A9E0;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-address-section-view div.map_container{border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body div div.add-resume-address a{color:#00A9E0;}
    div#js_main_wrapper div div.js-resume-section-body div div.add-resume-form a{color:#00A9E0;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-data-section-view{border:1px solid #64676A;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-data-section-view div.js-resume-data-head{border-bottom:1px solid #64676A;color:#F0F0F0;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-data-section-view div div.js-resume-data-title{color:#D34034;}
    div#js_main_wrapper div div.js-resume-section-body div div.js-resume-data-section-view div div.js-resume-data-value{color:#F0F0F0;}
    div#jsjobs-wrapper div.email-checkbox {background-color:#FAFAFA;color: #64676A;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.radio-fields {background-color: #FAFAFA;color: #64676A;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.chck-box-email-text {color: #64676A;}
        div#resumeFilesPopup.resumeFilesPopup{background:#FAFAFA;}
    div#resumeFilesPopup div#resumeFiles_headline{background:#00A9E0;color:#FAFAFA;border-bottom:5px solid #0097C9;}
    div#resumeFilesPopup div.chosenFiles_heading{border-bottom:1px solid #0097C9;color:#444442}
    div#resumeFilesPopup div.filesInfo{border-bottom:1px solid #0097C9;}
    div#resumeFilesPopup div.fileSelectionButton span.fileSelector{border:1px solid #64676A;background:#FFFFFF;color:#444442;}
    div#resumeFilesPopup div.fileSelectionButton:hover span.fileSelector{background:#0097C9;color:#FAFAFA;}
    div#resumeFilesPopup div.resumeFiles_close span{border:1px solid #64676A;background:#FFFFFF;color:#444442;}
    div#resumeFilesPopup div.resumeFiles_close span:hover{background:#0097C9;color:#FAFAFA;}
    div#resumeFilesPopup div.filesInfo div.chosenFiles div.hoverLayer span.deleteChosenFiles{border:1px solid #0097C9;background:#FFFFFF;color:#444442;}
    div#resumeFilesPopup div.filesInfo div.chosenFiles div.hoverLayer span.deleteChosenFiles:hover{background:#0097C9;color:#FAFAFA;}
    div#resumeFilesPopup div.filesInfo div.chosenFiles div.hoverLayer{border:1px solid #0097C9;}
    div#jsst_breadcrumbs_parent div.home{background-color:#0097C9;}
    div#jsst_breadcrumbs_parent div.links a.links{color:#0097C9;}
    div#jsjobs-header-main-wrapper{background:#00A9E0;border-bottom:5px solid #0097C9;box-shadow: 0px 4px 1px #D4D4D5;}
    div#jsjobs-header-main-wrapper a.headerlinks{color:#FFFFFF;}
    div#jsjobs-header-main-wrapper a.headerlinks:hover{background:#FFFFFF;color:#00A9E0;}
    div#js-jobs-wrapper{border: 1px solid #D4D4D5; color: #64676A;}
    div#js-jobs-wrapper span.js-bold{color:#444442;}
    div#js-jobs-wrapper span.get-text{color:#64676A;}
    div#js-jobs-wrapper div.js-toprow div.js-image a{border: 1px solid #D4D4D5; border-left: 4px solid #00A9E0;}
    div#js-jobs-wrapper div.js-toprow div.js-data div.js-first-row{border-bottom: 1px solid #D4D4D5;}
    div#js-jobs-wrapper div.js-toprow div.js-data div.js-first-row span.js-title a{text-decoration:none;color: #00A9E0;}
    div#js-jobs-wrapper div.js-toprow div.js-data div.js-first-row span.js-jobtype span.js-type{border: 1px solid #D4D4D5; border-bottom: none;background: #FAFAFA;}
    div#js-jobs-wrapper div.js-toprow div.js-data div.js-midrow a.js-companyname{color: #64676A;}
    div#js-jobs-wrapper div.js-toprow div.js-data div.js-midrow a.js-companyname:hover{color: #00A9E0;}
    div#js-jobs-wrapper div.js-toprow div.js-data div.js-second-row div.js-fields span.js-totaljobs{border: 1px solid #D4D4D5;background: #FAFAFA;}
    div#js-jobs-wrapper div.js-bottomrow{border-top: 1px solid #D4D4D5;background: #FAFAFA; color: #64676A;}
    div#js-jobs-wrapper div.js-bottomrow div.js-actions a.js-button{border: 1px solid #D4D4D5;background: #F0F0F0;}
    div#js-jobs-wrapper div.js-bottomrow div.js-actions a.js-btn-apply{background: #00A9E0; color: #FFFFFF;}
    /*shoaib*/
    div#jsjobs-wrapper div.category-row-wrapper div.category-wrapper div.jsjobs-subcategory-wrapper{background:#FFFFFF;border:1px solid #D4D4D5;box-shadow: 0px 0px 10px #EAEAEA;}
    div#jsjobs-listpopup div.jsjob-contentarea div.jsjobs-subcategory-wrapper div.jsjobs-subcategory-wrapper{background:#FFFFFF;border:1px solid #D4D4D5;box-shadow: 0px 0px 10px #EAEAEA;}
    div#jsjobs-wrapper div.category-row-wrapper div.category-wrapper div.jsjobs-subcategory-wrapper div.showmore-wrapper a.showmorebutton,
    div#jsjobs-listpopup div.jsjob-contentarea div.jsjobs-subcategory-wrapper div.category-wrapper div.jsjobs-subcategory-wrapper div.showmore-wrapper a.showmorebutton{background: #00A9E0;color:#FFFFFF;}
    div#jsjobs-listpopup div.jsjob-contentarea div.jsjobs-subcategory-wrapper div.jobs-by-categories-wrapper{border: 1px solid #D4D4D5; background: #FAFAFA;color: #64676A;font-size: 14px;}
    div#jsjobs-listpopup div.jsjob-contentarea div.jsjobs-subcategory-wrapper div.jobs-by-categories-wrapper:hover{border-color: #00A9E0; cursor: pointer;}
    div#jsjobs-listpopup div.jsjob-contentarea div.jsjobs-subcategory-wrapper div.jobs-by-categories-wrapper span.total-jobs:hover{border-color: #00A9E0; cursor: pointer;}
    /********/
    /* Resume */
    div#resume-wrapper div.resume-section-title{background:#FAFAFA;border-bottom:2px solid #00A9E0;}
    div#resume-wrapper div.resume-section-title img{background:#00A9E0;}
    div#resume-wrapper div.section_wrapper div.resume-heading-row{background: #FAFAFA;border-bottom: 2px solid #00A9E0;}
    div#resume-wrapper div.section_wrapper div.resume-row-wrapper-wrapper{border-bottom: 1px solid #D4D4D5;}
    div#resume-wrapper div.section_wrapper div.resume-row-full-view{border-bottom: 1px solid #D4D4D5;}
    div#resume-wrapper div.resume-section-data{border:1px solid #D4D4D5;}
    div#resume-wrapper div.resume-heading-row span.resume-employer-position{background: #0097C9;color:#ffffff;}
    div#resume-wrapper div.resume-top-section{background: #FAFAFA;}
    div#resume-wrapper div.resume-top-section div.js-col-lg-4 img{background: #FFFFFF;border:2px solid #00A9E0;}
    div#resume-wrapper div.resume-top-section div.js-col-lg-8 span.resume-tp-name{border-bottom: 1px solid #D4D4D5;}
    div#resume-wrapper div.resume-top-section div.js-col-lg-8 span.resume-tp-apptitle{color:#64676A;}
    div#resume-wrapper div.resume-top-section div.js-col-lg-8 a{background: #F0F0F0;border:1px solid #D4D4D5;}
    div#resume-wrapper div.resume-top-section div.js-col-lg-8 a:hover{border:1px solid #00A9E0;}
    div#resume-wrapper div.resume-top-section div.js-col-lg-8 a.downloadall{background: #00A9E0;color:#ffffff;}
    div#resume-wrapper div.resume-row-wrapper div.row-title,
    div#resume-wrapper div.resume-map-edit div.row-title{color:#444442;}
    div#resume-wrapper div.resume-row-wrapper div.row-value img#rs_photo.rs_photo{border:2px solid #00A9E0;}
    div#resume-wrapper div.resume-row-wrapper div.row-value{color:#64676A;}
    div#resume-wrapper div.resume-map div.row-title{background: #FAFAFA;border:1px solid #D4D4D5;}
    div#resume-wrapper div.resume-map div.row-value{border:1px solid #D4D4D5;}
    div#resume-wrapper div.section_wrapper div.resume-row-full-view div.row-value.attachments a.file{color:#64676A;background: #FAFAFA;border:1px solid #D4D4D5;}
    div#resume-wrapper div.section_wrapper div.resume-row-full-view div.row-value.attachments a.file img.filedownload{background: #00A9E0;}
    div#resume-wrapper div.section_wrapper div.resume-row-full-view div.row-value.attachments{border:1px solid #D4D4D5;}
    div#resume-wrapper div.section_wrapper div.resume-row-full-view div.row-title.attachments{color:#444442;}
    div#resume-wrapper div.section_wrapper.form{border:1px solid #D4D4D5;}
    div#resume-wrapper div.section_wrapper.form div.formsectionheading{border-bottom:2px solid #00A9E0;background: #FAFAFA;}
    div#resume-wrapper a.add{background: #F0F0F0;color:#444442;border:1px solid #D4D4D5;}
    div#resume-wrapper div.resume-map-edit div.row-value div.map{border:1px solid #D4D4D5;}
    div#resume-files-popup-wrapper{background: #FAFAFA;border-bottom:5px solid #00A9E0;}
    div#resume-files-popup-wrapper span.close-resume-files{background: #00A9E0;border-bottom:5px solid #008bc2;color:#ffffff;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span.clickablefiles{background: #F0F0F0;color:#444442;border:1px solid #D4D4D5;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span.headingpopup{background: #444442;color:#FFFFFF;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span#resume-files-selected{background: #FFFFFF;border:1px solid #D4D4D5;}
    div#resume-wrapper div.resume-row-wrapper.form div.row-value input,
    div#resume-wrapper div.resume-row-wrapper.form div.row-value select{background: #FAFAFA;border:1px solid #D4D4D5;}
    div#resume-wrapper div.resume-row-wrapper.form div.row-value div#resumefileswrapper{background: #FAFAFA;border:1px solid #D4D4D5;}
    div#resume-wrapper div.resume-row-wrapper.form div.row-value div#resumefileswrapper span.resume-selectfiles{background: #00A9E0;}
    div#resume-wrapper div.resume-row-wrapper.form div.row-value div#resumefileswrapper a.file{background: #FFFFFF;border:1px solid #D4D4D5;color:#64676A;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span#resume-files-selected div.resumefileselected{border:1px solid #D4D4D5;background:#FAFAFA;color:#64676A;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span#resume-files-selected div.resumefileselected.errormsg{border:1px solid #ED3237;background:#FAFAFA;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span#resume-files-selected div.resumefileselected.errormsg span.filename{color:#ED3237;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span#resume-files-selected div.error_msg{color:#ED3237;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span#resume-files-selected div.resumefileselected button{background:#F0F0F0;color:#444442;border:1px solid #D4D4D5;}
    div#resume-files-popup-wrapper div.resumepopupsectionwrapper span#resume-files-selected div.resumefileselected button:hover{background:#00A9E0;color:#FFFFFF;}
    div#resume-files-popup-wrapper div.resume-filepopup-lowersection-wrapper{color:#64676A;}
    div#resume-wrapper span.resume-moreoptiontitle{background: #00A9E0;color:#FFFFFF;}
    div#jsjobs-wrapper div#comments label {color: #444442;}
    /* ratelist */
    div#jsjobs-wrapper div.rate-list-item{border:1px solid #D4D4D5;background-color:#FAFAFA;color:#444442;}
    div#jsjobs-wrapper div.rate-list-item span.rate-list-top{border-bottom:1px solid #D4D4D5;}
    div#jsjobs-wrapper div.rate-list-item span.rate-list-bottom{color:#64676A;background-color:#ffffff;}
    div#jsjobs-wrapper div.rate-list-item span.rate-list-bottom span.bold{color:#444442;}
    div#jsjobs-wrapper div.rate-list-item span.rate-list-bottom-right{border:1px solid #D4D4D5;background-color:#FAFAFA;}
    div#resume-wrapper div.resume-section-button input{background: #F0F0F0;border:1px solid #D4D4D5;color:#444442;}
    div#job-applied-resume-jobtitle{background: #FAFAFA;border:1px solid #D4D4D5;color:#64676A;}
    div#jsjobs-wrapper div#popup-main div#popup-bottom-part.center input.jsjobs-button{background: #F0F0F0;color:#444442;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper div#popup-main div#popup-bottom-part.center input.jsjobs-button:hover{background: #00A9E0;color:#FFFFFF;}
    div#jsjobs-listpopup div.job-alert-popup div#save-button input[type="submit"]{background: #F0F0F0 !important;border:1px solid#D4D4D5;color:#444442;}
    div#jsjobs-listpopup div.job-alert-popup div#save-button input[type="submit"]:hover{background: #FAFAFA !important;border:1px solid#D4D4D5;color:#444442;}
    div#jsjobs-listpopup div.job-alert-popup input#emailaddress{color:#64676A;border:1px solid #D4D4D5;}
    div#jsjobs-listpopup div.job-alert-popup div.js-form-title{color:#444442;}
    div#jsjobs-wrapper div.listing-fields div.custom-field-wrapper span.js-bold{color: #444442;}
    div#jsjobs-wrapper div.listing-fields div.custom-field-wrapper span.get-text{color: #64676A;}
    div#jsjobs_jstags span.jstagstitle{color:#444442;}
    div#jsjobs_jstags a.jsjob_tags_a:hover{color:#00A9E0; border:1px solid #00A9E0;background:unset;}
    div#jsjobs_module_wrapper div#jsjobs_module_wrap div#jsjobs_module_data_fieldwrapper span#jsjobs_module_data_fieldtitle{color:#444442;}
    div#jsjobs_module_wrapper div#jsjobs_module_wrap div#jsjobs_module_data_fieldwrapper span#jsjobs_module_data_fieldvalue{color:#64676A;}
    div#jsjobs_module_wrapper div#tp_heading {border-bottom: 2px solid #0097C9;}
    div#jsjobs_module{background:#FAFAFA;border:1px solid  #D4D4D5;}
    div#jsjobs_modulelist_databar{background:#FAFAFA;border:1px solid  #D4D4D5;}
    div#jsjobs_modulelist_titlebar{background:#FAFAFA;border:1px solid  #D4D4D5;}
    div#jsjobs_module span#jsjobs_module_heading{border-bottom:1px solid  #0097C9;}
    div#jsjobs_module a{color:#00A9E0;}
    div#jsjobs_mod_wrapper div#jsjobs-data-wrapper div.anchor a.anchor{background:#FAFAFA;border:1px solid  #D4D4D5;color: #444442;}
    div#jsjobs_mod_wrapper div#jsjobs-mod-heading{border-bottom:2px solid  #0097C9;color: #444442;}
    div#jsjobs_mod_wrapper div.jsjobs-value{color: #64676A;}
    div#jsjobs-popup.loginpopup div.popup-row.name div.login-heading{color:#444442;}
    div#jsjobs-popup.loginpopup div.popup-row.name input#user_login,
    div#jsjobs-popup.loginpopup div.popup-row.name input#user_pass{color:#64676A;border:1px solid #D4D4D5;background:#FAFAFA;}
    div#jsjobs-popup.loginpopup div.popup-row.name input#wp-submit{color:#FFFFFF;background:#00A9E0;border:0px;outline: unset;}
    div#jsjobs-popup.loginpopup div.popup-row.name p.login-remember label{color:#64676A;}
    div#jsjobs-popup.loginpopup div.loginintocomment span.logintext{color: #444442;}
    div#jsjobs-popup.loginpopup div.loginintocomment hr.loginhr{border: 1px solid #D4D4D5;}
    div#jsjobs-listpopup div.jsjob-contentarea div.quickviewrow span.jobtitle{border-bottom:1px solid #D4D4D5;border-top:2px solid #0097C9; color: #444442;background: #FAFAFA;}
    div.companies.filterwrapper form span.filterlocation img{border:1px solid #D4D4D5;border-bottom: none;}
    div.companies.filterwrapper form span.filterlocation ul.jsjobs-input-list-jsjobs{border:1px solid #D4D4D5;}
    div.companies.filterwrapper form input#jsjobs-company{background:#FFFFFF;border:1px solid #D4D4D5;}
    div.companies.filterwrapper{background: #FAFAFA;border-bottom:2px solid #D4D4D5;}
    div.companies.filterwrapper form input#jsjobs-go{background:#F0F0F0;border:1px solid #D4D4D5;color:#444442;}
    div.companies.filterwrapper form input#jsjobs-go:hover{background:#00A9E0;color:#FFFFFF;}
    div.companies.filterwrapper form input#jsjobs-reset{background:#F0F0F0;border:1px solid #D4D4D5;color:#444442;}
    div.companies.filterwrapper form input#jsjobs-reset:hover{background:#00A9E0;color:#FFFFFF;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div#job-applied-resume div.jobs-upper-wrapper div.job-detail div.job-detail-lower div.block span.applyassocial{background:#FAFAFA;border:1px solid #D4D4D5;}
    span.job-right-heading{color:#444442;background:#FAFAFA;border-bottom:1px solid #0097C9;}
    div#jsjobsfooter{border:1px solid #D4D4D5;background: #FAFAFA;}
    div#jsresume-tags-wrapper span.jsresume-tags-title{background: #444442;color:#FFFFFF;}
    div#jsresume-tags-wrapper div.tags-wrapper-border{border:1px solid #D4D4D5;}
    div#jsresume-tags-wrapper div.tags-wrapper-border a.jsjob_tags_a:hover{background: unset;border:1px solid #00A9E0;color:#00A9E0;}
    div#jsjobs-wrapper a#showmorejobs{color:#FFFFFF;background: #0097C9;}
    
    div.js-form-wrapper-newlogin{border: 1px solid #D4D4D5;background: #FAFAFA;}
    div.js-form-wrapper-newlogin div.js-imagearea div.js-img{background: #00A9E0;}
    div.js-form-wrapper-newlogin div.js-dataarea div.js-form-heading{color:#444442; border-bottom: 2px solid #0097C9;}

    div#jsjobs-wrapper form#jsjobs_registration_form input#save{background:none; color:#FFFFFF;background-color:#00A9E0;border:1px solid #D4D4D5;}
    div#jsjobs-wrapper form#jsjobs_registration_form fieldset label{color:#444442}
    div#jsjobs-wrapper form#jsjobs_registration_form fieldset p span{color:#444442}
    div#jsjobs-wrapper form#jsjobs_registration_form fieldset div#save{border-top:2px solid #0097C9;}

    div#jsjobs-wrapper div.js-login-wrapper{background-color:#FAFAFA;border:2px solid #D4D4D5;}
    div#jsjobs-wrapper div.js-login-wrapper div.login-heading{color: #444442;}
    div#jsjobs-wrapper div.js-login-wrapper div.js-ourlogin form#loginform-custom p label{color: #444442;}
    div#jsjobs-wrapper div.js-login-wrapper div.js-ourlogin form#loginform-custom p.login-submit input#wp-submit{border:none; outline: none; color: #FFFFFF; background: #00A9E0;}
    div#jsjobs-wrapper div.js-login-wrapper div.js-ourlogin form#loginform-custom p input.input{border:2px solid #D4D4D5;}
    div#jsjobs-wrapper div.js-login-wrapper div.js-seprator div.js-vline{border-left: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div#job-applied-resume-wrapper div.jsjobs-button-search{border-top: 2px solid #0097C9;}

	div#jsjobs-wrapper div#send-message-wrapper div.message-history span.js-msg-left div{border: 1px solid #D4D4D5;border-left:3px solid #00A9E0 }

    div#jsjobs-wrapper div.my-resume-data div.data-bigupper div.big-upper-lower.listing-fields div.myresume-list-data-profile {border: 1px solid #D4D4D5;}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper div.big-upper-lower.listing-fields div.myresume-list-data-profile  span.myresume-profile-heading{border-bottom: 1px solid #D4D4D5; background: #FAFAFA;}
    div#jsjobs-wrapper div.my-resume-data div.data-bigupper div.big-upper-lower.listing-fields div.myresume-list-data-profile  span.myresume-profile-title{ border-top: 1px solid #D4D4D5;}


    div#resume-wrapper div.jsresume_addnewbutton{border:1px solid #D4D4D5;background: #FAFAFA;color:#444442;}

    
    div#resume-wrapper div.resume-section-button div#save-button.bottombutton input.jsjb-jm-btn-primary{border:1px solid #00A9E0;background: #FAFAFA;color:#444442;}
    div#resume-wrapper div.resume-section-button div#save-button.bottombutton input.jsjb-jh-btn-primary{border:1px solid #00A9E0;background: #FAFAFA;color:#444442;}
    div#resume-wrapper div.resume-section-button div#save-button.bottombutton input.-btn-primary{border:1px solid #00A9E0;background: #FAFAFA;color:#444442;}
    div#resume-wrapper div.resume-section-button div#save-button.bottombutton a.resume_submits.cancel{border:1px solid #00A9E0;background: #FAFAFA;color:#444442;}
    div#jsjobs-wrapper div.js-form-wrapper div.resumefieldvalue div a.js-resume-close-cross{border:1px solid #00A9E0;}
    
    div#resume-wrapper div.section_wrapper{background: #FAFAFA}

    div#jsjobs-wrapper div#my-companies-header ul li{border: 1px solid #D4D4D5;color:#FFFFFF;background-color:#444442;}
    div#jsjobs-wrapper div#my-companies-header ul li a{color:#FFFFFF}
    div#jsjobs-wrapper div#my-companies-header ul li img#posted-img{border:1px solid white;}
    div#jsjobs-wrapper div#my-companies-header ul li:hover{background-color:#00A9E0;}

    .jsjobs-job-listing-total-jobs{border:1px solid #D4D4D5;background: #FAFAFA;color:#64676A;}
    .jsjobs-job-listing-total-jobs span{color:#444442;}


    div#jsjobs-wrapper div.visitor-apply-job-jobinforamtion-wrapper{border-bottom: 1px solid #00A9E0}

    @media(min-width: 481px) and (max-width: 780px) {
        div#jsjobs-wrapper div.message-content-data div.data-right{border-top:1px solid #D4D4D5;}
    }
    @media(min-width: 481px) and (max-width: 650px) {
        div#jsjobs-wrapper div.department-content-data div.data-lower{border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.search-wrapper-content-data div.data-upper{border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.search-wrapper-content-data span.upper-app-title{border:none;border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.cover-letter-content-data div.data-upper{border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.cover-letter-content-data span.upper-app-title{border:none;border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.folder-wrapper div.folder-firsl{border-bottom: 1px solid #D4D4D5 ;}
        div#jsjobs-wrapper div.js-login-wrapper div.js-seprator div.js-vline{border-top: 1px solid #D4D4D5;}
        div#jsjobs-wrapper div.purchase-history-wrapper div.purchase-history-data span.data-price{border-top: 1px solid #D4D4D5}
    }
    @media (max-width: 480px) {
        div#resume-wrapper div.section_wrapper div.resume-row-wrapper-wrapper{border:0px;}
        div#resume-wrapper div.resume-row-wrapper{border-bottom:1px solid #D4D4D5;}
        div#resume-wrapper div.resume-row-wrapper.form{border-bottom:0px;}
        div#jsjobs-wrapper div.department-content-data div.data-lower{border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.cover-letter-content-data div.data-upper{border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.cover-letter-content-data span.upper-app-title{border:none;border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div#view-cover-letter-wrapper div#wrapper-content div.content-data span.upper-app-title{border:none;border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.search-wrapper-content-data div.data-upper{border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.search-wrapper-content-data span.upper-app-title{border:none;border-bottom:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.message-content-data div.data-left span.lower{border-bottom:1px solid #D4D4D5;color:#64676A;}
        div#jsjobs-wrapper div.credit-wrapper div.credit-content-data span.data-top span.top-right{border-top:1px solid #D4D4D5;}
        div#jsjobs-wrapper div.credit-log-wrapper span.desc{border:none;border-top: 1px solid #D4D4D5;}
        div#jsjobs-wrapper div.folder-wrapper{display:inline-block;border:1px solid #D4D4D5; background: #FAFAFA;}
        div#jsjobs-wrapper div.folder-wrapper{display: inline-block; width: 100%;}
        div#jsjobs-wrapper div.folder-wrapper div.folder-firsl{border-bottom: 1px solid #D4D4D5;}
        div#jsjobs-wrapper div.folder-wrapper div.folder-firsl span{color:#444442 ; font-size: 13px; font-weight: bold;}
        div#jsjobs-wrapper div.folder-wrapper div.folder-second span{color:#444442 ; font-size: 14px; font-weight: bold;}
        div#jsjobs-wrapper div.folder-wrapper div.folder-second{border-bottom: 1px solid #D4D4D5 ;}
        div#jsjobs-wrapper div.folder-wrapper div.folder-third div.button-section div.button{ border: solid 1px #D4D4D5; background: #F0F0F0;}
        div#jsjobs-wrapper div.folder-wrapper div.folder-third div.button-section div.button a{color: #64676A; font-size: 14px;}
        div#jsjobs-wrapper div.folder-wrapper div.folder-third div.button-section div.resume-button:hover{background: #00A9E0; color: #FFFFFF;}
        div#jsjobs-wrapper div.resume-save-search-wrapper{ border:1px solid #D4D4D5; background: #FAFAFA;}
        div#jsjobs-wrapper div.resume-save-search-wrapper div.div-left{border-bottom: 1px solid #D4D4D5 ; border-right: 0px;}
        div#jsjobs-wrapper div.resume-save-search-wrapper div.div-left span{color:#444442 ; font-size: 13px; font-weight: bold;}
        div#jsjobs-wrapper div.resume-save-search-wrapper div.div-middel span{color:#444442 ; font-size: 14px; font-weight: bold;}
        div#jsjobs-wrapper div.resume-save-search-wrapper div.div-middel{border-bottom: 1px solid #D4D4D5 ; border-right: 0px;}
        div#jsjobs-wrapper div.resume-save-search-wrapper div.div-right div.button{ border: solid 1px #D4D4D5; background: #F0F0F0;}
        div#jsjobs-wrapper div.resume-save-search-wrapper div.div-right div.button a{color: #64676A; font-size: 14px;}
        div#jsjobs-wrapper div.resume-save-search-wrapper div.div-right div.button:hover{background: #00A9E0; color: #FFFFFF;} 
        div#jsjobs-wrapper div.resume-save-search-wrapper span.upper-app-title{border-right: none;}
        div#js-jobs-wrapper div.js-toprow div.js-image a{border: 1px solid #D4D4D5;border-left: 4px solid #00A9E0;}
        
        div#jsjobs-wrapper div.purchase-history-wrapper div.purchase-history-data span.data-price{border:none;border-top:1px solid #D4D4D5;}

        table#js-table tbody.stats tr td.title{border-right: 1px solid #D4D4D5;}
        table#js-table tbody.stats tr td.publish{border-right: 1px solid #D4D4D5;}
    }

        table#js-table tbody.stats tr td.gold{border-left:3px solid #Ff6600;}
        table#js-table tbody.stats tr td.feature{border-left:3px solid #00AFEF;}
        table#js-table tbody.stats tr td.simplejob{border-left:3px solid #65A324;}

    </style>
<meta name='robots' content='noindex,follow' />
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Job Creator &raquo; Feed" href="http://localhost/wordpress/wordpress/feed/" />
<link rel="alternate" type="application/rss+xml" title="Job Creator &raquo; Comments Feed" href="http://localhost/wordpress/wordpress/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost\/wordpress\/wordpress\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.8"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<!-- managing ads with Advanced Ads --><script>
					advanced_ads_ready=function(){var fns=[],listener,doc=typeof document==="object"&&document,hack=doc&&doc.documentElement.doScroll,domContentLoaded="DOMContentLoaded",loaded=doc&&(hack?/^loaded|^c/:/^loaded|^i|^c/).test(doc.readyState);if(!loaded&&doc){listener=function(){doc.removeEventListener(domContentLoaded,listener);window.removeEventListener("load",listener);loaded=1;while(listener=fns.shift())listener()};doc.addEventListener(domContentLoaded,listener);window.addEventListener("load",listener)}return function(fn){loaded?setTimeout(fn,0):fns.push(fn)}}();
			</script><style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='dashicons-css'  href='http://localhost/wordpress/wordpress/wp-includes/css/dashicons.min.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='admin-bar-css'  href='http://localhost/wordpress/wordpress/wp-includes/css/admin-bar.min.css?ver=4.9.8' type='text/css' media='all' />
<style id='admin-bar-inline-css' type='text/css'>
#wp-admin-bar-fl-builder-frontend-edit-link .ab-icon:before { content: "\f116" !important; top: 2px; margin-right: 3px; }
</style>
<link rel='stylesheet' id='fl-builder-layout-14-css'  href='http://localhost/wordpress/wordpress/wp-content/uploads/bb-plugin/cache/14-layout.css?ver=79eac36fbb861a08d6c236ca92b0fab9' type='text/css' media='all' />
<link rel='stylesheet' id='jsjob-jobseeker-style-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/js-jobs/includes/css/jobseekercp.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='jsjob-employer-style-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/js-jobs/includes/css/employercp.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='jsjob-style-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/js-jobs/includes/css/style.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='jsjob-style-tablet-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/js-jobs/includes/css/style_tablet.css?ver=4.9.8' type='text/css' media='(min-width: 481px) and (max-width: 780px)' />
<link rel='stylesheet' id='jsjob-style-mobile-landscape-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/js-jobs/includes/css/style_mobile_landscape.css?ver=4.9.8' type='text/css' media='(min-width: 481px) and (max-width: 650px)' />
<link rel='stylesheet' id='jsjob-style-mobile-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/js-jobs/includes/css/style_mobile.css?ver=4.9.8' type='text/css' media='(max-width: 480px)' />
<link rel='stylesheet' id='jsjob-chosen-style-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/js-jobs/includes/js/chosen/chosen.min.css?ver=4.9.8' type='text/css' media='all' />
<!--[if IE]>
<link rel='stylesheet' id='jsjobs-css-ie-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/js-jobs/includes/css/jsjobs-ie.css?ver=4.9.8' type='text/css' media='all' />
<![endif]-->
<link rel='stylesheet' id='image-hover-effects-css-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/mega-addons-for-visual-composer/css/ihover.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='style-css-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/mega-addons-for-visual-composer/css/style.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-latest-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/mega-addons-for-visual-composer/css/font-awesome/css/font-awesome.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='simple-job-board-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A100%2C100i%2C300%2C300i%2C400%2C400i%2C500%2C500i%2C700%2C700i%2C900%2C900i&#038;ver=2.6.0' type='text/css' media='all' />
<link rel='stylesheet' id='simple-job-board-font-awesome-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/simple-job-board/public/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='simple-job-board-jquery-ui-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/simple-job-board/public/css/jquery-ui.css?ver=1.12.1' type='text/css' media='all' />
<link rel='stylesheet' id='simple-job-board-frontend-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/simple-job-board/public/css/simple-job-board-public.css?ver=3.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/elementor/assets/lib/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='chosen-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/wp-job-manager/assets/css/chosen.css?ver=1.1.0' type='text/css' media='all' />
<link rel='stylesheet' id='wp-job-manager-frontend-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/wp-job-manager/assets/css/frontend.css?ver=1.31.2' type='text/css' media='all' />
<link rel='stylesheet' id='robolist-lite-style-css'  href='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/style.css?ver=4.9.8' type='text/css' media='all' />
<link rel='stylesheet' id='robolist-custom-lite-style-css'  href='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/css/robolist.css?ver=4.9.8' type='text/css' media='all' />
<link rel="stylesheet" type="text/css" href="//localhost/wordpress/wordpress/wp-content/plugins/smart-slider-3/library/media/smartslider.min.css?1533993153" media="all" />
<style type="text/css">.n2-ss-spinner-simple-white-container {
    position: absolute;
    top: 50%;
    left: 50%;
    margin: -20px;
    background: #fff;
    width: 20px;
    height: 20px;
    padding: 10px;
    border-radius: 50%;
    z-index: 1000;
}

.n2-ss-spinner-simple-white {
  outline: 1px solid RGBA(0,0,0,0);
  width:100%;
  height: 100%;
}

.n2-ss-spinner-simple-white:before {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 20px;
    height: 20px;
    margin-top: -11px;
    margin-left: -11px;
}

.n2-ss-spinner-simple-white:not(:required):before {
    content: '';
    border-radius: 50%;
    border-top: 2px solid #333;
    border-right: 2px solid transparent;
    animation: n2SimpleWhite .6s linear infinite;
    -webkit-animation: n2SimpleWhite .6s linear infinite;
}
@keyframes n2SimpleWhite {
    to {transform: rotate(360deg);}
}

@-webkit-keyframes n2SimpleWhite {
    to {-webkit-transform: rotate(360deg);}
}</style><script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/plugins/mega-addons-for-visual-composer/js/script.js?ver=4.9.8'></script>
<link rel='https://api.w.org/' href='http://localhost/wordpress/wordpress/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/wordpress/wordpress/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost/wordpress/wordpress/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.8" />
<link rel="canonical" href="http://localhost/wordpress/wordpress/" />
<link rel='shortlink' href='http://localhost/wordpress/wordpress/' />
<link rel="alternate" type="application/json+oembed" href="http://localhost/wordpress/wordpress/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwordpress%2Fwordpress%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://localhost/wordpress/wordpress/wp-json/oembed/1.0/embed?url=http%3A%2F%2Flocalhost%2Fwordpress%2Fwordpress%2F&#038;format=xml" />
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<style type="text/css" media="print">#wpadminbar { display:none; }</style>
<style type="text/css" media="screen">
	html { margin-top: 32px !important; }
	* html body { margin-top: 32px !important; }
	@media screen and ( max-width: 782px ) {
		html { margin-top: 46px !important; }
		* html body { margin-top: 46px !important; }
	}
</style>
<link rel="icon" href="http://localhost/wordpress/wordpress/wp-content/uploads/2018/08/cropped-jc-1-32x32.jpg" sizes="32x32" />
<link rel="icon" href="http://localhost/wordpress/wordpress/wp-content/uploads/2018/08/cropped-jc-1-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://localhost/wordpress/wordpress/wp-content/uploads/2018/08/cropped-jc-1-180x180.jpg" />
<meta name="msapplication-TileImage" content="http://localhost/wordpress/wordpress/wp-content/uploads/2018/08/cropped-jc-1-270x270.jpg" />
<script type="text/javascript">(function(){var N=this;N.N2_=N.N2_||{r:[],d:[]},N.N2R=N.N2R||function(){N.N2_.r.push(arguments)},N.N2D=N.N2D||function(){N.N2_.d.push(arguments)}}).call(window);if(!window.n2jQuery){window.n2jQuery={ready:function(cb){console.error('n2jQuery will be deprecated!');N2R(['$'],cb)}}}window.nextend={localization:{},ready:function(cb){console.error('nextend.ready will be deprecated!');N2R('documentReady',function($){cb.call(window,$)})}};nextend.fontsLoaded=false;nextend.fontsLoadedActive=function(){nextend.fontsLoaded=true};var fontData={google:{families:["Raleway:300,400:latin"]},active:function(){nextend.fontsLoadedActive()},inactive:function(){nextend.fontsLoadedActive()}};if(typeof WebFontConfig!=='undefined'){var _WebFontConfig=WebFontConfig;for(var k in WebFontConfig){if(k=='active'){fontData.active=function(){nextend.fontsLoadedActive();_WebFontConfig.active()}}else if(k=='inactive'){fontData.inactive=function(){nextend.fontsLoadedActive();_WebFontConfig.inactive()}}else if(k=='google'){if(typeof WebFontConfig.google.families!=='undefined'){for(var i=0;i<WebFontConfig.google.families.length;i++){fontData.google.families.push(WebFontConfig.google.families[i])}}}else{fontData[k]=WebFontConfig[k]}}}if(typeof WebFont==='undefined'){window.WebFontConfig=fontData}else{WebFont.load(fontData)}</script><script type="text/javascript" src="//localhost/wordpress/wordpress/wp-content/plugins/smart-slider-3/nextend/media/dist/n2.min.js?1533993168"></script>
<script type="text/javascript" src="//localhost/wordpress/wordpress/wp-content/plugins/smart-slider-3/nextend/media/dist/nextend-frontend.min.js?1533993168"></script>
<script type="text/javascript" src="//localhost/wordpress/wordpress/wp-content/plugins/smart-slider-3/library/media/dist/smartslider-frontend.min.js?1533993151"></script>
<script type="text/javascript" src="//localhost/wordpress/wordpress/wp-content/plugins/smart-slider-3/library/media/plugins/type/simple/simple/dist/smartslider-simple-type-frontend.min.js?1533993152"></script>
<script type="text/javascript" src="//localhost/wordpress/wordpress/wp-content/plugins/smart-slider-3/nextend/media/dist/nextend-webfontloader.min.js?1533993168"></script>
<script type="text/javascript">N2R('documentReady',function($){nextend.fontsDeferred=$.Deferred();if(nextend.fontsLoaded){nextend.fontsDeferred.resolve()}else{nextend.fontsLoadedActive=function(){nextend.fontsLoaded=true;nextend.fontsDeferred.resolve()};var intercalCounter=0;nextend.fontInterval=setInterval(function(){if(intercalCounter>3||document.documentElement.className.indexOf('wf-active')!==-1){nextend.fontsLoadedActive();clearInterval(nextend.fontInterval)}intercalCounter++},1000)}N2R(["nextend-frontend","smartslider-frontend","smartslider-simple-type-frontend"],function(){new N2Classes.SmartSliderSimple('#n2-ss-1',{"admin":false,"translate3d":1,"callbacks":"","background.video.mobile":1,"randomize":{"randomize":0,"randomizeFirst":0},"align":"normal","isDelayed":0,"load":{"fade":1,"scroll":0},"playWhenVisible":1,"playWhenVisibleAt":0.5,"responsive":{"desktop":1,"tablet":1,"mobile":1,"onResizeEnabled":true,"type":"auto","downscale":1,"upscale":1,"minimumHeight":0,"maximumHeight":3000,"maximumSlideWidth":3000,"maximumSlideWidthLandscape":3000,"maximumSlideWidthTablet":3000,"maximumSlideWidthTabletLandscape":3000,"maximumSlideWidthMobile":3000,"maximumSlideWidthMobileLandscape":3000,"maximumSlideWidthConstrainHeight":0,"forceFull":0,"forceFullOverflowX":"body","forceFullHorizontalSelector":"","constrainRatio":1,"verticalOffsetSelectors":"","decreaseSliderHeight":0,"focusUser":0,"focusAutoplay":0,"deviceModes":{"desktopPortrait":1,"desktopLandscape":0,"tabletPortrait":1,"tabletLandscape":0,"mobilePortrait":1,"mobileLandscape":0},"normalizedDeviceModes":{"unknownUnknown":["unknown","Unknown"],"desktopPortrait":["desktop","Portrait"],"desktopLandscape":["desktop","Portrait"],"tabletPortrait":["tablet","Portrait"],"tabletLandscape":["tablet","Portrait"],"mobilePortrait":["mobile","Portrait"],"mobileLandscape":["mobile","Portrait"]},"verticalRatioModifiers":{"unknownUnknown":1,"desktopPortrait":1,"desktopLandscape":1,"tabletPortrait":1,"tabletLandscape":1,"mobilePortrait":1,"mobileLandscape":1},"minimumFontSizes":{"desktopPortrait":1,"desktopLandscape":1,"tabletPortrait":1,"tabletLandscape":1,"mobilePortrait":1,"mobileLandscape":1},"ratioToDevice":{"Portrait":{"tablet":0.7,"mobile":0.5},"Landscape":{"tablet":0,"mobile":0}},"sliderWidthToDevice":{"desktopPortrait":1200,"desktopLandscape":1200,"tabletPortrait":840,"tabletLandscape":0,"mobilePortrait":600,"mobileLandscape":0},"basedOn":"combined","orientationMode":"width_and_height","scrollFix":0,"overflowHiddenPage":0,"desktopPortraitScreenWidth":1200,"tabletPortraitScreenWidth":800,"mobilePortraitScreenWidth":440,"tabletLandscapeScreenWidth":800,"mobileLandscapeScreenWidth":440},"controls":{"scroll":0,"drag":1,"touch":"horizontal","keyboard":1,"tilt":0},"lazyLoad":0,"lazyLoadNeighbor":0,"blockrightclick":0,"maintainSession":0,"autoplay":{"enabled":1,"start":1,"duration":8000,"autoplayToSlide":-1,"autoplayToSlideIndex":-1,"allowReStart":0,"pause":{"click":1,"mouse":"0","mediaStarted":1},"resume":{"click":0,"mouse":"0","mediaEnded":1,"slidechanged":0}},"perspective":1000,"layerMode":{"playOnce":0,"playFirstLayer":1,"mode":"skippable","inAnimation":"mainInEnd"},"background.parallax.tablet":1,"background.parallax.mobile":1,"initCallbacks":["N2D(\"SmartSliderWidgetArrowImage\",function(i,e){function t(e,t,s,h){this.slider=e,this.slider.started(i.proxy(this.start,this,t,s,h))}return t.prototype.start=function(e,t,s){return this.slider.sliderElement.data(\"arrow\")?!1:(this.slider.sliderElement.data(\"arrow\",this),this.deferred=i.Deferred(),this.slider.sliderElement.on(\"SliderDevice\",i.proxy(this.onDevice,this)).trigger(\"addWidget\",this.deferred),this.previous=i(\"#\"+this.slider.elementID+\"-arrow-previous\").on(\"click\",i.proxy(function(i){i.stopPropagation(),this.slider[n2const.rtl.previous]()},this)),this.previousResize=this.previous.find(\".n2-resize\"),0==this.previousResize.length&&(this.previousResize=this.previous),this.next=i(\"#\"+this.slider.elementID+\"-arrow-next\").on(\"click\",i.proxy(function(i){i.stopPropagation(),this.slider[n2const.rtl.next]()},this)),this.nextResize=this.next.find(\".n2-resize\"),0==this.nextResize.length&&(this.nextResize=this.next),this.desktopRatio=e,this.tabletRatio=t,this.mobileRatio=s,void i.when(this.previous.n2imagesLoaded(),this.next.n2imagesLoaded()).always(i.proxy(this.loaded,this)))},t.prototype.loaded=function(){this.previousResize.css(\"display\",\"inline-block\"),this.previousWidth=this.previousResize.width(),this.previousHeight=this.previousResize.height(),this.previousResize.css(\"display\",\"\"),this.nextResize.css(\"display\",\"inline-block\"),this.nextWidth=this.nextResize.width(),this.nextHeight=this.nextResize.height(),this.nextResize.css(\"display\",\"\"),this.previousResize.find(\"img\").css(\"width\",\"100%\"),this.nextResize.find(\"img\").css(\"width\",\"100%\"),this.onDevice(null,{device:this.slider.responsive.getDeviceMode()}),this.deferred.resolve()},t.prototype.onDevice=function(i,e){var t=1;switch(e.device){case\"tablet\":t=this.tabletRatio;break;case\"mobile\":t=this.mobileRatio;break;default:t=this.desktopRatio}this.previousResize.width(this.previousWidth*t),this.previousResize.height(this.previousHeight*t),this.nextResize.width(this.nextWidth*t),this.nextResize.height(this.nextHeight*t)},t});","new N2Classes.SmartSliderWidgetArrowImage(this, 1, 0.7, 0.5);","N2D(\"SmartSliderWidgetBulletTransition\",function(t,i){function e(i,e){this.slider=i,this.slider.started(t.proxy(this.start,this,e))}return e.prototype.start=function(i){if(this.slider.sliderElement.data(\"bullet\"))return!1;this.slider.sliderElement.data(\"bullet\",this),this.axis=\"horizontal\",this.offset=0,this.parameters=i,this.bar=this.slider.sliderElement.find(\".nextend-bullet-bar\");var e=\"universalclick\";if(\"mouseenter\"==i.action&&(e=\"mouseenter\"),this.originalDots=this.dots=this.bar.find(\"div\").on(e,t.proxy(this.onDotClick,this)),this.slider.isShuffled){for(var s=[],o=[],a=0;this.slider.realSlides.length>a;a++){var r=this.slider.realSlides[a];s.push(this.dots.get(r.originalIndex)),o.push(this.parameters.thumbnails[r.originalIndex]),i.numeric&&this.dots.eq(r.originalIndex).html(a+1)}this.originalDots=this.dots=t(s).appendTo(this.dots.parent()),this.parameters.thumbnails=o}if(this.slider.sliderElement.on({slideCountChanged:t.proxy(this.onSlideCountChanged,this),sliderSwitchTo:t.proxy(this.onSlideSwitch,this)}),this.slider.firstSlideReady.done(t.proxy(this.onFirstSlideSet,this)),0==i.overlay){var n=!1;switch(i.area){case 1:n=\"Top\";break;case 12:n=\"Bottom\";break;case 5:n=\"Left\",this.axis=\"vertical\";break;case 8:n=\"Right\",this.axis=\"vertical\"}n&&(this.offset=parseFloat(this.bar.data(\"offset\")),this.slider.responsive.addStaticMargin(n,this))}this.initThumbnails()},e.prototype.onFirstSlideSet=function(t){this.dots.eq(t.index).addClass(\"n2-active\")},e.prototype.onDotClick=function(i){this.slider.directionalChangeToReal(this.originalDots.index(i.currentTarget)),t(i.target).blur()},e.prototype.onSlideSwitch=function(t,i){this.dots.filter(\".n2-active\").removeClass(\"n2-active\"),this.dots.eq(i).addClass(\"n2-active\")},e.prototype.isVisible=function(){return this.bar.is(\":visible\")},e.prototype.getSize=function(){return\"horizontal\"==this.axis?this.bar.height()+this.offset:this.bar.width()+this.offset},e.prototype.initThumbnails=function(){this.parameters.thumbnails.length>0&&this.dots.each(t.proxy(function(i,e){\"\"!=this.parameters.thumbnails[i]&&t(e).on({universalenter:t.proxy(this.showThumbnail,this,i)},{leaveOnSecond:!0})},this))},e.prototype.showThumbnail=function(i,e){var s=this.getThumbnail(i);NextendTween.to(s,.3,{opacity:1}),this.originalDots.eq(i).on(\"universalleave.thumbnailleave\",t.proxy(this.hideThumbnail,this,i,s))},e.prototype.hideThumbnail=function(t,i,e){e.stopPropagation(),this.originalDots.eq(t).off(\"universalleave.thumbnailleave\"),NextendTween.to(i,.3,{opacity:0,onComplete:function(){i.remove()}})},e.prototype.getThumbnail=function(i){var e=this.originalDots.eq(i),s=this.slider.sliderElement.offset(),o=e.offset(),a=e.outerWidth(),r=e.outerHeight(),n=t(\"<div\/>\").append(t(\"<div\/>\").css({width:this.parameters.thumbnailWidth,height:this.parameters.thumbnailHeight,backgroundImage:'url(\"'+this.parameters.thumbnails[i]+'\")'}).addClass(\"n2-ss-bullet-thumbnail\")).addClass(this.parameters.thumbnailStyle).addClass(\"n2-ss-bullet-thumbnail-container\").appendTo(this.slider.sliderElement);switch(this.parameters.thumbnailPosition){case\"right\":n.css({left:o.left-s.left+a,top:o.top-s.top+r\/2-n.outerHeight(!0)\/2});break;case\"left\":n.css({left:o.left-s.left-n.outerWidth(!0),top:o.top-s.top+r\/2-n.outerHeight(!0)\/2});break;case\"top\":n.css({left:o.left-s.left+a\/2-n.outerWidth(!0)\/2,top:o.top-s.top-n.outerHeight(!0)});break;case\"bottom\":n.css({left:o.left-s.left+a\/2-n.outerWidth(!0)\/2,top:o.top-s.top+r})}return e.data(\"thumbnail\",n),n},e.prototype.onSlideCountChanged=function(i,e,s){this.dots=t();for(var o=0;this.originalDots.length>o;o++)o%s==0?this.dots=this.dots.add(this.originalDots.eq(o).css(\"display\",\"\")):this.originalDots.eq(o).css(\"display\",\"none\");this.parameters.numeric&&this.dots.each(function(t,i){i.innerHTML=t+1})},e});","new N2Classes.SmartSliderWidgetBulletTransition(this, {\"overlay\":true,\"area\":12,\"thumbnailWidth\":120,\"thumbnailHeight\":81,\"thumbnailStyle\":\"n2-style-42845aa02120076deb3a5681d1d750ac-simple \",\"thumbnailPosition\":\"top\",\"thumbnails\":[\"https:\\\/\\\/smartslider3.com\\\/sample\\\/developerthumbnail.jpg\",\"https:\\\/\\\/smartslider3.com\\\/sample\\\/artdirectorthumbnail.jpg\",\"https:\\\/\\\/smartslider3.com\\\/sample\\\/photographerthumbnail.jpg\"],\"action\":\"click\",\"numeric\":0});"],"allowBGImageAttachmentFixed":false,"bgAnimationsColor":"RGBA(51,51,51,1)","bgAnimations":0,"mainanimation":{"type":"horizontal","duration":600,"delay":0,"ease":"easeOutQuad","parallax":0,"shiftedBackgroundAnimation":0},"carousel":1,"dynamicHeight":0})})});</script></head>

<body class="home page-template-default page page-id-14 logged-in admin-bar no-customize-support wp-custom-logo fl-builder robolist-lite elementor-default">
<!-- Header -->

<div id="sidr" class="mobile-menu">
    <div class="menu-close">
        <i class="fa fa-close"></i>
    </div>
    <ul id="menu-menu-1" class=""><li id="menu-item-29" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-14 current_page_item menu-item-29 active"><a title="HOME" href="http://localhost/wordpress/wordpress/">HOME</a></li>
<li id="menu-item-30" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30"><a title="Profile" href="http://localhost/wordpress/wordpress/profile/">Profile</a></li>
<li id="menu-item-35" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a title="Academic" href="http://localhost/wordpress/wordpress/academic/">Academic</a></li>
<li id="menu-item-51" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-51"><a title="Trending Technologies" href="http://localhost/wordpress/wordpress/treanding-jobs/">Trending Technologies</a></li>
<li id="menu-item-81" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-81 dropdown"><a title="Companies" href="http://localhost/wordpress/wordpress/companies/">Companies <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu">
	<li id="menu-item-84" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-84"><a title="IT Companies" href="http://localhost/wordpress/wordpress/it-companies/">IT Companies</a></li>
	<li id="menu-item-90" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-90"><a title="Electrical Companies" href="http://localhost/wordpress/wordpress/electrical-companies/">Electrical Companies</a></li>
	<li id="menu-item-93" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-93"><a title="Civil Companies" href="http://localhost/wordpress/wordpress/civil-companies/">Civil Companies</a></li>
	<li id="menu-item-96" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-96"><a title="Mechenical Companies" href="http://localhost/wordpress/wordpress/mechenical-companies/">Mechenical Companies</a></li>
</ul>
</li>
</ul></div>


<header id="top" class="header hero ">
    <!-- Start of Naviation -->
    <div class="nav-wrapper">
        <div class="container">
            <div class="col-md-2">

                <div class="site-branding">
                    <a href="http://localhost/wordpress/wordpress/" class="custom-logo-link" rel="home" itemprop="url"><img width="644" height="498" src="http://localhost/wordpress/wordpress/wp-content/uploads/2018/08/cropped-jc-2.jpg" class="custom-logo" alt="Job Creator" itemprop="logo" srcset="http://localhost/wordpress/wordpress/wp-content/uploads/2018/08/cropped-jc-2.jpg 644w, http://localhost/wordpress/wordpress/wp-content/uploads/2018/08/cropped-jc-2-300x232.jpg 300w" sizes="(max-width: 644px) 100vw, 644px" /></a>                        <h1 class="site-title"><a href="http://localhost/wordpress/wordpress/" rel="home">Job Creator</a></h1>
                                        </div><!-- .site-branding -->
                <div class="show-mobile">

                    <ul class="nav navbar-nav">
                        <li id="sign-out" class="signout"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><img alt='' src='http://0.gravatar.com/avatar/f5905e5a625788db9dbdfb170a56cc35?s=32&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/f5905e5a625788db9dbdfb170a56cc35?s=64&#038;d=mm&#038;r=g 2x' class='avatar avatar-32 photo' height='32' width='32' /></span></a><ul class="dropdown-menu"><li><a href="http://localhost/wordpress/wordpress/wp-admin/profile.php">Edit Profile</a></li><li><a href="http://localhost/wordpress/wordpress/wp-login.php?action=logout&#038;_wpnonce=78fcf135d1">Sign Out</a></li></ul></li>                                                    <li class="addlisting"><a href="http://localhost/wordpress/wordpress/"><i class="fa fa-plus-circle" aria-hidden="true"></i>Add Listing</a></li>
                                            </ul>
                </div>
                <div class="navbar-header">
                    <a id="simple-menu" class="ninja-btn menu-btn pull-right" href="#sidr"><span></span></a>
                </div>
            </div>
            <div class="col-md-7">
                <nav id="primary-nav" class="navbar navbar-default">
                    <!-- Brand and toggle get grouped for better mobile display -->

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="navbar-collapse">

                        <ul id="menu-menu-2" class="nav navbar-nav"><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-14 current_page_item menu-item-29 active"><a title="HOME" href="http://localhost/wordpress/wordpress/">HOME</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-30"><a title="Profile" href="http://localhost/wordpress/wordpress/profile/">Profile</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a title="Academic" href="http://localhost/wordpress/wordpress/academic/">Academic</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-51"><a title="Trending Technologies" href="http://localhost/wordpress/wordpress/treanding-jobs/">Trending Technologies</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-81 dropdown"><a title="Companies" href="http://localhost/wordpress/wordpress/companies/">Companies <span class="caret"></span></a>
<ul role="menu" class=" dropdown-menu">
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-84"><a title="IT Companies" href="http://localhost/wordpress/wordpress/it-companies/">IT Companies</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-90"><a title="Electrical Companies" href="http://localhost/wordpress/wordpress/electrical-companies/">Electrical Companies</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-93"><a title="Civil Companies" href="http://localhost/wordpress/wordpress/civil-companies/">Civil Companies</a></li>
	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-96"><a title="Mechenical Companies" href="http://localhost/wordpress/wordpress/mechenical-companies/">Mechenical Companies</a></li>
</ul>
</li>
</ul>                    </div><!-- End navbar-collapse -->
                </nav>
            </div>
            <div class="col-md-3">
                <ul class="nav navbar-nav">
                    <li id="sign-out" class="signout"><a class="dropdown-toggle" data-toggle="dropdown" href="#"><img alt='' src='http://0.gravatar.com/avatar/f5905e5a625788db9dbdfb170a56cc35?s=32&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/f5905e5a625788db9dbdfb170a56cc35?s=64&#038;d=mm&#038;r=g 2x' class='avatar avatar-32 photo' height='32' width='32' /></span></a><ul class="dropdown-menu"><li><a href="http://localhost/wordpress/wordpress/wp-admin/profile.php">Edit Profile</a></li><li><a href="http://localhost/wordpress/wordpress/wp-login.php?action=logout&#038;_wpnonce=78fcf135d1">Sign Out</a></li></ul></li>                                        <li class="addlisting"><a href="http://localhost/wordpress/wordpress/"><i class="fa fa-plus-circle" aria-hidden="true"></i>Add Listing</a></li>
                                    </ul>
            </div>
        </div>
    </div>
    <!-- End of Navigation -->

        <div class="inner-banner-wrap"
         >
        <div class="container">
            <div class="row">
                <div class="inner-banner-content">
                    <h2>HOME</h2>
                    <div class="header-breadcrumb">

                        <ul class="breadcrumb"><li><a href="http://localhost/wordpress/wordpress">Home</a></li> <li>HOME</li></ul>                    </div>
                </div>
            </div>
        </div>
    </div>
    </header>
    <div class="section page-section ">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div id="primary" class="content-area">
                        <main id="main" class="site-main">

                            
<article id="post-14" class="post-14 page type-page status-publish hentry">

	
	<div class="entry-content">
		<div class="fl-builder-content fl-builder-content-14 fl-builder-content-primary" data-post-id="14"><div class="fl-row fl-row-fixed-width fl-row-bg-none fl-node-5b6ee38a71546" data-node="5b6ee38a71546">
	<div class="fl-row-content-wrap">
				<div class="fl-row-content fl-row-fixed-width fl-node-content">
		
<div class="fl-col-group fl-node-5b6ee38a799a5" data-node="5b6ee38a799a5">
			<div class="fl-col fl-node-5b6ee38a79d2d" data-node="5b6ee38a79d2d">
	<div class="fl-col-content fl-node-content">
	<div class="fl-module fl-module-beaver-builder-module fl-node-5b6ee38a71234" data-node="5b6ee38a71234">
	<div class="fl-module-content fl-node-content">
		<style>div#n2-ss-1{width:1200px;float:left;margin:0px 0px 0px 0px;}html[dir="rtl"] div#n2-ss-1{float:right;}div#n2-ss-1 .n2-ss-slider-1{position:relative;padding-top:0px;padding-right:0px;padding-bottom:0px;padding-left:0px;height:600px;border-style:solid;border-width:0px;border-color:#3e3e3e;border-color:RGBA(62,62,62,1);border-radius:0px;background-clip:padding-box;background-repeat:repeat;background-position:50% 50%;background-size:cover;background-attachment:scroll;}div#n2-ss-1 .n2-ss-slider-background-video-container{position:absolute;left:0;top:0;width:100%;height:100%;overflow:hidden;}div#n2-ss-1 .n2-ss-slider-2{position:relative;width:100%;height:100%;}.x-firefox div#n2-ss-1 .n2-ss-slider-2{opacity:0.99999;}div#n2-ss-1 .n2-ss-slider-3{position:relative;width:100%;height:100%;overflow:hidden;outline:1px solid rgba(0,0,0,0);z-index:10;}div#n2-ss-1 .n2-ss-slide-backgrounds,div#n2-ss-1 .n2-ss-slider-3 > .n-particles-js-canvas-el,div#n2-ss-1 .n2-ss-slider-3 > .n2-ss-divider{position:absolute;left:0;top:0;width:100%;height:100%;}div#n2-ss-1 .n2-ss-slide-backgrounds{z-index:10;}div#n2-ss-1 .n2-ss-slider-3 > .n-particles-js-canvas-el{z-index:12;}div#n2-ss-1 .n2-ss-slide-backgrounds > *{overflow:hidden;}div#n2-ss-1 .n2-ss-slide{position:absolute;top:0;left:0;width:100%;height:100%;z-index:20;display:block;-webkit-backface-visibility:hidden;}div#n2-ss-1 .n2-ss-layers-container{position:relative;width:1200px;height:600px;}div#n2-ss-1 .n2-ss-parallax-clip > .n2-ss-layers-container{position:absolute;right:0;}div#n2-ss-1 .n2-ss-slide{-webkit-perspective:1000px;perspective:1000px;}div#n2-ss-1 .n2-ss-slide-active{z-index:21;}div#n2-ss-1 .nextend-arrow{cursor:pointer;overflow:hidden;line-height:0 !important;z-index:20;}div#n2-ss-1 .nextend-arrow img{position:relative;min-height:0;min-width:0;vertical-align:top;width:auto;height:auto;max-width:100%;max-height:100%;display:inline;}div#n2-ss-1 .nextend-arrow img.n2-arrow-hover-img{display:none;}div#n2-ss-1 .nextend-arrow:HOVER img.n2-arrow-hover-img{display:inline;}div#n2-ss-1 .nextend-arrow:HOVER img.n2-arrow-normal-img{display:none;}div#n2-ss-1 .nextend-arrow-animated{overflow:hidden;}div#n2-ss-1 .nextend-arrow-animated > div{position:relative;width:100%;height:100%;box-sizing:border-box;}div#n2-ss-1 .nextend-arrow-animated .n2-active{position:absolute;}div#n2-ss-1 .nextend-arrow-animated-fade{transition:background 0.3s, opacity 0.4s;}div#n2-ss-1 .nextend-arrow-animated-horizontal > div{transition:all 0.4s;left:0;}div#n2-ss-1 .nextend-arrow-animated-horizontal .n2-active{top:0;}div#n2-ss-1 .nextend-arrow-previous.nextend-arrow-animated-horizontal:HOVER > div,div#n2-ss-1 .nextend-arrow-next.nextend-arrow-animated-horizontal .n2-active{left:-100%;}div#n2-ss-1 .nextend-arrow-previous.nextend-arrow-animated-horizontal .n2-active,div#n2-ss-1 .nextend-arrow-next.nextend-arrow-animated-horizontal:HOVER > div{left:100%;}div#n2-ss-1 .nextend-arrow.nextend-arrow-animated-horizontal:HOVER .n2-active{left:0;}div#n2-ss-1 .nextend-arrow-animated-vertical > div{transition:all 0.4s;top:0;}div#n2-ss-1 .nextend-arrow-animated-vertical .n2-active{left:0;}div#n2-ss-1 .nextend-arrow-animated-vertical .n2-active{top:-100%;}div#n2-ss-1 .nextend-arrow-animated-vertical:HOVER > div{top:100%;}div#n2-ss-1 .nextend-arrow-animated-vertical:HOVER .n2-active{top:0;}div#n2-ss-1 .n2-ss-control-bullet{visibility:hidden;text-align:center;justify-content:center;}div#n2-ss-1 .n2-ss-control-bullet-horizontal.n2-ss-control-bullet-fullsize{width:100%;}div#n2-ss-1 .n2-ss-control-bullet-vertical.n2-ss-control-bullet-fullsize{height:100%;flex-flow:column;}div#n2-ss-1 .nextend-bullet-bar{display:inline-flex;visibility:visible;align-items:center;flex-wrap:wrap;}div#n2-ss-1 .n2-bar-justify-content-left{justify-content:flex-start;}div#n2-ss-1 .n2-bar-justify-content-center{justify-content:center;}div#n2-ss-1 .n2-bar-justify-content-right{justify-content:flex-end;}div#n2-ss-1 .n2-ss-control-bullet-vertical > .nextend-bullet-bar{flex-flow:column;}div#n2-ss-1 .n2-ss-control-bullet-fullsize > .nextend-bullet-bar{display:flex;}div#n2-ss-1 .n2-ss-control-bullet-horizontal.n2-ss-control-bullet-fullsize > .nextend-bullet-bar{flex:1 1 auto;}div#n2-ss-1 .n2-ss-control-bullet-vertical.n2-ss-control-bullet-fullsize > .nextend-bullet-bar{height:100%;}div#n2-ss-1 .nextend-bullet-bar > div{display:inline-block;cursor:pointer;transition:background-color 0.4s;vertical-align:top;}div#n2-ss-1 .nextend-bullet-bar > div.n2-active{cursor:default;}div#n2-ss-1 div.n2-ss-bullet-thumbnail-container{position:absolute;opacity:0;z-index:10000000;}div#n2-ss-1 .n2-ss-bullet-thumbnail-container .n2-ss-bullet-thumbnail{background-size:cover;background-repeat:no-repeat;background-position:center;}div#n2-ss-1 .n2-ss-layer .n2-font-b3345663dc8b9cef8e1c2d7598218f7d-hover{font-family: 'Raleway','Arial';color: #0b0b0b;font-size:225%;text-shadow: none;line-height: 1.5;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: 10px;word-spacing: normal;text-transform: uppercase;}div#n2-ss-1 .n2-style-34aabac2d1a1f42ea86057074a5dba21-heading{background: #ffffff;background: RGBA(255,255,255,0.8);opacity:1;padding:0.4em 1em 0.4em 1em ;box-shadow: none;border-width: 0px;border-style: solid;border-color: #000000; border-color: RGBA(0,0,0,1);border-radius:0px;}div#n2-ss-1 .n2-ss-layer .n2-font-f7cfdde6001a78b89d1f32639ff1ac5c-hover{font-family: 'Raleway','Arial';color: #ffffff;font-size:137.5%;text-shadow: none;line-height: 1;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: 2px;word-spacing: normal;text-transform: none;}div#n2-ss-1 .n2-style-ef33d9149525c4afb4ba031e6eb66c9e-heading{background: #000000;background: RGBA(0,0,0,0.8);opacity:1;padding:0.8em 1em 0.8em 1em ;box-shadow: none;border-width: 0px;border-style: solid;border-color: #000000; border-color: RGBA(0,0,0,1);border-radius:0px;}div#n2-ss-1 .n2-style-09efebcef1f2f45d29438e0cabcf79bc-dot{background: #000000;background: RGBA(0,0,0,0.67);opacity:1;padding:5px 5px 5px 5px ;box-shadow: none;border-width: 0px;border-style: solid;border-color: #000000; border-color: RGBA(0,0,0,1);border-radius:50px;margin: 4px;}div#n2-ss-1 .n2-style-09efebcef1f2f45d29438e0cabcf79bc-dot.n2-active, div#n2-ss-1 .n2-style-09efebcef1f2f45d29438e0cabcf79bc-dot:HOVER{background: #09b474;}div#n2-ss-1 .n2-style-42845aa02120076deb3a5681d1d750ac-simple{background: #000000;background: RGBA(0,0,0,0.5);opacity:1;padding:3px 3px 3px 3px ;box-shadow: none;border-width: 0px;border-style: solid;border-color: #000000; border-color: RGBA(0,0,0,1);border-radius:3px;margin: 5px;}</style><div id="n2-ss-1-align" class="n2-ss-align"><div class="n2-padding"><div id="n2-ss-1" data-creator="Smart Slider 3" class="n2-ss-slider n2-ow n2-has-hover n2notransition n2-ss-load-fade " data-minFontSizedesktopPortrait="1" data-minFontSizedesktopLandscape="1" data-minFontSizetabletPortrait="1" data-minFontSizetabletLandscape="1" data-minFontSizemobilePortrait="1" data-minFontSizemobileLandscape="1" style="font-size: 16px;" data-fontsize="16">
        <div class="n2-ss-slider-1 n2-ss-swipe-element n2-ow" style="">
                        <div class="n2-ss-slider-2 n2-ow">
                                <div class="n2-ss-slider-3 n2-ow" style="">

                    <div class="n2-ss-slide-backgrounds"></div><div data-first="1" data-slide-duration="0" data-id="1" style="" class="n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-1"><div class="n2-ss-slide-background n2-ow" data-mode="fill"><img data-hash="7148fa26ad6dd9ee953b6c3f5f30c99d" data-desktop="https://smartslider3.com/sample/programmer.jpg" data-blur="0" data-opacity="100" data-x="50" data-y="50" src="https://smartslider3.com/sample/programmer.jpg" alt="" /></div><div class="n2-ss-layers-container n2-ow" data-csstextalign="center" style=""><div class="n2-ss-layer n2-ow" style="overflow:;" data-csstextalign="inherit" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-pm="content" data-desktopportraitpadding="10|*|10|*|10|*|10|*|px+" data-desktopportraitinneralign="inherit" data-sstype="content" data-hasbackground="0" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="1" data-desktopportraitfontsize="100" data-mobileportraitfontsize="60" data-plugin="rendered"><div class="n2-ss-section-main-content n2-ss-layer-content n2-ow" style="padding:0.625em 0.625em 0.625em 0.625em ;" data-verticalalign="center"><div class="n2-ss-layer n2-ow" style="margin:0.625em 0em 0.625em 0em ;overflow:visible;" data-pm="normal" data-desktopportraitmargin="10|*|0|*|10|*|0|*|px+" data-desktopportraitheight="0" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><h2 id="n2-ss-1item1" class="n2-font-b3345663dc8b9cef8e1c2d7598218f7d-hover n2-style-34aabac2d1a1f42ea86057074a5dba21-heading   n2-ow" style="display:inline-block;">Martin Dwyer</h2></div><div class="n2-ss-layer n2-ow" style="margin:0em 0em 0em 0em ;overflow:visible;" data-pm="normal" data-desktopportraitmargin="0|*|0|*|0|*|0|*|px+" data-desktopportraitheight="0" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><h2 id="n2-ss-1item2" class="n2-font-f7cfdde6001a78b89d1f32639ff1ac5c-hover n2-style-ef33d9149525c4afb4ba031e6eb66c9e-heading   n2-ow" style="display:inline-block;white-space:nowrap;">Application Developer</h2></div></div></div></div></div><div data-slide-duration="0" data-id="2" style="" class="n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-2"><div class="n2-ss-slide-background n2-ow" data-mode="fill"><img data-hash="6681af77aa8c9f342a3f8a98939dca43" data-desktop="https://smartslider3.com/sample/free1.jpg" data-blur="0" data-opacity="100" data-x="50" data-y="50" src="https://smartslider3.com/sample/free1.jpg" alt="" /></div><div class="n2-ss-layers-container n2-ow" data-csstextalign="center" style=""><div class="n2-ss-layer n2-ow" style="overflow:;" data-csstextalign="inherit" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-pm="content" data-desktopportraitpadding="10|*|10|*|10|*|10|*|px+" data-desktopportraitinneralign="inherit" data-sstype="content" data-hasbackground="0" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="1" data-desktopportraitfontsize="100" data-mobileportraitfontsize="60" data-plugin="rendered"><div class="n2-ss-section-main-content n2-ss-layer-content n2-ow" style="padding:0.625em 0.625em 0.625em 0.625em ;" data-verticalalign="center"><div class="n2-ss-layer n2-ow" style="margin:0.625em 0em 0.625em 0em ;overflow:visible;" data-pm="normal" data-desktopportraitmargin="10|*|0|*|10|*|0|*|px+" data-desktopportraitheight="0" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><h2 id="n2-ss-1item3" class="n2-font-b3345663dc8b9cef8e1c2d7598218f7d-hover n2-style-34aabac2d1a1f42ea86057074a5dba21-heading   n2-ow" style="display:inline-block;">Rachel Wright</h2></div><div class="n2-ss-layer n2-ow" style="margin:0em 0em 0em 0em ;overflow:visible;" data-pm="normal" data-desktopportraitmargin="0|*|0|*|0|*|0|*|px+" data-desktopportraitheight="0" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><h2 id="n2-ss-1item4" class="n2-font-f7cfdde6001a78b89d1f32639ff1ac5c-hover n2-style-ef33d9149525c4afb4ba031e6eb66c9e-heading   n2-ow" style="display:inline-block;white-space:nowrap;">Art Director & Photographer</h2></div></div></div></div></div><div data-slide-duration="0" data-id="3" style="" class="n2-ss-slide n2-ss-canvas n2-ow  n2-ss-slide-3"><div class="n2-ss-slide-background n2-ow" data-mode="fill"><img data-hash="2ebcc61fcb32c829e4927fbfd782ff7a" data-desktop="https://smartslider3.com/sample/photographer.jpg" data-blur="0" data-opacity="100" data-x="50" data-y="50" src="https://smartslider3.com/sample/photographer.jpg" alt="" /></div><div class="n2-ss-layers-container n2-ow" data-csstextalign="center" style=""><div class="n2-ss-layer n2-ow" style="overflow:;" data-csstextalign="inherit" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-pm="content" data-desktopportraitpadding="10|*|10|*|10|*|10|*|px+" data-desktopportraitinneralign="inherit" data-sstype="content" data-hasbackground="0" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="1" data-desktopportraitfontsize="100" data-mobileportraitfontsize="60" data-plugin="rendered"><div class="n2-ss-section-main-content n2-ss-layer-content n2-ow" style="padding:0.625em 0.625em 0.625em 0.625em ;" data-verticalalign="center"><div class="n2-ss-layer n2-ow" style="margin:0.625em 0em 0.625em 0em ;overflow:visible;" data-pm="normal" data-desktopportraitmargin="10|*|0|*|10|*|0|*|px+" data-desktopportraitheight="0" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><h2 id="n2-ss-1item5" class="n2-font-b3345663dc8b9cef8e1c2d7598218f7d-hover n2-style-34aabac2d1a1f42ea86057074a5dba21-heading   n2-ow" style="display:inline-block;">Andrew Butler</h2></div><div class="n2-ss-layer n2-ow" style="margin:0em 0em 0em 0em ;overflow:visible;" data-pm="normal" data-desktopportraitmargin="0|*|0|*|0|*|0|*|px+" data-desktopportraitheight="0" data-has-maxwidth="0" data-desktopportraitmaxwidth="0" data-cssselfalign="inherit" data-desktopportraitselfalign="inherit" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><h2 id="n2-ss-1item6" class="n2-font-f7cfdde6001a78b89d1f32639ff1ac5c-hover n2-style-ef33d9149525c4afb4ba031e6eb66c9e-heading   n2-ow" style="display:inline-block;">Photographer & Illustrator</h2></div></div></div></div></div>                </div>
            </div>
            <div data-ssleft="0+15" data-sstop="height/2-previousheight/2" id="n2-ss-1-arrow-previous" class="n2-ss-widget n2-ss-widget-display-desktop n2-ss-widget-display-tablet n2-ss-widget-display-mobile nextend-arrow n2-ow nextend-arrow-previous  nextend-arrow-animated-fade n2-ib" style="position: absolute;" role="button" aria-label="Previous slide" tabindex="0"><img class="n2-ow" data-no-lazy="1" data-hack="data-lazy-src" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTEuNDMzIDE1Ljk5MkwyMi42OSA1LjcxMmMuMzkzLS4zOS4zOTMtMS4wMyAwLTEuNDItLjM5My0uMzktMS4wMy0uMzktMS40MjMgMGwtMTEuOTggMTAuOTRjLS4yMS4yMS0uMy40OS0uMjg1Ljc2LS4wMTUuMjguMDc1LjU2LjI4NC43N2wxMS45OCAxMC45NGMuMzkzLjM5IDEuMDMuMzkgMS40MjQgMCAuMzkzLS40LjM5My0xLjAzIDAtMS40MmwtMTEuMjU3LTEwLjI5IiBmaWxsPSIjZmZmZmZmIiBvcGFjaXR5PSIwLjgiIGZpbGwtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==" alt="previous arrow" /></div>
<div data-ssright="0+15" data-sstop="height/2-nextheight/2" id="n2-ss-1-arrow-next" class="n2-ss-widget n2-ss-widget-display-desktop n2-ss-widget-display-tablet n2-ss-widget-display-mobile nextend-arrow n2-ow nextend-arrow-next  nextend-arrow-animated-fade n2-ib" style="position: absolute;" role="button" aria-label="Next slide" tabindex="0"><img class="n2-ow" data-no-lazy="1" data-hack="data-lazy-src" src="data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzIiIGhlaWdodD0iMzIiIHZpZXdCb3g9IjAgMCAzMiAzMiIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTAuNzIyIDQuMjkzYy0uMzk0LS4zOS0xLjAzMi0uMzktMS40MjcgMC0uMzkzLjM5LS4zOTMgMS4wMyAwIDEuNDJsMTEuMjgzIDEwLjI4LTExLjI4MyAxMC4yOWMtLjM5My4zOS0uMzkzIDEuMDIgMCAxLjQyLjM5NS4zOSAxLjAzMy4zOSAxLjQyNyAwbDEyLjAwNy0xMC45NGMuMjEtLjIxLjMtLjQ5LjI4NC0uNzcuMDE0LS4yNy0uMDc2LS41NS0uMjg2LS43NkwxMC43MiA0LjI5M3oiIGZpbGw9IiNmZmZmZmYiIG9wYWNpdHk9IjAuOCIgZmlsbC1ydWxlPSJldmVub2RkIi8+PC9zdmc+" alt="next arrow" /></div>
        </div>
        <div data-position="below" data-offset="10" class="n2-ss-widget n2-ss-widget-display-desktop n2-ss-widget-display-tablet n2-ss-widget-display-mobile  n2-flex n2-ss-control-bullet n2-ss-control-bullet-horizontal" style="margin-top:10px;"><div class=" nextend-bullet-bar n2-ow n2-bar-justify-content-center"><div class="n2-ow n2-style-09efebcef1f2f45d29438e0cabcf79bc-dot " tabindex="0"></div><div class="n2-ow n2-style-09efebcef1f2f45d29438e0cabcf79bc-dot " tabindex="0"></div><div class="n2-ow n2-style-09efebcef1f2f45d29438e0cabcf79bc-dot " tabindex="0"></div></div></div>
</div><div class="n2-clear"></div><div id="n2-ss-1-spinner" style="display: none;"><div><div class="n2-ss-spinner-simple-white-container"><div class="n2-ss-spinner-simple-white"></div></div></div></div></div></div><div id="n2-ss-1-placeholder" style="position: relative;z-index:2;background-color:RGBA(0,0,0,0);max-height:3000px; background-color:RGBA(255,255,255,0);"><img style="width: 100%; max-width:3000px; display: block;opacity:0;" class="n2-ow" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMCIgd2lkdGg9IjEyMDAiIGhlaWdodD0iNjAwIiA+PC9zdmc+" alt="Slider" /></div>	</div>
</div>
	</div>
</div>
	</div>
		</div>
	</div>
</div>
<div class="fl-row fl-row-fixed-width fl-row-bg-none fl-node-5b6e9b2b09324" data-node="5b6e9b2b09324">
	<div class="fl-row-content-wrap">
				<div class="fl-row-content fl-row-fixed-width fl-node-content">
		
<div class="fl-col-group fl-node-5b6e9b2b0cf24" data-node="5b6e9b2b0cf24">
			<div class="fl-col fl-node-5b6e9b2b0d25c fl-col-small" data-node="5b6e9b2b0d25c">
	<div class="fl-col-content fl-node-content">
	<div class="fl-module fl-module-photo fl-node-5b6e9b4a12217" data-node="5b6e9b4a12217">
	<div class="fl-module-content fl-node-content">
		<div class="fl-photo fl-photo-align-center" itemscope itemtype="https://schema.org/ImageObject">
	<div class="fl-photo-content fl-photo-img-png">
				<img class="fl-photo-img wp-image-66 size-full" src="http://localhost/wordpress/wordpress/wp-content/uploads/2018/08/digit.png" alt="digit.png" itemprop="image" height="150" width="200" title="digit.png"  />
					</div>
	</div>
	</div>
</div>
	</div>
</div>
			<div class="fl-col fl-node-5b6e9b2b0d26f" data-node="5b6e9b2b0d26f">
	<div class="fl-col-content fl-node-content">
	<div class="fl-module fl-module-rich-text fl-node-5b6e9b6775717" data-node="5b6e9b6775717">
	<div class="fl-module-content fl-node-content">
		<div class="fl-rich-text">
	<p>mhh b mhnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn.i;l</p>
</div>
	</div>
</div>
	</div>
</div>
	</div>
		</div>
	</div>
</div>
</div>	</div><!-- .entry-content -->

			<footer class="entry-footer">
			<span class="edit-link"><a class="post-edit-link" href="http://localhost/wordpress/wordpress/wp-admin/post.php?post=14&#038;action=edit">Edit <span class="screen-reader-text">HOME</span></a></span>		</footer><!-- .entry-footer -->
	</article><!-- #post-14 -->

                        </main><!-- #main -->
                    </div><!-- #primary -->
                </div>


                                    <div class="col-md-4">
                        
<aside id="secondary" class="widget-area">
	<section id="search-2" class="widget widget_search"><form role="search" method="get" class="search-form" action="http://localhost/wordpress/wordpress/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form></section>		<section id="recent-posts-2" class="widget widget_recent_entries">		<h2 class="widget-title">Recent Posts</h2>		<ul>
											<li>
					<a href="http://localhost/wordpress/wordpress/2018/08/04/hello-world/">Hello world!</a>
									</li>
					</ul>
		</section><section id="recent-comments-2" class="widget widget_recent_comments"><h2 class="widget-title">Recent Comments</h2><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link"><a href='https://wordpress.org/' rel='external nofollow' class='url'>A WordPress Commenter</a></span> on <a href="http://localhost/wordpress/wordpress/2018/08/04/hello-world/#comment-1">Hello world!</a></li></ul></section></aside><!-- #secondary -->
                    </div>
                
            </div>
        </div>
    </div>
    <footer>
    
    <div class="botfooter">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="copyright">
                        <p>
                            <a href="https://wordpress.org/">Proudly powered by WordPress</a> <span class="sep"> | </span>
                            Theme: <a target="_blank" href="https://codethemes.co/product/robolist-lite" rel="nofollow" title="Robolist Lite">Robolist Lite</a> by Code Themes.                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Advanced Ads: the following code is used for automatic error detection and only visible to admins-->
		<style>.hidden { display: none; } .advads-adminbar-is-warnings { background: #a54811 ! important; color: #fff !important; }
		#wp-admin-bar-advanced_ads_ad_health-default a:after { content: "\25BA"; margin-left: .5em; font-size: smaller; }
		.advanced-ads-highlight-ads { outline:4px solid blue !important; }</style>
		<script type="text/javascript" src="http://localhost/wordpress/wordpress/wp-content/plugins/advanced-ads/admin/assets/js/advertisement.js"></script>
		<script>
		var advanced_ads_frontend_checks = {
			showCount: function() {
				try {
					// Count only warnings that have the 'advanced_ads_ad_health_warning' class.
					var warning_count = document.querySelectorAll( '.advanced_ads_ad_health_warning:not(.hidden)' ).length;
					var fine_item = document.getElementById( 'wp-admin-bar-advanced_ads_ad_health_fine' );
				} catch ( e ) { return; }

				if ( warning_count ) {
					var header = document.querySelector( '#wp-admin-bar-advanced_ads_ad_health > div' );

					if ( fine_item ) {
						// Hide 'fine' item.
						fine_item.className += ' hidden';
					}

					if ( header ) {
						header.innerHTML = header.innerHTML.replace(/ <i>(.*?)<\/i>/, '') + ' <i>(' + warning_count + ')</i>';
						header.className += ' advads-adminbar-is-warnings';
					}
				}
			},
			add_item_to_node: function( selector, item ) {
				var selector = document.querySelector( selector );
				if ( selector ) {
					selector.className = selector.className.replace( 'hidden', '' );
					selector.innerHTML = selector.innerHTML.replace( /(<i>)(.*?)(<\/i>)/, function( match, p1, p2, p3 ) {
						p2 = ( p2 ) ? p2.split( ', ' ) : [];
						if ( p2.indexOf( item ) === -1 ) p2.push( item );
						return p1 + p2.join( ', ' ) + p3;
					} );
					advanced_ads_frontend_checks.showCount();
				}
			}
		};

		(function(d, w) {
				// var not_head_jQuery = typeof jQuery === 'undefined';

				var addEvent = function( obj, type, fn ) {
					if ( obj.addEventListener )
						obj.addEventListener( type, fn, false );
					else if ( obj.attachEvent )
						obj.attachEvent( 'on' + type, function() { return fn.call( obj, window.event ); } );
				};

				function highlight_ads() {
					try {
					    var ad_wrappers = document.querySelectorAll('div[id^="local-"]')
					} catch ( e ) { return; }
				    for ( i = 0; i < ad_wrappers.length; i++ ) {
				        if ( this.checked ) {
				            ad_wrappers[i].className += ' advanced-ads-highlight-ads';
				        } else {
				            ad_wrappers[i].className = ad_wrappers[i].className.replace( 'advanced-ads-highlight-ads', '' );
				        }
				    }
				}

				advanced_ads_ready( function() {
					var adblock_item = d.getElementById( 'wp-admin-bar-advanced_ads_ad_health_adblocker_enabled' );
					// jQuery_item = d.getElementById( 'wp-admin-bar-advanced_ads_ad_health_jquery' ),

					var highlight_checkbox = d.getElementById( 'advanced_ads_highlight_ads_checkbox' );
					if ( highlight_checkbox ) {
						addEvent( highlight_checkbox, 'change', highlight_ads );
					}

					if ( adblock_item && typeof advanced_ads_adblocker_test === 'undefined' ) {
						// show hidden item
						adblock_item.className = adblock_item.className.replace( /hidden/, '' );
					}

					/* if ( jQuery_item && not_head_jQuery ) {
						// show hidden item
						jQuery_item.className = jQuery_item.className.replace( /hidden/, '' );
					}*/

					advanced_ads_frontend_checks.showCount();
				});
				
									// show warning if AdSense ad is hidden
					setTimeout( function(){
						advanced_ads_ready( advads_highlight_hidden_adsense );
					}, 2000 );
					function advads_highlight_hidden_adsense(){
						if ( window.jQuery ) {
							var advads_ad_health_check_adsense_hidden_ids = [];
							jQuery('ins.adsbygoogle').each( function(){
								if( ! jQuery( this ).parent().is(':visible') ){
								advads_ad_health_check_adsense_hidden_ids.push( this.dataset.adSlot );
								}
							});
							if( advads_ad_health_check_adsense_hidden_ids.length ){
								var advads_has_hidden_adsense_link = document.querySelector( '.advanced_ads_ad_health_hidden_adsense' );
								if ( advads_has_hidden_adsense_link ) {
									advads_has_hidden_adsense_link.className = advads_has_hidden_adsense_link.className.replace( 'hidden', '' );
									advads_has_hidden_adsense_link.innerHTML = advads_has_hidden_adsense_link.innerHTML.replace( /(<i>)(.*?)(<\/i>)/, function( match, p1, p2, p3 ) {
										var ad_id = advads_ad_health_check_adsense_hidden_ids.join( ', ');
										p2 = ( p2 ) ? p2.split( ', ' ) : [];
										if ( p2.indexOf( ad_id ) === -1 ) p2.push( ad_id );
										return p1 + p2.join( ', ' ) + p3;
									} );
									advanced_ads_frontend_checks.showCount();
								}
							}
						}
					};

					// highlight AdSense Auto Ads ads 3 seconds after site loaded
					setTimeout( function(){
						advanced_ads_ready( advads_highlight_adsense_autoads )
					}, 3000 );
					function advads_highlight_adsense_autoads(){
						if ( ! window.jQuery ) {
							window.console && window.console.log( 'Advanced Ads: jQuery not found. Some Ad Health warnings will not be shown' );
							return;
						}
						var autoads_ads = jQuery(document).find('.google-auto-placed');
						jQuery( '<p class="advads-autoads-hint" style="background-color:#0085ba;color:#fff;font-size:0.8em;padding:5px;">This ad was automatically placed here by AdSense. <a href="https://wpadvancedads.com/adsense-in-random-positions-auto-ads/#utm_source=advanced-ads&utm_medium=link&utm_campaign=frontend-autoads-ads" target="_blank" style="color:#fff;border-color:#fff;">Click here to learn more</a>.</p>' ).prependTo( autoads_ads );
						// show Auto Ads warning in Adhealth Bar if relevant
						if( autoads_ads.length ){
							var advads_autoads_link = document.querySelector( '#wp-admin-bar-advanced_ads_autoads_displayed.hidden' );
							if ( advads_autoads_link ) {
								advads_autoads_link.className = advads_autoads_link.className.replace( 'hidden', '' );
							}
							advanced_ads_frontend_checks.showCount();
						}

					}
						})(document, window);
		</script>
		<script>
		var advanced_ads_ga_UID = false;
		var advanced_ads_ga_anonymIP = true;
advanced_ads_check_adblocker=function(t){function e(t){(window.requestAnimationFrame||window.mozRequestAnimationFrame||window.webkitRequestAnimationFrame||function(t){return setTimeout(t,16)}).call(window,t)}var n=[],a=null;return e(function(){var t=document.createElement("div");t.innerHTML="&nbsp;",t.setAttribute("class","ad_unit ad-unit text-ad text_ad pub_300x250"),t.setAttribute("style","width: 1px !important; height: 1px !important; position: absolute !important; left: 0px !important; top: 0px !important; overflow: hidden !important;"),document.body.appendChild(t),e(function(){var e=window.getComputedStyle&&window.getComputedStyle(t),o=e&&e.getPropertyValue("-moz-binding");a=e&&"none"===e.getPropertyValue("display")||"string"==typeof o&&-1!==o.indexOf("about:");for(var i=0;i<n.length;i++)n[i](a);n=[]})}),function(t){if(null===a)return void n.push(t);t(a)}}(),function(){var t=function(t,e){this.name=t,this.UID=e,this.analyticsObject=null;var n=this,a={hitType:"event",eventCategory:"Advanced Ads",eventAction:"AdBlock",eventLabel:"Yes",nonInteraction:!0,transport:"beacon"};this.analyticsObject="string"==typeof GoogleAnalyticsObject&&"function"==typeof window[GoogleAnalyticsObject]&&window[GoogleAnalyticsObject],!1===this.analyticsObject?(!function(t,e,n,a,o,i,d){t.GoogleAnalyticsObject=o,t[o]=t[o]||function(){(t[o].q=t[o].q||[]).push(arguments)},t[o].l=1*new Date,i=e.createElement(n),d=e.getElementsByTagName(n)[0],i.async=1,i.src="https://www.google-analytics.com/analytics.js",d.parentNode.insertBefore(i,d)}(window,document,"script",0,"_advads_ga"),_advads_ga("create",n.UID,"auto",this.name),advanced_ads_ga_anonymIP&&_advads_ga("set","anonymizeIp",!0),_advads_ga(n.name+".send",a)):(window.console&&window.console.log("Advanced Ads Analytics >> using other's variable named `"+GoogleAnalyticsObject+"`"),window[GoogleAnalyticsObject]("create",n.UID,"auto",this.name),window[GoogleAnalyticsObject]("set","anonymizeIp",!0),window[GoogleAnalyticsObject](n.name+".send",a))};advanced_ads_check_adblocker(function(e){e&&"string"==typeof advanced_ads_ga_UID&&advanced_ads_ga_UID&&new t("advadsTracker",advanced_ads_ga_UID)})}();		
		</script><script type="text/javascript">

if(typeof jQuery == 'undefined' || typeof jQuery.fn.on == 'undefined') {
	document.write('<script src="http://localhost/wordpress/wordpress/wp-includes/js/jquery/jquery.js"><\/script>');
	document.write('<script src="http://localhost/wordpress/wordpress/wp-includes/js/jquery/jquery-migrate.min.js"><\/script>');
}

</script>
<style>[class*="fa fa-"]{font-family: FontAwesome !important;}</style><link rel='stylesheet' id='jp-front-styles-css'  href='http://localhost/wordpress/wordpress/wp-content/plugins/job-postings/include/../css/style.css?v=1.7.8&#038;ver=4.9.8' type='text/css' media='all' />
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-includes/js/admin-bar.min.js?ver=4.9.8'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/uploads/bb-plugin/cache/14-layout.js?ver=79eac36fbb861a08d6c236ca92b0fab9'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/js/navigation.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/js/skip-link-focus-fix.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/bootstrap.min.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/slick.min.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/tabs.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/fitvids.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/sticky-header.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/jarallax.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/sidr.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/bootstrap-select.min.js?ver=20151215'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var robolist_lite_params = {"login_url":"http:\/\/localhost\/wordpress\/wordpress\/wp-login.php","listings_page_url":"http:\/\/localhost\/wordpress\/wordpress\/jobs\/","strings":{"wp-job-manager-file-upload":"Add Photo","no_job_listings_found":"No results","results-no":"Results"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/themes/robolist-lite/assets/js/app.js?ver=20151215'></script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-includes/js/wp-embed.min.js?ver=4.9.8'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var jpsd = {"ajaxurl":"http:\/\/localhost\/wordpress\/wordpress\/wp-admin\/admin-ajax.php","no_name":"Please input template name."};
/* ]]> */
</script>
<script type='text/javascript' src='http://localhost/wordpress/wordpress/wp-content/plugins/job-postings/include/../js/script.js?v=1.7.8&#038;ver=4.9.8'></script>
	<!--[if lte IE 8]>
		<script type="text/javascript">
			document.body.className = document.body.className.replace( /(^|\s)(no-)?customize-support(?=\s|$)/, '' ) + ' no-customize-support';
		</script>
	<![endif]-->
	<!--[if gte IE 9]><!-->
		<script type="text/javascript">
			(function() {
				var request, b = document.body, c = 'className', cs = 'customize-support', rcs = new RegExp('(^|\\s+)(no-)?'+cs+'(\\s+|$)');

						request = true;
		
				b[c] = b[c].replace( rcs, ' ' );
				// The customizer requires postMessage and CORS (if the site is cross domain)
				b[c] += ( window.postMessage && request ? ' ' : ' no-' ) + cs;
			}());
		</script>
	<!--<![endif]-->
			<div id="wpadminbar" class="nojq nojs">
							<a class="screen-reader-shortcut" href="#wp-toolbar" tabindex="1">Skip to toolbar</a>
						<div class="quicklinks" id="wp-toolbar" role="navigation" aria-label="Toolbar" tabindex="0">
				<ul id="wp-admin-bar-root-default" class="ab-top-menu">
		<li id="wp-admin-bar-wp-logo" class="menupop"><a class="ab-item" aria-haspopup="true" href="http://localhost/wordpress/wordpress/wp-admin/about.php"><span class="ab-icon"></span><span class="screen-reader-text">About WordPress</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-wp-logo-default" class="ab-submenu">
		<li id="wp-admin-bar-about"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/about.php">About WordPress</a>		</li></ul><ul id="wp-admin-bar-wp-logo-external" class="ab-sub-secondary ab-submenu">
		<li id="wp-admin-bar-wporg"><a class="ab-item" href="https://wordpress.org/">WordPress.org</a>		</li>
		<li id="wp-admin-bar-documentation"><a class="ab-item" href="https://codex.wordpress.org/">Documentation</a>		</li>
		<li id="wp-admin-bar-support-forums"><a class="ab-item" href="https://wordpress.org/support/">Support Forums</a>		</li>
		<li id="wp-admin-bar-feedback"><a class="ab-item" href="https://wordpress.org/support/forum/requests-and-feedback">Feedback</a>		</li></ul></div>		</li>
		<li id="wp-admin-bar-site-name" class="menupop"><a class="ab-item" aria-haspopup="true" href="http://localhost/wordpress/wordpress/wp-admin/">Job Creator</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-site-name-default" class="ab-submenu">
		<li id="wp-admin-bar-dashboard"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/">Dashboard</a>		</li></ul><ul id="wp-admin-bar-appearance" class="ab-submenu">
		<li id="wp-admin-bar-themes"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/themes.php">Themes</a>		</li>
		<li id="wp-admin-bar-widgets"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/widgets.php">Widgets</a>		</li>
		<li id="wp-admin-bar-menus"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/nav-menus.php">Menus</a>		</li>
		<li id="wp-admin-bar-background" class="hide-if-customize"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/themes.php?page=custom-background">Background</a>		</li>
		<li id="wp-admin-bar-header" class="hide-if-customize"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/themes.php?page=custom-header">Header</a>		</li></ul></div>		</li>
		<li id="wp-admin-bar-customize" class="hide-if-no-customize"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/customize.php?url=http%3A%2F%2Flocalhost%2Fwordpress%2Fwordpress%2F">Customize</a>		</li>
		<li id="wp-admin-bar-updates"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/update-core.php" title="1 Plugin Update"><span class="ab-icon"></span><span class="ab-label">1</span><span class="screen-reader-text">1 Plugin Update</span></a>		</li>
		<li id="wp-admin-bar-comments"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/edit-comments.php"><span class="ab-icon"></span><span class="ab-label awaiting-mod pending-count count-0" aria-hidden="true">0</span><span class="screen-reader-text">0 comments awaiting moderation</span></a>		</li>
		<li id="wp-admin-bar-new-content" class="menupop"><a class="ab-item" aria-haspopup="true" href="http://localhost/wordpress/wordpress/wp-admin/post-new.php"><span class="ab-icon"></span><span class="ab-label">New</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-new-content-default" class="ab-submenu">
		<li id="wp-admin-bar-new-post"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/post-new.php">Post</a>		</li>
		<li id="wp-admin-bar-new-media"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/media-new.php">Media</a>		</li>
		<li id="wp-admin-bar-new-page"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/post-new.php?post_type=page">Page</a>		</li>
		<li id="wp-admin-bar-new-job_listing"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/post-new.php?post_type=job_listing">Listing</a>		</li>
		<li id="wp-admin-bar-new-jobs"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/post-new.php?post_type=jobs">Job</a>		</li>
		<li id="wp-admin-bar-new-job-entry"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/post-new.php?post_type=job-entry">Job entry</a>		</li>
		<li id="wp-admin-bar-new-jobpost"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/post-new.php?post_type=jobpost">Job</a>		</li>
		<li id="wp-admin-bar-new-user"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/user-new.php">User</a>		</li>
		<li id="wp-admin-bar-new_content_smart_slider"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/admin.php?page=smart-slider-3#createslider">Slider [Smart Slider 3]</a>		</li></ul></div>		</li>
		<li id="wp-admin-bar-edit"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/post.php?post=14&#038;action=edit">Edit Page</a>		</li>
		<li id="wp-admin-bar-smart_slider_3" class="menupop"><a class="ab-item" aria-haspopup="true" href="http://localhost/wordpress/wordpress/wp-admin/admin.php?page=smart-slider-3">Smart Slider</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-smart_slider_3-default" class="ab-submenu">
		<li id="wp-admin-bar-smart_slider_3_dashboard"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/admin.php?page=smart-slider-3">Dashboard</a>		</li>
		<li id="wp-admin-bar-smart_slider_3_create_slider"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/admin.php?page=smart-slider-3#createslider">Create slider</a>		</li>
		<li id="wp-admin-bar-smart_slider_3_edit" class="menupop"><a class="ab-item" aria-haspopup="true" href="http://localhost/wordpress/wordpress/wp-admin/admin.php?page=smart-slider-3">Edit slider</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-smart_slider_3_edit-default" class="ab-submenu">
		<li id="wp-admin-bar-smart_slider_3_slider_1"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/admin.php?page=smart-slider-3&#038;nextendcontroller=slider&#038;nextendaction=edit&#038;sliderid=1">#1 - Sample Slider</a>		</li></ul></div>		</li></ul></div>		</li>
		<li id="wp-admin-bar-fl-builder-frontend-edit-link"><a class="ab-item" href="http://localhost/wordpress/wordpress/?fl_builder"><span class="ab-icon"></span>Beaver Builder <span class="fl-builder-admin-bar-status-dot" style="color:#6bc373; font-size:18px; line-height:1;">&bull;</span></a>		</li>
		<li id="wp-admin-bar-advanced_ads_ad_health" class="menupop"><div class="ab-item ab-empty-item" aria-haspopup="true">Ad Health</div><div class="ab-sub-wrapper"><ul id="wp-admin-bar-advanced_ads_ad_health-default" class="ab-submenu">
		<li id="wp-admin-bar-advanced_ads_ad_health_hidden_adsense" class="hidden advanced_ads_ad_health_warning advanced_ads_ad_health_hidden_adsense"><a class="ab-item" href="https://wpadvancedads.com/manual/ad-health/#adsense-hidden&#038;utm_source=advanced-ads&#038;utm_medium=link&#038;utm_campaign=frontend-adsense-hidden" target="_blank">AdSense violation: Ad is hidden. IDs: <i></i></a>		</li>
		<li id="wp-admin-bar-advanced_ads_autoads_displayed" class="hidden advanced_ads_ad_health_warning"><a class="ab-item" href="https://wpadvancedads.com/adsense-in-random-positions-auto-ads/#utm_source=advancedads&#038;utm_medium=link&#038;utm_campaign=frontend-autoads-ads" target="_blank">Random AdSense ads</a>		</li>
		<li id="wp-admin-bar-advanced_ads_ad_health_incorrect_head" class="hidden advanced_ads_ad_health_warning advanced_ads_ad_health_incorrect_head"><a class="ab-item" href="https://wpadvancedads.com/manual/ad-health/#header-ads" target="_blank">Visible ads should not use the Header placement: <i></i></a>		</li>
		<li id="wp-admin-bar-advanced_ads_ad_health_has_http" class="hidden advanced_ads_ad_health_warning advanced_ads_ad_health_has_http"><a class="ab-item" href="https://wpadvancedads.com/manual/ad-health/#https-ads" target="_blank">Your website is using HTTPS, but the ad code contains HTTP and might not work. Ad IDs: <i></i></a>		</li>
		<li id="wp-admin-bar-advanced_ads_ad_health_adblocker_enabled" class="hidden advanced_ads_ad_health_warning"><div class="ab-item ab-empty-item">Ad blocker enabled</div>		</li>
		<li id="wp-admin-bar-advanced_ads_ad_health_highlight_ads"><div class="ab-item ab-empty-item"><label style="color: inherit;"><input id="advanced_ads_highlight_ads_checkbox" type="checkbox"> highlight ads</label></div>		</li>
		<li id="wp-admin-bar-advanced_ads_ad_health_debug_dfp" class="hidden advanced_ads_ad_health_debug_dfp_link"><a class="ab-item" href="/wordpress/wordpress/?googfc" target="_blank">debug DFP ads</a>		</li>
		<li id="wp-admin-bar-advanced_ads_ad_health_fine"><div class="ab-item ab-empty-item">Everything is fine</div>		</li></ul></div>		</li></ul><ul id="wp-admin-bar-top-secondary" class="ab-top-secondary ab-top-menu">
		<li id="wp-admin-bar-search" class="admin-bar-search"><div class="ab-item ab-empty-item" tabindex="-1"><form action="http://localhost/wordpress/wordpress/" method="get" id="adminbarsearch"><input class="adminbar-input" name="s" id="adminbar-search" type="text" value="" maxlength="150" /><label for="adminbar-search" class="screen-reader-text">Search</label><input type="submit" class="adminbar-button" value="Search"/></form></div>		</li>
		<li id="wp-admin-bar-my-account" class="menupop with-avatar"><a class="ab-item" aria-haspopup="true" href="http://localhost/wordpress/wordpress/wp-admin/profile.php">Howdy, <span class="display-name">Darshit Patel</span><img alt='' src='http://0.gravatar.com/avatar/f5905e5a625788db9dbdfb170a56cc35?s=26&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/f5905e5a625788db9dbdfb170a56cc35?s=52&#038;d=mm&#038;r=g 2x' class='avatar avatar-26 photo' height='26' width='26' /></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-user-actions" class="ab-submenu">
		<li id="wp-admin-bar-user-info"><a class="ab-item" tabindex="-1" href="http://localhost/wordpress/wordpress/wp-admin/profile.php"><img alt='' src='http://0.gravatar.com/avatar/f5905e5a625788db9dbdfb170a56cc35?s=64&#038;d=mm&#038;r=g' srcset='http://0.gravatar.com/avatar/f5905e5a625788db9dbdfb170a56cc35?s=128&#038;d=mm&#038;r=g 2x' class='avatar avatar-64 photo' height='64' width='64' /><span class='display-name'>Darshit Patel</span></a>		</li>
		<li id="wp-admin-bar-edit-profile"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-admin/profile.php">Edit My Profile</a>		</li>
		<li id="wp-admin-bar-logout"><a class="ab-item" href="http://localhost/wordpress/wordpress/wp-login.php?action=logout&#038;_wpnonce=78fcf135d1">Log Out</a>		</li></ul></div>		</li></ul>			</div>
						<a class="screen-reader-shortcut" href="http://localhost/wordpress/wordpress/wp-login.php?action=logout&#038;_wpnonce=78fcf135d1">Log Out</a>
					</div>

		
</body>
</html>
