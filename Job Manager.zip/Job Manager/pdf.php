<?php 

require'fpdf.php';
class PD extends FPDF
{
// Page header
	function Header()
	{
    // Logo
	
    $this->SetFont('Arial','B',13);
    // Move to the right
    // Title
    $this->SetY(10);
    $this->Cell(90);

    $this->Image('BANNER.png',40,10,200,40);
    
   $this->Ln(30);
   $this->Line(00,50,2000,50);
    // Line break
   
    $this->SetY(80);
    $this->Cell(15);
    $this->SetFillColor(230,220,220);
    $this->Cell(80,10,'NAME',1,0,'C',TRUE);
    $this->Cell(180,10,'DARSHIT',1,0,'C');
 	$this->Ln(10);
 	$this->SetY(90);
    $this->Cell(15);
    $this->Cell(80,10,'ID',1,0,'C',TRUE);
    $this->Cell(180,10,'16IT067',1,0,'C');
    $this->Ln(10);
 	$this->SetY(100);
    $this->Cell(15);
    $this->Cell(80,10,'HOBBY',1,0,'C',TRUE);
    $this->Cell(180,10,'',1,0,'C');
    $this->Ln(10);
 	$this->SetY(110);
    $this->Cell(15);
    $this->Cell(80,10,'SKILL',1,0,'C',TRUE);
    $this->Cell(180,10,'',1,0,'C');
	}
}
$PD=new PD(); 
$PD->AliasNbPages();
$PD->SetMargins(2.54,2.54,2.54,2.54);
$PD->AddPage('L','A4',0);
$PD->Output();
?>