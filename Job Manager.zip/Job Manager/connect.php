<?php 

define("HOSTNAME","localhost");
define("PASSWORD","darshit");
define("USERNAME","DCP");
define("DATABASE","job creator");


$con = new mysqli(HOSTNAME,USERNAME,PASSWORD,DATABASE);

if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

?>