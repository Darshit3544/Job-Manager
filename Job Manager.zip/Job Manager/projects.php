<?php
include "header.php";
if($_SESSION["user_id"]=='')
        {
            $message = "Login First!!!";
            echo "<script type='text/javascript'>alert('$message');window.location='home.php'</script>";
        }
?>
	<title>Projects & Achievements &#8211; Job Creator</title>
 	<script src="ckeditor.js"></script>
 	<script type="text/javascript">
		$(document).ready(function(){
			var action="view";
			$.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action,
        success : function(data)
        {
          $("#vi").html(data);
        }
       })
  
    $("#project_form").submit(function(event){
            action="project";
           var name=document.getElementById('project_name').value;
           var tech=document.getElementById('tech').value;
           var con=CKEDITOR.instances.text.getData();
      event.preventDefault();
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action+"&desc="+con+"&nam="+name+"&tec="+tech,
        success : function(data)
        {
          $("#msg").html(data);
        }
       })
    })

       $("#ach_form").submit(function(event){
            action="ach";
           var name=document.getElementById('ach_name').value;
           var tech=document.getElementById('rank').value;
           var con=CKEDITOR.instances.text1.getData();
      event.preventDefault();
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action+"&desc="+con+"&nam="+name+"&tec="+tech,
        success : function(data)
        {
          $("#msg").html(data);
        }
       })
    })

   $("#intern_form").submit(function(event){
            action="intern";
           var name=document.getElementById('com_name').value;
           var tech=document.getElementById('time').value;
           var con=CKEDITOR.instances.text2.getData();
      event.preventDefault();
      $.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action+"&desc="+con+"&nam="+name+"&tim="+tech,
        success : function(data)
        {
          $("#msg2").html(data);
        }
       })
    })
})
</script>
<script type="text/javascript">
	function dele(a,b)
	{
		var action="dele";
		$.ajax({
        type:"POST",
        url:"login.php",
        data:"act="+action+"&num="+b+"&daa="+a,
        success : function(data)
        {
          $("#vi").html(data);
        }
       })
	}
</script>
 	<div class="row">

 		<div class="col-md-4"><h3><button><a data-toggle="modal" data-target="#project_modal" href="">Add Projects</a></button></h3></div>
 		<div class="col-md-4"><h3><button><a data-toggle="modal" data-target="#ach_modal" href="">Add Achievements</a></button></h3></div>
    <div class="col-md-4"><h3><button><a data-toggle="modal" data-target="#intern_modal" href="">Add Internship</a></button></h3></div>
 		</div>
 		<div>
 			<br>
 			
 			<p id="vi"></p>
 		</div>
    <div class="modal fade" id="project_modal" tabindex="-1" role="dialog" aria-hidden="true" style="top:30px">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Add Project Details
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cl()">
          <span aria-hidden="true">&times;</span>
        </button>
    </h3>
      </div>
      <div class="modal-body" >
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        
  <form class="formst" id="project_form">
  <div class="form-group"> 
    <label><strong>Project Name</strong></label>
    
    <input type="text" id="project_name" required>
    </div>
    <div class="form-group"> 
    <label><strong>Technologies Used</strong></label>
    
    <input type="text" id="tech" required>
    </div>
    <div class="form-group"> 
    <label><strong>Description</strong></label>
    
    <textarea rows="14" cols="40" id="text" placeholder="ENTER CONTENT HERE......" required></textarea> <script>CKEDITOR.replace( 'text' );</script>
    </div>
    <div class="form-group">
  <button type="submit" class="btn btn-primary" style="font-size:25px"><strong>Submit</strong></button>
  </div>
<p id="msg" ></p>


</form> 
      </div>
    </div>
    
</div>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="cl()" >Close</button>
       </div>
    </div>
  </div>
</div>

<div class="modal fade" id="ach_modal" tabindex="-1" role="dialog" aria-hidden="true" style="top:30px">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Add Achievement Details
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cl()">
          <span aria-hidden="true">&times;</span>
        </button>
    </h3>
      </div>
      <div class="modal-body" >
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        
  <form class="formst" id="ach_form">
  <div class="form-group"> 
    <label><strong>Name</strong></label>
    
    <input type="text" id="ach_name" required>
    </div>
    <div class="form-group"> 
    <label><strong>Rank</strong></label>
    
    <input type="text" id="rank" required>
    </div>
    <div class="form-group"> 
    <label><strong>Description</strong></label>
    
    <textarea rows="14" cols="40" id="text1" placeholder="ENTER CONTENT HERE......" required></textarea> <script>CKEDITOR.replace( 'text1' );</script>
    </div>
    <div class="form-group">
  <button type="submit" class="btn btn-primary" style="font-size:25px"><strong>Submit</strong></button>
  </div>
<p id="msg" ></p>


</form> 
      </div>
    </div>
    
</div>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="cl()" >Close</button>
       </div>
    </div>
  </div>
</div>

<div class="modal fade" id="intern_modal" tabindex="-1" role="dialog" aria-hidden="true" style="top:30px">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title">Add Internship Details
        <button type="button" class="close" data-dismiss="modal" aria-label="Close" onclick="cl()">
          <span aria-hidden="true">&times;</span>
        </button>
    </h3>
      </div>
      <div class="modal-body" >
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-6">
        
  <form id="intern_form">
  <div class="form-group"> 
    <label><strong>Company's Name</strong></label>
    
    <input type="text" id="com_name" required>
    </div>
    <div class="form-group"> 
    <label><strong>Duration</strong></label>
    
    <input type="text" id="time" required>
    </div>
    <div class="form-group"> 
    <label><strong>Description</strong></label>
    
    <textarea rows="14" cols="40" id="text2" placeholder="Write Something about work done in Internship......" required></textarea> <script>CKEDITOR.replace( 'text2' );</script>
    </div>
    <div class="form-group">
  <button type="submit" class="btn btn-primary" style="font-size:25px"><strong>Submit</strong></button>
  </div>
<p id="msg2" ></p>


</form> 
      </div>
    </div>
    
</div>
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="cl()" >Close</button>
       </div>
    </div>
  </div>
</div>

<?php
include "footer.php";
?>