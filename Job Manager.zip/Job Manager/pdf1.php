<?php 
session_start();
require "connect.php";
if($_SESSION["user_id"]=='')
        {
            $message = "Login First!!!";
            echo "<script type='text/javascript'>alert('$message');window.location='home.php'</script>";
        }
require'fpdf.php';
class PD extends FPDF
{
// Page header
    function Header()
    {
    // Logo
    $this->Image('CSPIT.png',0,0,60,50);
    $this->SetFont('Arial','B',13);
    // Move to the right
    // Title
    $this->SetY(10);
    $this->Cell(230);

    $this->Image('BANNER.png',80,5,200,40);
    $this->Line(00,50,2000,50);
    $this->Ln(40);
    }
    function Footer()
    {
    // Go to 1.5 cm from bottom
    $this->SetY(-15);
    // Select Arial italic 8
    $this->SetFont('Arial','I',14);
    // Print centered page number
    $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'R');
    }
}
$PD=new PD(); 
$PD->AddPage('L','A4',0);
$PD->Ln(30);
    $user=$_SESSION["user_id"];
   $tab="select * from details where User_id='$user'";
    $rlt=mysqli_query($con,$tab);
    $re=mysqli_fetch_array($rlt);
   $PD->ClippingCircle(250,85,30,True);
   $img="upls/".$user.".jpg";
    $PD->Image($img,190,60,115);
    $PD->UnsetClipping();
    $PD->Ln(30);
    $PD->SetY(60);
    $PD->Cell(10);
    $PD->write(10,$re['Name']);
    $PD->SetY(70);
    $PD->Cell(10);
    $PD->Write(10,'PHONE:-');
    $PD->SetY(70);
    $PD->Cell(30);
    $PD->write(10,$re['Number']);
    $PD->SetY(80);
    $PD->Cell(10);
    $PD->Write(10,'Email:-');
    $PD->SetY(80);
    $PD->Cell(30);
    $em=$user."@charusat.edu.in";
    $PD->write(10,$em);
    $PD->SetY(110+20);
    $PD->Cell(10);
    $PD->Write(10,'OBJECTIVE:-');
    $PD->Line(10,120,290,120);
    $PD->SetY(120+20);
    $PD->Cell(10);
    $PD->Write(10,'To work in an organization where culture of freedom and working for initiatives is ensured, facilitating my contribution');
    $PD->SetY(130+20);
    $PD->Cell(10);
    $PD->write(10,'through thoughts and action to the company vision and thus achieve self-development by playing a important role in the');
    $PD->SetY(140+20);
    $PD->Cell(10);
    $PD->write(10,'organization.');
    $PD->SetY(160+30);
    $PD->Cell(20);
    $PD->write(30,'EDUCATIONAL QUALIFICATION:-');
   // $PD->Line(10,170+20,290,170+20);
    $di=10;
    $PD->Ln(60+$di);
    $PD->Cell(10);
    $PD->SetY(60+$di);
    $PD->Cell(20);
    $PD->MultiCell(45,10,'YEAR',1,'C',False);
    $PD->SetY(60+$di);
    $PD->Cell(65);
    $PD->MultiCell(65,10,'DEGREE CERTIFICATION',1,'C',False);
    $PD->SetY(60+$di);
    $PD->Cell(130);
    $PD->MultiCell(65,10,'INSTITUTE / BOARD',1,'C',False);
    $PD->SetY(60+$di);
    $PD->Cell(195);
    $PD->MultiCell(65,10,'MARKS OBTAINED',1,'C',False);
    $PD->SetY(70+$di);
    $PD->Cell(20);
    $tab="select * from academic where User_id='$user'";
    $rlt=mysqli_query($con,$tab);
    $re=mysqli_fetch_array($rlt);
    $PD->MultiCell(45,10,'2010',1,'C',False);
    $PD->SetY(70+$di);
    $PD->Cell(65);
    $PD->MultiCell(65,10,'10',1,'C',False);
    $PD->SetY(70+$di);
    $PD->Cell(130);
    $PD->MultiCell(65,10,$re['10_Board'],1,'C',False);
    $PD->SetY(70+$di);
    $PD->Cell(195);
    $PD->MultiCell(65,10,$re['10th']."%",1,'C',False);
    $PD->SetY(80+$di);
    $PD->Cell(20);
    $PD->MultiCell(45,10,'2012',1,'C',False);
    $PD->SetY(80+$di);
    $PD->Cell(65);
    $PD->MultiCell(65,10,'12',1,'C',False);
    $PD->SetY(80+$di);
    $PD->Cell(130);
    $PD->MultiCell(65,10,$re['12_board'],1,'C',False);
    $PD->SetY(80+$di);
    $PD->Cell(195);
    $PD->MultiCell(65,10,$re['12th']."%",1,'C',False);
    $PD->SetY(90+$di);
    $PD->Cell(20);
    $PD->MultiCell(45,10,'2018',1,'C',False);
    $PD->SetY(90+$di);
    $PD->Cell(65);
    $PD->MultiCell(65,10,'Current CGPA',1,'C',False);
    $PD->SetY(90+$di);
    $PD->Cell(130);
    $PD->MultiCell(65,10,'CSPIT',1,'C',False);
    $PD->SetY(90+$di);
    $PD->Cell(195);
    $PD->MultiCell(65,10,$re['CGPA'],1,'C',False);
    $PD->Ln(10);
    $k=$i=$j=110;
    $PD->SetY($k=$j+10);
    $PD->Cell(20);
    $PD->write(10,'Technical Skills:-');
    //$PD->Line(10,$i=$k+10,290,$k+10);
    //$PD->Ln(10);
    //$k=-1;
    $tab="select * from interests where User_id='$user'";
    $rlt=mysqli_query($con,$tab);
    $a=0;
    $k-=10;
    while($re=mysqli_fetch_array($rlt))
    {
        
        if($a%2==0)
        {
        $k+=10;
        $PD->SetY($k);
        $PD->Cell(20);
        $PD->MultiCell(50,30,"*  ".$re['Skills'],0,'L',False);
        }
        else
        {
        $PD->SetY($k);
        $PD->Cell(60);
        $PD->MultiCell(50,30,"*  ".$re['Skills'],0,'L',False);
        }
        $a++;
    }
    $PD->SetY(250);
    $PD->Cell(20);
    $PD->write(25,'Extra Activities:-');
    $tab="select * from achievements where User_id='$user'";
    $rlt=mysqli_query($con,$tab);
    $PD->SetY(70);
        $PD->Cell(20);
        $PD->MultiCell(63,10,"Achievement",1,'L',False);
        $PD->SetY(70);
        $PD->Cell(83);
        $PD->MultiCell(63,10,"Rank",1,'L',False);
        $PD->SetY(70);
        $PD->Cell(146);
        $PD->MultiCell(115,10,"Description",1,'L',False);
        $i=0;
        $j=0;
    while($re=mysqli_fetch_array($rlt))
    {
        $i+=10;
        $PD->SetY(70+$i);
        $PD->Cell(20);
        $PD->MultiCell(63,10,$re['name'],1,'L',False);
        $PD->SetY(70+$i);
        $PD->Cell(83);
        $PD->MultiCell(63,10,$re['rank'],1,'L',False);
        $PD->SetY(70+$i);
        $PD->Cell(146);
        $PD->MultiCell(115,10,$re['description'],1,'L',False);
        
    }
    $j=70+$i;
    $PD->SetY($j+=20);
    $PD->Cell(20);
    $PD->write(25,'PROJECTS:-');
    $tab="select * from projects where User_id='$user'";
    $rlt=mysqli_query($con,$tab);
        $PD->SetY($j+=20);
        $PD->Cell(20);
        $PD->MultiCell(63,10,"Project",1,'L',False);
        $PD->SetY($j);
        $PD->Cell(83);
        $PD->MultiCell(63,10,"Technology Used",1,'L',False);
        $PD->SetY($j);
        $PD->Cell(146);
        $PD->MultiCell(115,10,"Description",1,'L',False);
         $i=$j;
    while($re=mysqli_fetch_array($rlt))
    {
       
        $PD->SetY($i+=10);
        $PD->Cell(20);
        $PD->MultiCell(63,10,$re['Projects'],1,'L',False);
        $PD->SetY($i);
        $PD->Cell(83);
        $PD->MultiCell(63,10,$re['tech'],1,'L',False);
        $PD->SetY($i);
        $PD->Cell(146);
        $PD->MultiCell(115,10,$re['Description'],1,'L',False);
    }
    
    $PD->SetY(250);
    $PD->Cell(20);
    $PD->write(25,'Internship Done:-');
    $tab="select * from internship where User_id='$user'";
    $rlt=mysqli_query($con,$tab);
        $PD->SetY($j=70);
        $PD->Cell(20);
        $PD->MultiCell(63,10,"Company",1,'L',False);
        $PD->SetY($j);
        $PD->Cell(83);
        $PD->MultiCell(63,10,"Duration",1,'L',False);
        $PD->SetY($j);
        $PD->Cell(146);
        $PD->MultiCell(115,10,"Description",1,'L',False);
         $i=$j;
    while($re=mysqli_fetch_array($rlt))
    {
       
        $PD->SetY($i+=10);
        $PD->Cell(20);
        $PD->MultiCell(63,10,$re['company'],1,'L',False);
        $PD->SetY($i);
        $PD->Cell(83);
        $PD->MultiCell(63,10,$re['time'],1,'L',False);
        $PD->SetY($i);
        $PD->Cell(146);
        $PD->MultiCell(115,10,$re['description'],1,'L',False);
    }
    

$PD->Output();
?>