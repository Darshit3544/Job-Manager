<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form action="pdf.php" method="GET">
NAME<input type="text" name="name"><br>
<input type="submit" name="submit">
</form>
</body>
</html>